create function gettimeback(serialnoArg in varchar2)
--初审回退门店时间
return varchar2
is tiemback varchar2(100);
begin
  select nvl(ba.isapprovebackorg,'否') into  tiemback from business_apply ba where ba.serialno=serialnoArg;
  if tiemback ='是' then
select updatetime into tiemback
 from flow_opinion where serialno=(
 select serialno from (
     select serialno
     from flow_opinion
     where reasoncode1 is not null
     and phasechoice = '初审回退录入'
     and objectno = serialnoArg order by updatetime desc)
   where rownum=1 );

  else
    tiemback:='';
  end if;

  return tiemback;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end gettimeback;
/

