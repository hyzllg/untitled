create PACKAGE BODY dw_getdimwid_pkg IS

  -- get_month_wid
  FUNCTION get_month_wid(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE IS
    l_month_wid dw_gd_month_d.month_wid%TYPE;
  BEGIN
    SELECT month.month_wid
      INTO l_month_wid
      FROM dw_gd_month_d MONTH
     WHERE month.month_name = p_period_name;
    RETURN l_month_wid;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_month_wid;
  END get_month_wid;

  -- get_last_month_wid
  FUNCTION get_last_month_wid(p_month_wid VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE IS
    l_month_wid dw_gd_month_d.month_wid%TYPE;
  BEGIN
    SELECT lm.month_wid
      INTO l_month_wid
      FROM (SELECT *
              FROM dw_gd_month_d m
             WHERE m.month_wid <
                   (SELECT distinct  cm.month_wid
                      FROM dw_gd_month_d cm
                     WHERE cm.month_wid = p_month_wid)
             ORDER BY m.month_wid DESC) lm
     WHERE rownum = 1;
    RETURN l_month_wid;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_month_wid;
  END get_last_month_wid;

  -- get_last_year_month_wid
  FUNCTION get_last_year_month_wid(p_month_wid VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE IS
    l_month_wid dw_gd_month_d.month_wid%TYPE;
  BEGIN
    SELECT m.month_wid
      INTO l_month_wid
      FROM dw_gd_month_d m
     WHERE (m.year_name, m.month_in_year) =
           (SELECT distinct cm.year_name - 1
                  ,cm.month_in_year
              FROM dw_gd_month_d cm
             WHERE cm.month_wid = p_month_wid);
    RETURN l_month_wid;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_month_wid;
  END get_last_year_month_wid;

  -- get_last_year_end_month_wid
  FUNCTION get_last_year_end_month_wid(p_month_wid VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE IS
    l_month_wid dw_gd_month_d.month_wid%TYPE;
  BEGIN
    SELECT m.month_wid
      INTO l_month_wid
      FROM dw_gd_month_d m
     WHERE (m.year_name, m.month_in_year) =
           (SELECT distinct  cm.year_name - 1
                  ,12
              FROM dw_gd_month_d cm
             WHERE cm.month_wid = p_month_wid);
    RETURN l_month_wid;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_month_wid;
  END get_last_year_end_month_wid;

  -- get_last_period_name
  FUNCTION get_last_period_name(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_name%TYPE
    PARALLEL_ENABLE IS
    l_period_name dw_gd_month_d.month_name%TYPE;
  BEGIN
    SELECT lm.month_name
      INTO l_period_name
      FROM (SELECT *
              FROM dw_gd_month_d m
             WHERE m.month_wid <
                   (SELECT distinct  cm.month_wid
                      FROM dw_gd_month_d cm
                     WHERE cm.month_name = p_period_name)
             ORDER BY m.month_wid DESC) lm
     WHERE rownum = 1;
    RETURN l_period_name;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_period_name;
  END get_last_period_name;

  -- get_last_year_period_name
  FUNCTION get_last_year_period_name(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_name%TYPE
    PARALLEL_ENABLE IS
    l_period_name dw_gd_month_d.month_name%TYPE;
  BEGIN
    SELECT m.month_name
      INTO l_period_name
      FROM dw_gd_month_d m
     WHERE (m.year_name, m.month_in_year) =
           (SELECT distinct  cm.year_name - 1
                  ,cm.month_in_year
              FROM dw_gd_month_d cm
             WHERE cm.month_name = p_period_name);
    RETURN l_period_name;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_period_name;
  END get_last_year_period_name;

  -- get_last_year_end_period_name
  FUNCTION get_last_year_end_period_name(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_name%TYPE
    PARALLEL_ENABLE IS
    l_period_name dw_gd_month_d.month_name%TYPE;
  BEGIN
    SELECT m.month_name
      INTO l_period_name
      FROM dw_gd_month_d m
     WHERE (m.year_name, m.month_in_year) =
           (SELECT distinct  cm.year_name - 1
                  ,12
              FROM dw_gd_month_d cm
             WHERE cm.month_name = p_period_name);
    RETURN l_period_name;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_period_name;
  END get_last_year_end_period_name;

END dw_getdimwid_pkg;
/

