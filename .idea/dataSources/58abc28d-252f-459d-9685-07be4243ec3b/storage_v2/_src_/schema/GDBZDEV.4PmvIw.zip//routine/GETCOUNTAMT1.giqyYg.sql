create procedure GETCOUNTAMT1(pObjectno varchar,pTerm varchar)
return varchar2
is pIncome varchar(30);
   v_col_name varchar2(30) := pTerm;
   v_sql_str varchar2(500);
begin
v_sql_str ='select distinct LAST_VALUE(||v_col_name||) OVER(PARTITION BY objectno ORDER BY serialno rows between unbounded preceding and unbounded following)
from flow_opinion where phaseno in('0030','0035','0045','0040','0047') and objectno= pObjectno' ;
execute immediate v_sql_str into pIncome;

end;

/

