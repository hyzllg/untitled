create function facedealwhycancel(serialnoArg in varchar2)
return varchar2
is cancelreanson varchar2(400);
   cancelreanson1 varchar2(400);

begin
  begin 
  select  fo.phaseopinion2 as opinino into cancelreanson
    from flow_opinion fo
   where
     reasoncode1 is not null and (phasechoice like '%取消%' or phasechoice like '%终止%')
     and objectno=serialnoArg
     and objecttype='CreditApply';
     select UNPUTOUTREASON as opinino into cancelreanson1 from business_apply where serialno=serialnoArg;

 return(cancelreanson||cancelreanson1);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return  '';
  WHEN OTHERS THEN
  return  '';
  end;
end;
/

