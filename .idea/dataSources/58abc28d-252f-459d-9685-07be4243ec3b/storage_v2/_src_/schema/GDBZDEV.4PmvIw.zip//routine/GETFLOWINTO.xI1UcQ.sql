create FUNCTION getFlowInto(sCertid varchar)
return varchar
is
flowinto1 varchar(2);
flowinto2 varchar(2);
begin
    select flowinto into flowinto1  FROM repayment_list WHERE repayserialno = (select MAX(repayserialno) from repayment_list where certid=sCertid);
    SELECT flowinto into flowinto2 FROM collection_info WHERE certid = sCertid;
	return flowinto1||flowinto2;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getFlowInto;
/

