create function getOrgFenbuProvince(orgArg in varchar2)
--获取门店所在省分部
 return varchar2 is
  vOrgId varchar(32);
begin
  select t.orgid
    into vOrgId
    from org_info t
   where t.orgname like '%分部%'
     and t.orglevel='12'
     and rownum = 1
   start with t.orgid = orgArg
  connect by t.orgid = prior t.belongorgid;
  return vOrgId;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end getOrgFenbuProvince;

/

