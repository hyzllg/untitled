create FUNCTION getObjectTypeName
(
   pObjectType VARCHAR2
)
RETURN VARCHAR2
IS
v_Result varchar2(600);
BEGIN
select
coalesce(ObjectName,pObjectType) into v_Result
from OBJECTTYPE_CATALOG
where ObjectType=pObjectType
;
return v_Result;
END;

/

