create view VW_CLEAR_LOAN_DATA as
select
serialno          ,
branchname        ,
businesstypename  ,
termmonth         ,
businesssum       ,
signtime          ,
inputorgname      ,
fee1rate          ,
finishdate        ,
inputtime         ,
updatetime        ,
loansource        ,
customertype      ,
presum            ,
prepolicyrate     ,
lastnewapprovalno ,
renewrepayloanterm,
batchno           ,
approveseg
from GDBZDEV.clear_loan_data
/

