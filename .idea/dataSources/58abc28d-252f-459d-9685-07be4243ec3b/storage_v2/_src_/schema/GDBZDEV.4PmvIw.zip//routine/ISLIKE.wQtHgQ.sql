create FUNCTION ISLIKE(pOrigin varchar2,pTarget varchar2)
return integer   --pOrigin Like pTarget%，返回1，否则返回0
is
 pResult integer;
begin

 if(pOrigin like pTarget||'%') then
   pResult := 1;
 else
   pResult := 0;
 end if;
     return pResult;
end;

/

