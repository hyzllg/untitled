create FUNCTION getlpstyle(serialno in varchar)
return varchar
is  lpstylename  varchar(200);
pCount  varchar2(20);
qCount  varchar2(20);
begin
  lpstylename:='';
  select count(1) into pCount from bankadvancedclaimgd b
  where b.businessno=serialno and status<>'0';
  if (pCount>0) then
    select b.lpstyle into lpstylename from bankadvancedclaimgd b where b.businessno=serialno and status<>'0';
  else
    select count(1) into qCount from bankadvancedclaimhb a where a.businessno=serialno and status<>'0';
    if (qCount>0) then
      select a.lpstyle into lpstylename from bankadvancedclaimhb a where a.businessno=serialno and status<>'0';
    else
      select count(1) into qCount from bankadvancedclaimhs a where a.businessno=serialno and status<>'0';
      if (qCount>0) then
        select a.lpstyle into lpstylename from bankadvancedclaimhs a where a.businessno=serialno and status<>'0';
      else
         lpstylename:='正常理赔';
      end if;
    end if;
  end if;
  return lpstylename;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '正常理赔';
  WHEN OTHERS THEN
  return '正常理赔';

end;
/

