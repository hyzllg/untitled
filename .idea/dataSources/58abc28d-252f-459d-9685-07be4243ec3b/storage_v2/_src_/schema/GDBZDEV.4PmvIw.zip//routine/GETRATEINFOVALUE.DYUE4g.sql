create FUNCTION "GETRATEINFOVALUE"(sRATETYPE varchar2,sbusinesstype varchar2,srelativecode varchar2,scooperativebank varchar2,sorgid varchar2)
return number
is sRate number(10,7);
  baseRate varchar2(50);
  floatRateStr varchar2(50);
  resultStr varchar2(50);
  resultStrFloat varchar2(50);

begin
   ---获取基准利率
   select nvl((select ar.ratevalue from (select ratevalue from acct_rate_info where ratetype=sRATETYPE and status ='1' and srelativecode>minterm and srelativecode<=maxterm order by effectdate desc) ar where rownum=1),'0') into baseRate from dual;
   select nvl((select t.floatrate from loanrate_info t, code_library cl where t.loanterm=cl.itemno and cl.codeno='贷款期限' and cl.relativecode=srelativecode and t.ISINUSE='1' and t.TYPENO=sbusinesstype and t.cooperativebank=scooperativebank and t.orgid =sorgid and rownum=1),'N') into floatRateStr from dual;
   select nvl((select t.loanrate from loanrate_info t, code_library cl where t.loanterm=cl.itemno and cl.codeno='贷款期限' and cl.relativecode=srelativecode and t.ISINUSE='1' and t.TYPENO=sbusinesstype and t.cooperativebank=scooperativebank and t.orgid is null and rownum=1),'N') into resultStr from dual;
   select nvl((select t.floatrate from loanrate_info t, code_library cl where t.loanterm=cl.itemno and cl.codeno='贷款期限' and cl.relativecode=srelativecode and t.ISINUSE='1' and t.TYPENO=sbusinesstype and t.cooperativebank=scooperativebank and t.orgid is null and rownum=1),'N') into resultStrFloat from dual;

   if floatRateStr<>'N' then
       select round(baseRate*(1 + floatRateStr/100),7) into sRate from dual;
   else
     if resultStr<>'N' then
         select resultStr*1 into sRate from dual;
     else
       if resultStrFloat<>'N' then
          select round(baseRate*(1 + resultStrFloat/100),7) into sRate from dual;
       else
          select baseRate*1 into sRate from dual;
       end if;
     end if;
   end if;
   return sRate;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end;
/

