create function getDateFromTimeStamp(tsp in integer) return date is
  Result date;
  tt     integer;
begin
  tt := substr(tsp, 0, 13);
  SELECT ((tt - EXTRACT(SECOND FROM SYSTIMESTAMP(3)) * 1000) / 86400000 +
         TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24miss'))
    into result
    FROM DUAL;
  return(Result);
end getDateFromTimeStamp;
/

