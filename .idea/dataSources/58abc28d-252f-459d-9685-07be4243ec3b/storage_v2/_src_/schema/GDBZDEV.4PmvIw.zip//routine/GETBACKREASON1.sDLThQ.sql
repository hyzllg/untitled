create function GetBackReason1(ftserialnoArg in varchar2)
--找上一阶段的回退原因
return varchar2
is backReason  varchar2(200) ;
begin
  select a.mainreason||'-'||b.subreason into backReason from
(select ra.mainreason,fo.serialno
  from reason_param ra, flow_opinion fo
 where reasontype = '20'
   and fo.phaseno = ra.phaseno
   and fo.reasoncode1 = ra.mainreasoncode
   --and fo.reasoncode2 = ra.subreasoncode
   and fo.serialno = ftserialnoArg) a left join
   (select ra.subreason ,fo.serialno
  from reason_param ra, flow_opinion fo
 where reasontype = '20'
   and fo.phaseno = ra.phaseno
   --and fo.reasoncode1 = ra.mainreasoncode
   and fo.reasoncode2 = ra.subreasoncode
   and fo.serialno = ftserialnoArg ) b on a.serialno=b.serialno ;
  return backReason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetBackReason1;

/

