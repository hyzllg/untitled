create FUNCTION getBusinessTypeName(pSerialnoID varchar2)
--获取产品类型
return varchar2
is pBusinessTypeName  varchar2(80);
begin
select businesstypename into pBusinessTypeName
  from business_apply
where serialno = pSerialnoID;
  return pBusinessTypeName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end;

/

