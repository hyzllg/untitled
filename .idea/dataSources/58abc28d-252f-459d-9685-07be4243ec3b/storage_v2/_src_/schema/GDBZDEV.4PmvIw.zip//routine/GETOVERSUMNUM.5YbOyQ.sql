create FUNCTION           "GETOVERSUMNUM"(pSerialno varchar)
return varchar
is pBalance  Number(20,4);
begin
select (case
         when nvl(al.overduedays, 0) = 0 then
          0           
         else
          nvl(al.overduebalance, 0) + nvl(al.interestbalance, 0) +
          nvl(al.fineintebalance, 0) + nvl(al.feeamtbalance, 0) +
          nvl(al.overduefinebalance, 0) + nvl(al.compintebalance,0)
       end)
  into pBalance
from acct_loan al
where serialno = pSerialno;
  return pBalance;
end;
/

