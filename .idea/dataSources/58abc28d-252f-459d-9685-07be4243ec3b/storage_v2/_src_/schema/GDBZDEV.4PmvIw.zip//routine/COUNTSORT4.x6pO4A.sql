create FUNCTION         countsort4(sReportNo in varchar2)
return integer is
  Counts  integer;
begin
  Counts := 0;
  if Counts = 0 then
    select count(*) into Counts from icr_rpt_t24 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t25 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t22 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t23 where rptno = sReportNo;
  end if;
  return(Counts);
end;

/

