create FUNCTION getapprovalrate(objectNo varchar)
return varchar
is PREMIUMRATE varchar(80);
begin
select PREMIUMRATE into PREMIUMRATE
from (select PREMIUMRATE from approval_amount aa where objectno=objectNo order by INPUTTIME desc)
 where rownum=1;
 return PREMIUMRATE;
end;
/

