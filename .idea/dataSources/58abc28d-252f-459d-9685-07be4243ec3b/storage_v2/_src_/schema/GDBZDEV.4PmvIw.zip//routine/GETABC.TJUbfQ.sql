create FUNCTION getabc(pSerialnoID varchar)
return varchar
is pChannel  varchar(80);
begin
select channel into pChannel
  from business_apply
where serialno = pSerialnoID;
  return pChannel;
end;
/

