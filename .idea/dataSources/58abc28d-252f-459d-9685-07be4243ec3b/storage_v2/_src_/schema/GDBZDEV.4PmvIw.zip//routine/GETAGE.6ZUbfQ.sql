create FUNCTION GETAGE(pCustomerid varchar)
return varchar2
is pAge varchar(10);
begin
select  floor(MONTHS_BETWEEN(sysdate,to_date(birthday,'yyyy/mm/dd'))/12)  into pAge from ind_info where customerid= pCustomerid;
return (pAge);
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

