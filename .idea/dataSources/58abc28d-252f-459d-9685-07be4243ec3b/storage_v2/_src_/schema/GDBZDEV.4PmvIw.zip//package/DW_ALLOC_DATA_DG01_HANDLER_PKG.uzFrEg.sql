create PACKAGE         dw_alloc_data_dg01_handler_pkg IS

/*=========================================
一.待摊数据维度维值处理
=========================================*/
  --1.oracle财务系统待摊处理
   PROCEDURE pre_alloc_financial_sys(x_return_status        OUT VARCHAR2,
                                     p_plan_node_control_id NUMBER,
                                     p_period_name          VARCHAR2,
                                     p_ledger_id            NUMBER);
  --2.费控系统待摊处理
   PROCEDURE pre_alloc_expense_control_sys(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2);
  --3.人事系统待摊处理（补录）
   PROCEDURE pre_alloc_hr_sys_apd(x_return_status        OUT VARCHAR2,
                                  p_plan_node_control_id NUMBER,
                                  p_period_name          VARCHAR2);

  --4.基本法系统待摊处理（补录）
   PROCEDURE pre_alloc_basic_law_sys_apd(x_return_status        OUT VARCHAR2,
                                         p_plan_node_control_id NUMBER,
                                         p_period_name          VARCHAR2);
/*=========================================
二.分摊因子数据维度维值处理
=========================================*/
  --预处理acct_payment_schedule_v
  PROCEDURE alloc_pre_paymt_schdu(x_return_status        OUT VARCHAR2,
                                  p_plan_node_control_id NUMBER,
                                  p_period_name          VARCHAR2);

  /*--根据跑批日期生产当月的视图
  PROCEDURE alloc_pre_view(p_period_name VARCHAR2);*/

  --1.当月新增账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_incremnt_account(x_return_status        OUT VARCHAR2,
                                       p_plan_node_control_id NUMBER,
                                       p_period_name          VARCHAR2);
  --2.年累计新增账户数ETL处理（个贷系统因子）--删
  --3.累计 新增账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_cum_incremnt_account(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2);
  --4.期末账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_end_account(x_return_status        OUT VARCHAR2,
                                         p_plan_node_control_id NUMBER,
                                         p_period_name          VARCHAR2);
  --5.期末账户数与当月新增账户数差值（个贷系统因子）ETL处理
  PROCEDURE alloc_fcr_period_end_acontblac(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2);
  --6.期末账户数（逾期期数为M2）ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_end_accountm2(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2);
  --7.当月逾期账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_overdue_acout(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2);
  --8.年累计平均逾期账户数（不含M7）ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_avgytd_overdue_acout(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2);
  --9.累计逾期账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_cum_overdue_acout(x_return_status        OUT VARCHAR2,
                                        p_plan_node_control_id NUMBER,
                                        p_period_name          VARCHAR2);
  --10.当月申请量ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_apply_num(x_return_status        OUT VARCHAR2,
                                       p_plan_node_control_id NUMBER,
                                       p_period_name          VARCHAR2);
  --11.有效保单剩余本金ETL处理（个贷系统因子） --删
  --12.保单1号UPR ETL处理（ORACLE系统因子）
  PROCEDURE alloc_fcr_ipo1_upr(x_return_status      OUT VARCHAR2,
                               p_plan_node_control_id NUMBER,
                               p_period_name          VARCHAR2);
  --13.佣金占比 ETL处理（基本法-手工补录系统因子）
  PROCEDURE alloc_fcr_commission_percent (x_return_status      OUT VARCHAR2,
                                          p_plan_node_control_id NUMBER,
                                          p_period_name          VARCHAR2);

/*=========================================
三.分摊过程特殊处理
=========================================*/
  --1.？期末账户数对前期累计费用进行分摊
  PROCEDURE c(x_return_status         OUT VARCHAR2,
              p_plan_node_control_id  NUMBER);
  --2.清空分摊表分摊数据

  --3.分摊数据归档
  PROCEDURE alloc_spec_achieve(x_return_status         OUT VARCHAR2
                                 ,p_plan_node_control_id NUMBER
                                 ,p_period_name          VARCHAR2
                                 ,p_coa_id               NUMBER);
END dw_alloc_data_dg01_handler_pkg;

/

