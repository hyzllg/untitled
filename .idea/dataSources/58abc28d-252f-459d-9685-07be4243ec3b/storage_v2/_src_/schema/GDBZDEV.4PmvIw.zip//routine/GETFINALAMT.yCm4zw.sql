create function getfinalamt(serialnoArg in varchar2)
--获取最终审批金额
return varchar2
is approvesum varchar2(20);
begin
 select fo.businesssum into approvesum
   from flow_opinion fo
  where fo.opinionno = （select opinionno from (select opinionno 
                         from flow_opinion
                        where phaseno in('0040','0035','0030','0045','0047')
                          and objectno = serialnoArg order by updatetime desc)where rownum=1);
  return approvesum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfinalamt;

/

