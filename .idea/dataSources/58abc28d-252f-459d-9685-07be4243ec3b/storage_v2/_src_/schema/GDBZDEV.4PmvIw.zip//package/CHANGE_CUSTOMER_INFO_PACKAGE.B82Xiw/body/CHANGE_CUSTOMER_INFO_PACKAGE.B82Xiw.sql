create package body change_customer_info_package is
        --更新其他表
        function replaceOtherInfoID(certid varchar2,custid varchar2) return varchar2
        is
            Type Custinfocursor IS  REF CURSOR RETURN azhi_customer_info%RowType;
            vCustomerCur  Custinfocursor;
            vTempC  vCustomerCur%RowType;
            str varchar2(150);
            customerId varchar2(40);
        begin

           open  vCustomerCur for select * from azhi_customer_info ci where ci.certid=custid;
           loop
               exit when vCustomerCur%notfound;
               fetch vCustomerCur into vTempC;

                str:='update INSURE_APPLY set customerid=:1 wehere customerid=:2;';
                customerId:=vTempC.customerid;
                execute immediate str using custid,customerId;
                commit;
            end loop;
            close vCustomerCur;
            return '';
        end;
end change_customer_info_package;
/

