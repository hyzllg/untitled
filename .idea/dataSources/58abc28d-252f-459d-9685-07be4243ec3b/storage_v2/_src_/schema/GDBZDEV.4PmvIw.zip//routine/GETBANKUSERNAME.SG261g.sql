create function GetBankUserName(bankUserArg in varchar2)
return varchar2
is BankNameValue varchar2(200) ;
begin
 select distinct inputusername into BankNameValue from cooperative_bank where inputuserid = bankUserArg;
  return BankNameValue;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetBankUserName;

/

