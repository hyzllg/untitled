create function GetEndResultApprove1(serialnoArg in varchar2)
--内配-电话匹配-审批结果
return varchar2
is approveendresult varchar2(200) ;
begin
  select phaseaction  into approveendresult
    from flow_task ft
   where serialno = (select max(relativeserialno)
                       from flow_task
                      where exists (select 1
                               from flow_task
                              where phaseno='0030' and endtime is not null and objectno = ft.objectno and flowno='CreditFlow' and userid<>'OPS')
                        and phaseno not in ('0070', '1000','2060','2050','2070','2010','2000','3030','2080','3080','2090','3000','3060','3080','3070')
                        and objectno = ft.objectno and flowno='CreditFlow') and objectno=serialnoArg and ft.flowno='CreditFlow';
  return approveendresult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetEndResultApprove1;
/

