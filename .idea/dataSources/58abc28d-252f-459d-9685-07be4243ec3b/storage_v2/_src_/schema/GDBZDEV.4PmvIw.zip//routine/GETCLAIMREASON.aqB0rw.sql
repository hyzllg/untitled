create FUNCTION getClaimReason(serialno in varchar)
return varchar
is  claimReason  varchar(200);
pCount  varchar2(20);
qCount  varchar2(20);
begin
  claimReason:='';
  select count(1) into pCount from bankadvancedclaimgd b
  where b.businessno=serialno ;
  if (pCount>0) then
    select b.claimReason into claimReason from bankadvancedclaimgd b where b.businessno=serialno ;
  else
    select count(1) into qCount from bankadvancedclaimhb a where a.businessno=serialno ;
    if (qCount>0) then
      select a.claimReason into claimReason from bankadvancedclaimhb a where a.businessno=serialno ;
    else
      select count(1) into qCount from bankadvancedclaimhs a where a.businessno=serialno ;
      if (qCount>0) then
        select a.claimReason into claimReason from bankadvancedclaimhs a where a.businessno=serialno ;
      else
        claimReason:='';
      end if;
    end if;
  end if;
  return claimReason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';

end;
/

