create FUNCTION getOtherReason(serialno in varchar)
return varchar
is  otherReason  varchar(200);
pCount  varchar2(20);
qCount  varchar2(20);
begin
  otherReason:='';
  select count(1) into pCount from bankadvancedclaimgd b
  where b.businessno=serialno ;
  if (pCount>0) then
    select b.otherReason into otherReason from bankadvancedclaimgd b where b.businessno=serialno ;
  else
    select count(1) into qCount from bankadvancedclaimhb a where a.businessno=serialno ;
    if (qCount>0) then
      select a.otherReason into otherReason from bankadvancedclaimhb a where a.businessno=serialno ;
    else
      select count(1) into qCount from bankadvancedclaimhs a where a.businessno=serialno ;
      if (qCount>0) then
        select a.otherReason into otherReason from bankadvancedclaimhs a where a.businessno=serialno ;
      else
        otherReason:='';
      end if;
    end if;
  end if;
  return otherReason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';

end;
/

