create FUNCTION GETCARDTYPE(pSerialno varchar2)
    return varchar2
    is pCardType  varchar2(10);
    pCount  varchar2(60);
    begin
    select count(1) into pCount from Card_Reader where customerid = (select customerid from business_apply where serialno = pSerialno and inputdate<'2019/05/12') and baserialno is null;
    if pCount>0 then
          select CardType into pCardType from Card_Reader where customerid = (select customerid from business_apply where serialno = pSerialno and inputdate<'2019/05/12') and baserialno is null;
    else
          select CardType into pCardType from Card_Reader where baserialno = pSerialno;
    end if;
  return pCardType;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '0';
  WHEN OTHERS THEN
  return '0';
end;
/

