create FUNCTION getAppointmentDate(pRelserialno varchar)
return varchar
is pAppointmentDate  varchar(40);
begin
	select AppointmentDate into pAppointmentDate
	from telsignrecord
	where relserialno=pRelserialno;
	return pAppointmentDate;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
END getAppointmentDate;
/

