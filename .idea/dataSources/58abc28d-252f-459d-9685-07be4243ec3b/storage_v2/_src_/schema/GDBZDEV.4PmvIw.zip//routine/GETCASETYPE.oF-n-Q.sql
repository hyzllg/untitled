create FUNCTION getCaseType(businessno varchar)
--获取案件类型
return varchar2
is sCasetype  varchar2(80);
begin
select
   case
              when (nvl(ba.isgreen,'2')=1 and nvl(ba.segmentrecommend,'2')=1) then '分部推荐、绿色通道'
              when (nvl(ba.isgreen,'2')=1 and nvl(ba.segmentrecommend,'2')=2) then '绿色通道'
              when (nvl(ba.isgreen,'2')=2 and nvl(ba.segmentrecommend,'2')=1) then '分部推荐'
              when (nvl(ba.isgreen,'2')=2 and nvl(ba.segmentrecommend,'2')=2) then '普通'
              else ''
   end
into sCasetype from business_apply ba where ba.serialno = businessno;
return sCasetype;
end;
/

