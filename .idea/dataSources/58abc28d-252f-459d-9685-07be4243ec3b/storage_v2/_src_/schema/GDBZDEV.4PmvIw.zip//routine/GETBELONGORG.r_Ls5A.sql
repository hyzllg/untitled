create function getbelongorg(teamidArg in varchar2)
--获取催收所属机构
 return varchar2
is
  belongorg varchar2(20);
begin
  select belongorg into belongorg
    from user_info
   where userid = (select leader
                     from urge_team_info
                    where teamid = teamidArg);
  return(belongorg);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getbelongorg;
/

