create FUNCTION getReasonDetails(pSerialNo varchar)
/**
* 获取门店拒绝详情 2018/06/29
*/
return varchar
is  pReason  varchar(600);
begin
  pReason:='';
  select REASON into pReason
  from SIGN_REMARK
  where  SERIALNO=(select  max(serialno)  from  SIGN_REMARK where OBJECTTYPE='CreditApply' and OBJECTNO=pSerialNo);
  if pReason is null then
            return '';
  else
            return pReason;
  end if;
end;
/

