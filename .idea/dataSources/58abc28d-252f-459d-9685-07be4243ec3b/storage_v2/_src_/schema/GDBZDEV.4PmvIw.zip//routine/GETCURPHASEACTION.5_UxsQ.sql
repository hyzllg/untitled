create FUNCTION getCurPhaseAction(V_ObjectType varchar,V_ObjectNo varchar, V_SerialNo varchar)
return varchar
is v_phaseAction  varchar(80);
begin
select phaseAction into v_phaseAction
  from flow_task
where objecttype = V_ObjectType and objectno=V_ObjectNo and serialno=V_SerialNo;
  return v_phaseAction;
end;

/

