create FUNCTION getentkeyman(pCustomerID varchar,pRelationShip  varchar)
return varchar
is pEntKeyManName  varchar(80);
begin
select CustomerName into pEntKeyManName
  from CUSTOMER_RELATIVE
  where CustomerID = pCustomerID
  and RelationShip = pRelationShip;
return pEntKeyManName;
end;

/

