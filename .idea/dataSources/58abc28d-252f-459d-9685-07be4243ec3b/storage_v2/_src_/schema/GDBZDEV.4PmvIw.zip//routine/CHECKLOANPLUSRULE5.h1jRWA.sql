create Function         checkLoanPlusRule5 ( pCertID IN varchar2 ) RETURN varchar2
IS
     ret varchar2(10);
     ICount number(6);
     IMonthBtw number(10);
     DXSerialNo varchar2(20);
     sMAXPhaseno varchar2(20);
     sOrderDate varchar2(20);
     sEndtime varchar2(20);
BEGIN
     select count(1) into ICount
     from acct_loan al,customer_info ci,business_type bt,acct_payment_schedule aps,business_apply ba
     where al.CUSTOMERID=ci.customerid
       and al.businesstype=bt.typeno
       and aps.objectno=al.serialno
       and al.baserialno=ba.serialno

     --5.当前无在途申请（指放款前的申请）
      and NOT EXISTS
      (
          select bt.customerid
          from flow_object ft, business_apply bt
          where ft.objectno = bt.serialno
            and bt.customerid=ci.customerid
            and ft.flowno='CreditFlow'
            and ft.phasetype <=1000 AND nvl(bt.putoutflag,'1') IN ('1','10','4','7','8')
     )
     and NOT EXISTS
     (
          select rsa.creditid
          from retail_sales_apply rsa
          where rsa.creditid =ci.certid
            and rsa.staus <='6003'
     )
     and ci.certid=pCertID;

     IF ICount=0 THEN
        ret := 'Betray';
     ELSE
        ret := 'LOVE';
     END IF;
     RETURN ret;
END;

/

