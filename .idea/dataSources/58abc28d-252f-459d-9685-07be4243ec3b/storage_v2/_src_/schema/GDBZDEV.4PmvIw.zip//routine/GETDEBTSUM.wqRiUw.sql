create function getdebtsum(serialnoArg in varchar2)
--获取负债金额
return number
is
  debtsum number;
begin
      select  tatalDebt into debtsum
        from flow_opinion where opinionno =(select opinionno from 
        ( select opinionno from flow_opinion
       where  objectno=serialnoArg
         and phaseno in ('0030','0035')
         and objecttype = 'CreditApply' order by updatetime desc)where rownum=1);
  return(debtsum);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getdebtsum;
/

