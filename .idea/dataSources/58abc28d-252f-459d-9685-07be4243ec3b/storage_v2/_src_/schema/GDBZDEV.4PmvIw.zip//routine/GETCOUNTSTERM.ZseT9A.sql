create FUNCTION getCountSterm(pObjectno varchar2)
--获取已还期数
return varchar2
is  pCountOverstage  varchar2(20);
begin
  select count(1) into pCountOverstage from acct_payment_schedule where (nvl(paycorpusamt,0)+nvl(payinteamt,0)+nvl(payfineamt,0)+nvl(payfeeamt1,0)+nvl(paycompdinteamt，0))-(nvl(actualpaycorpusamt,0)+nvl(actualfineamt,0)+nvl(actualpayinteamt,0)+nvl(actualpayfeeamt1,0)+nvl(actualcompdinteamt,0))=0
 and objectno = pObjectno  ;
  return pCountOverstage;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

