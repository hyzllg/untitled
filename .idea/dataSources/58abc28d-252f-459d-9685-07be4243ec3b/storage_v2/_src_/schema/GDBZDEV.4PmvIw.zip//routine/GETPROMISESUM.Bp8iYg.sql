create function getpromisesum(idArg  in varchar2)
--获取某催收员下承诺还款总金额
return number is
  promisesum number;
begin
  select sum(promisesum) into promisesum
    from collection_info
   where collectionuserid = idArg
     and isinuse = '1';
  return(promisesum);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getpromisesum;
/

