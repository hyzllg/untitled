create function GetStatementBelongTeamNum(orgidArg in varchar2)
--获取机构下营业组数
return number
is countteam number(10) ;
begin
 select count(orgid) into countteam from org_statement_info o where o.belongorgid=orgidArg;
  return  countteam;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GETSTATEMENTBELONGTEAMNUM;

/

