create FUNCTION getcreditstatus(pSerialNo varchar)
return varchar
is sFinishDate varchar(10);
begin
   select FinishDate into sFinishDate from BUSINESS_CONTRACT
   where SerialNo=pSerialNo;
   if sFinishDate is not null then
      return '???';
   else
       return '??';
   end if;
end;

/

