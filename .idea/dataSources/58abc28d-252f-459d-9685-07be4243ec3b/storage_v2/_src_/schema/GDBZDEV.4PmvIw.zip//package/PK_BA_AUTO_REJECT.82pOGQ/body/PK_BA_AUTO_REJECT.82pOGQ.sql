create package body pk_ba_auto_reject is
  /*
  * 检查客户是否有在途申请
  */
  procedure sp_has_apply_info(pi_ba_serial_no  in varchar2,
                              pi_cert_id       in varchar2,
                              po_reject_reason out varchar2) is
    v_count int := 0;
  begin
    select count(0)
      into v_count
      from flow_object ft, business_apply ba, customer_info ci
     where ft.objectno = ba.serialno
       and ba.customerid = ci.customerid
       and ft.flowno = 'CreditFlow'
       and ft.phasetype <= 1000
       and nvl(ba.putoutflag, '1') = '1'
       and ba.serialno <> pi_ba_serial_no
       and ci.certid = pi_cert_id;

    if v_count > 0 then
      po_reject_reason := '该客户有在途申请，拒绝申请';
    end if;
  end sp_has_apply_info;

  /*
  * 检查客户是否为个贷部黑名单
  */
  /*procedure sp_is_in_black_list(pi_cert_id       in varchar2,
                                po_reject_reason out varchar2) is
    v_count varchar2(20) := '';
  begin
    select bi.CASERESULT
      into v_count
      from black_info bi
     where nvl(status, '1') = '1'
       and bi.certid = pi_cert_id;

    if v_count = '03' then
      po_reject_reason := '客户为个贷部黑名单客户，拒绝申请';
    else po_reject_reason :='';
    end if;
    exception
      when no_data_found then
        po_reject_reason := '';
  end sp_is_in_black_list; */

  /*
  * 检查贷款已结清历史是否存在逾期超过60天
  */
  procedure sp_has_overdure_his(pi_cert_id       in varchar2,
                                po_reject_reason out varchar2) is
    v_count int := 0;
  begin
    select count(0)
      into v_count
      from customer_info ci, acct_loan al
     where ci.customerid = al.customerid
       and al.finishdate is not null
       and exists
     (select 1
              from acct_payment_schedule aps
             where aps.objectno = al.serialno
               and (to_date(nvl(aps.finishdate, aps.paydate), 'yyyy-MM-dd') -
                   to_date(aps.paydate, 'yyyy-MM-dd')) > 60)
       and ci.certid = pi_cert_id;
    if v_count > 0 then
      po_reject_reason := '贷款已结清，但历史上逾期有超过60天，拒绝申请';
    end if;
  end sp_has_overdure_his;

  /*
  * 检查客户是否有被拒绝过
  * 拒绝原因主代码为SP12,SP13,SP29,SP14,SP18
  * SP18子原因为SP1802的，自动拒绝，其它不会拒绝

  "出现以下任一项，拒绝：
1、客户前次因“提供虚假资料/疑欺诈申请”（SP12/SP13/SP29）被拒绝；
2、申请人前次因“信息不真实”被拒绝(SP14)，此次申请距离上次申请被拒绝在3个月以内；
3、申请人因“信息无法核实-客户身份信息难于核实”(SP18-SP1802)被拒绝，此次申请距离上次申请被拒绝在1个月以内。"

  */
  procedure sp_has_reject_his(pi_ba_serial_no  in varchar2, -- 申请编号
                              pi_cert_id       in varchar2, -- 客户身份证信息
                              po_reject_reason out varchar2) is
    v_main_reason_code flow_opinion.reasoncode1%type;
  begin
    begin
    select  fc.reasoncode1
     into v_main_reason_code
     from (select fo.reasoncode1
         from flow_task      ft,
             flow_opinion   fo,
             business_apply ba,
             customer_info  ci
       where ft.objectno = ba.serialno
         and ft.objectno = fo.objectno
         and ba.customerid = ci.customerid
         and ft.flowno = 'CreditFlow'
         and fo.phaseno = ft.phaseno
         and fo.serialno = ft.serialno
         and (fo.reasoncode1 in ('SP12', 'SP13', 'SP29') or
             (fo.reasoncode1 = 'SP14' and
             ft.endtime >= to_char(add_months(trunc(sysdate), -3),'yyyy/MM/dd')) or
             (fo.reasoncode1 = 'SP18' and fo.reasoncode2 = 'SP1802' and
             ft.endtime >= to_char(add_months(trunc(sysdate), -1),'yyyy/MM/dd')))
         and nvl(ba.putoutflag, '1') = '1'
         and ba.serialno <> pi_ba_serial_no
         and ci.certid = pi_cert_id
         order by ba.inputdate desc) fc
         where rownum=1;
    exception
      when no_data_found then
        v_main_reason_code := '';
    end;

    if v_main_reason_code is not null then
      if v_main_reason_code = 'SP12' or v_main_reason_code = 'SP13' or
         v_main_reason_code = 'SP29' then
        po_reject_reason := '客户前次因“提供虚假资料/疑欺诈申请”，拒绝申请';
      elsif v_main_reason_code = 'SP14' then
        po_reject_reason := '客户前次因“信息不真实”，拒绝申请';
      elsif v_main_reason_code = 'SP18' then
        po_reject_reason := '客户前次因“信息无法核实-客户身份信息难于核实”，拒绝申请';
      end if;
    end if;
  end sp_has_reject_his;

  /*
  * 申请阶段自动审批处理
  */
  procedure sp_ba_apply_auto_reject(pi_ba_serial_no  in varchar2, -- 申请编号
                                    pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2) is -- 拒绝原因
  po_reject_reason_zhongjian varchar2(2000):='';
  begin
    /*if po_reject_reason is null then
      sp_has_apply_info(pi_ba_serial_no, pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;*/
    if po_reject_reason is null then
      sp_has_overdure_his(pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    /*if po_reject_reason is null then
      sp_is_in_black_list(pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;*/
    if po_reject_reason is null then
      sp_has_reject_his(pi_ba_serial_no, pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    po_reject_reason :=po_reject_reason_zhongjian;

  end sp_ba_apply_auto_reject;
/*
"客户手机与系统内其他申请客户的手机号码/其他客户联系人的手机号码相同；
匹配出的人非客户所填的配偶；"

*/
  procedure sp_cust_info_unverifiable(pi_ba_serial_no  in varchar2,
                                      po_reject_reason out varchar2) is
    v_spouse_sql  varchar2(2000) := '';
    v_contact_sql clob := '';
    v_sql         clob := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
  begin
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户配偶的电话和名字
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, business_apply ba' ||
                       ' where cr.customerid = ba.customerid and cr.relation'||v_suffix||' = ''0301''' ||
                       ' and ba.serialno = ''' || pi_ba_serial_no || '''';
    --匹配当前客户与其他客户联系人 电话号码相同，名字不同
     v_contact_sql := v_contact_sql ||
                       ' union all select cr.mobile' || v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, business_apply ba, ind_info ii' ||
                       ' where ba.customerid = ii.customerid and cr.mobile'||v_suffix||'  = ii.mobiletelephone' ||
                       ' and cr.fullname'||v_suffix||'  <> ii.fullname and ba.serialno = ''' ||
                       pi_ba_serial_no || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的电话号码相同，名字不同
    v_contact_sql := v_contact_sql ||
                     ' union all select ii2.mobiletelephone, ii2.fullname' ||
                     ' from business_apply ba, ind_info ii1, ind_info ii2' ||
                     ' where ba.customerid = ii1.customerid and ba.customerid <> ii2.customerid' ||
                     ' and ii1.mobiletelephone = ii2.mobiletelephone and ii1.fullname <> ii2.fullname' ||
                     ' and ba.serialno = ''' || pi_ba_serial_no || '''';
    v_contact_sql := substr(v_contact_sql, 12);

    v_sql := 'select count(0) from  (' || v_spouse_sql || ')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql := 'select count(0) from (' || v_spouse_sql || ') t1, (' ||
               v_contact_sql || ') t2 ' ||
               'where (t1.mobile <> t2.mobile) or (t1.mobile = t2.mobile and t1.fullname <> t2.fullname)';
    else
      v_sql := 'select count(0) from (' || v_contact_sql || ')';
    end if;

    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      po_reject_reason := '信息无法核实，拒绝提交审批';
    end if;
    --po_reject_reason := v_sql;
  end sp_cust_info_unverifiable;

/*
客户（“每月基本薪金”+"其他收入"）小于3000，拒绝。

*/
  procedure sp_salary_toolittle(pi_ba_serial_no  in varchar2,
                                      po_reject_reason out varchar2) is
    v_sql         varchar2(2000) := '';
    v_count       int := 0;
  begin
    v_sql:='select sum(nvl(cw.salary,0))+sum(nvl(cw.other_earn,0)) from customer_work cw where cw.objectno='''||pi_ba_serial_no||'''';

    execute immediate v_sql
      into v_count;
    if v_count < 3000 then
      po_reject_reason := '工资小于3000，拒绝提交审批';
    end if;
    exception
      when no_data_found then
        po_reject_reason := '';
  end sp_salary_toolittle;

/*
房时贷产品
"受薪客户：客户“成立时间”距离申请时间小于6个月（按日计算）；
私营业主：客户“起始服务时间”距离申请时间小于6个月（按日计算）；"
*/
  procedure sp_intime_tooshort(pi_ba_serial_no  in varchar2,
                               po_reject_reason out varchar2) is
    v_sql         varchar2(2000) := '';
    v_isprivate   varchar2(2000) := '';
    v_count       number(10,2) := 0;
    s_isprivate   varchar2(2) :='';
  begin
    v_sql:='select months_between(to_date(ba.inputdate,''yyyy/mm/dd''),to_date(cw.start_date,''yyyy/mm/dd'')) '
    ||' from customer_work cw,business_apply ba where cw.objectno=ba.serialno and cw.start_date is not null and '
    ||' cw.customerid=ba.customerid and ba.serialno='''||pi_ba_serial_no||''' and instr(ba.BUSINESSTYPENAME,''房抵保'')=1 '
    ||' union select months_between(to_date(ba.inputdate,''yyyy/mm/dd''),to_date(cw.setupdate,''yyyy/mm/dd'')) '
    ||' from customer_work cw,business_apply ba where cw.objectno=ba.serialno and cw.setupdate is not null and '
    ||' cw.customerid=ba.customerid and ba.serialno='''||pi_ba_serial_no||'''';
    execute immediate v_sql
      into v_count;
    v_isprivate := 'select cw.isprivateowner from customer_work cw where cw.objectno='''||pi_ba_serial_no||'''';
    execute immediate v_isprivate
      into s_isprivate;
    if s_isprivate ='1' then
      if v_count<6 then
         po_reject_reason := '私营业主：客户“成立时间”距离申请时间小于6个月,拒绝申请';
      end if;
    elsif s_isprivate='2' then
      if v_count<6 then
        po_reject_reason := '受薪客户：客户“起始服务时间”距离申请时间小于6个月,拒绝申请';
      end if;
    end if;
    exception
      when no_data_found then
        po_reject_reason := '';
  end sp_intime_tooshort;

/*
"客户年龄小于22周岁或大于55周岁（按日计算）"
*/
  procedure sp_age_tooyoung(pi_cert_id       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_card21      varchar2(10);
    n_card55      varchar2(10);
    n_nowyear     varchar2(10);
  begin
    if pi_cert_id is null then
      po_reject_reason := '';
    else
     n_card21 := substr(pi_cert_id,7,4)+21||substr(pi_cert_id,11,4);
     n_card55 := substr(pi_cert_id,7,4)+56||substr(pi_cert_id,11,4);
     select to_char(sysdate,'yyyymmdd') into n_nowyear from dual;

      if n_card21 > n_nowyear then
           po_reject_reason := '客户年龄小于21周岁，拒绝申请';
      end if;
      if n_card55 < n_nowyear then
          po_reject_reason := '客户年龄大于55周岁，拒绝申请';
      end if;
    end if;
    exception
      when no_data_found then
        po_reject_reason := '';
  end sp_age_tooyoung;

/*
车主贷客户，全款车，二手车过户未满6个月
*/
  procedure sp_oldcar_tooShort(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_num   number(10,6);
  begin
    select months_between(to_date(ba.inputdate,'yyyy/MM/dd'),to_date(cv.TRANSFERTIME,'yyyy/MM/dd')) into n_num from business_apply ba,customer_vehicle cv where ba.serialno=pi_ba_serial_no and cv.isusedcar='1' and cv.cartype='01' and instr(getbusinessname(ba.businesstype),'车主保')<>0 and cv.customerid=ba.customerid;
    if n_num<6 then
      po_reject_reason := '车主保客户，二手车过户未满6个月,自动拒绝';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_oldcar_tooShort;

  /*
车主贷客户，按揭车，购车价值不符合要求
*/
  procedure sp_car_toolittle(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_num   number(20,6);
    v_isusedcar varchar2(20);
  begin
    select cv.purchasesum,cv.isusedcar into n_num,v_isusedcar from business_apply ba,customer_vehicle cv where ba.serialno=pi_ba_serial_no and cv.cartype='02' and instr(getbusinessname(ba.businesstype),'车主保')<>0 and cv.customerid=ba.customerid;
    if v_isusedcar='1' and n_num<100000 then
      po_reject_reason := '车主保客户，按揭二手车：购车价不应小于100000';
    elsif v_isusedcar<>'1' and n_num<50000 then
      po_reject_reason := '车主保客户，按揭一手车：购车价不应小于50000';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_car_toolittle;

   /*
车主贷客户，按揭车：购置时间不符合要求
*/
  procedure sp_car_tooShort(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_num   number(20,6);
    v_isusedcar varchar2(20);
  begin
    select months_between(to_date(ba.inputdate,'yyyy/MM/dd'),to_date(cv.PURCHASEDATE,'yyyy/MM/dd')),cv.isusedcar into n_num,v_isusedcar from business_apply ba,customer_vehicle cv where ba.serialno=pi_ba_serial_no and cv.cartype='02' and instr(getbusinessname(ba.businesstype),'车主保')<>0 and cv.customerid=ba.customerid;
    if v_isusedcar='1' and n_num<12 then
      po_reject_reason := '车主保客户，按揭二手车：购车时间需大于12个月';
    elsif v_isusedcar<>'1' and n_num<6 then
      po_reject_reason := '车主保客户，按揭一手车：购车时间需大于6个月';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_car_tooShort;
 /*
 经系统匹配，申请客户的联系人（包括配偶、亲属和其他联系人）中当前有逾期，申请人直接拒绝
 */
  procedure sp_relative_existsOverdue(pi_ba_serial_no       in varchar2, --客户申请号
                            pi_cert_id       in varchar2,-- 客户身份证信息
                            po_reject_reason out varchar2) is
   v_spouse_sql  varchar2(4000) := '';
    v_contact_sql varchar2(4000) := '';
    v_self_sql varchar2(4000):='';--找出自己的姓名和手机号
    --找出系统已有客户的联系人与当前申请客户的电话和姓名相同
    v_contact_self_sql varchar2(4000):='';
    v_sql         varchar2(4000) := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
    v_num         int := 0;
    v_fullname      varchar2(200);
    v_mobiletelephone varchar2(20);
  begin
    v_self_sql:='select ii.mobiletelephone,ii.fullname from ind_info ii where certid='''||pi_cert_id||'''';
    execute immediate v_self_sql into v_mobiletelephone,v_fullname;
    v_contact_self_sql:=' SELECT customerid FROM customer_relative UNPIVOT'||
                        ' ((mob,fulname) FOR (mob1,fullname) IN ((mobile,fullname),'||
                        ' (mobile1,fullname1),(mobile2,fullname2),(mobile3,fullname3),'||
                        ' (mobile4,fullname4),(mobile5,fullname5),(mobile6,fullname6),'||
                        '(mobile7,fullname7),(mobile8,fullname8),(mobile9,fullname9)) )'||
                        ' WHERE  MOB ='''||v_mobiletelephone||''' and fulname='''||v_fullname||'''';
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户联系人和电话
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, business_apply ba' ||
                       ' where cr.customerid = ba.customerid ' ||
                       ' and ba.serialno = ''' || pi_ba_serial_no || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的当前客户联系人和电话对应的客户id
    v_contact_sql := v_contact_sql ||
                     ' select ii2.customerid ' ||
                     ' from ind_info ii2 , (' ||v_spouse_sql || ') t1 '||
                     ' where ii2.mobiletelephone=t1.mobile and ii2.fullname=t1.fullname '
                   || ' union all '||v_contact_self_sql;
    v_sql := 'select count(0) from (' || v_contact_sql || ')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql := 'select nvl(sum(al.overduedays),0) from acct_loan al where customerid in ('||v_contact_sql||')';
      execute immediate v_sql
      into v_num;
      if v_num>0 then
        po_reject_reason := '申请客户的联系人（包括配偶、亲属和其他联系人）中当前有逾期,拒绝审批';
      else po_reject_reason := '';
      end if;
    else
      po_reject_reason := '';
    end if;
  end sp_relative_existsOverdue;

  /*
 经系统匹配，申请客户的配偶和亲属中1年之内有30+逾期的，申请人直接拒绝。
 */
  procedure sp_relative_exists31Overdue(pi_ba_serial_no       in varchar2, --客户申请号
                            pi_cert_id       in varchar2,-- 客户身份证信息
                            po_reject_reason out varchar2) is
   v_spouse_sql  varchar2(4000) := '';
    v_contact_sql varchar2(4000) := '';
    v_self_sql varchar2(4000):='';--找出自己的姓名和手机号
    --找出系统已有客户的联系人与当前申请客户的电话和姓名相同
    v_contact_self_sql varchar2(4000):='';
    v_sql         varchar2(4000) := '';
    v_sql2         varchar2(4000) := '';
    v_sql3         varchar2(4000) := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
    v_num         int := 0;
    v_fullname      varchar2(200);
    v_mobiletelephone varchar2(20);
  begin
    v_self_sql:='select ii.mobiletelephone,ii.fullname from ind_info ii where certid='''||pi_cert_id||'''';
    execute immediate v_self_sql into v_mobiletelephone,v_fullname;
    v_contact_self_sql:=' SELECT customerid FROM customer_relative UNPIVOT '||
                        ' ((mob,fulname,reltion) FOR (mob1,fullname,relation) IN ((mobile,fullname,relation),'||
                        ' (mobile1,fullname1,relation1),(mobile2,fullname2,relation2),(mobile3,fullname3,relation3),'||
                        ' (mobile4,fullname4,relation4),(mobile5,fullname5,relation5),(mobile6,fullname6,relation6),'||
                        '(mobile7,fullname7,relation7),(mobile8,fullname8,relation8),(mobile9,fullname9,relation9)) )'||
                        ' WHERE  MOB ='''||v_mobiletelephone||''' and fulname='''||v_fullname||''' and  '||
                        ' reltion in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')';
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户联系人和电话
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, business_apply ba' ||
                       ' where cr.customerid = ba.customerid  and cr.RELATION'||v_suffix ||
                       ' in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')'||
                       ' and ba.serialno = ''' || pi_ba_serial_no || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的当前客户联系人和电话对应的客户id
    v_contact_sql := v_contact_sql ||
                     ' select ii2.customerid ' ||
                     ' from ind_info ii2 , (' ||v_spouse_sql || ') t1 '||
                     ' where ii2.mobiletelephone=t1.mobile and ii2.fullname=t1.fullname '||
                     ' union all '||v_contact_self_sql;
    v_sql := 'select count(0) from (' || v_contact_sql || ')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql2 := 'select 1 from acct_payment_schedule aps where aps.paydate<to_char(sysdate,''yyyy/MM/dd'')'||
      ' and aps.paydate >to_char(sysdate,''yyyy'')-1||substr(to_char(sysdate,''yyyy/mm/dd''),5) and '||
      ' aps.objectno in (select al.serialno from acct_loan al where al.customerid in ('||v_contact_sql||'))'||
      ' and to_date(nvl(aps.finishdate,to_char(sysdate,''yyyy/MM/dd'')),''yyyy/MM/dd'')-to_date(aps.paydate,''yyyy/MM/dd'')>30';
      v_sql3 := 'select count(0) from (' || v_sql2 || ')';
      execute immediate v_sql3
      into v_num;
      if v_num>0 then
        po_reject_reason := '经系统匹配，申请客户的配偶和亲属中1年之内有30天以上的逾期，申请人直接拒绝';
      else po_reject_reason := '';
      end if;
    else
      po_reject_reason := '';
    end if;
  end sp_relative_exists31Overdue;

   /*
 经系统匹配，申请客户的配偶和亲属中在最近的三个月内有放款的，申请人直接拒绝（判断时间精确到日）。
 */
  procedure sp_relative_exists3MPutOut(pi_ba_serial_no       in varchar2, --客户申请号
                            pi_cert_id       in varchar2,-- 客户身份证信息
                            po_reject_reason out varchar2) is
   v_spouse_sql  varchar2(3000) := '';
    v_contact_sql varchar2(4000) := '';
    v_self_sql varchar2(4000):='';--找出自己的姓名和手机号
    --找出系统已有客户的联系人与当前申请客户的电话和姓名相同
    v_contact_self_sql varchar2(4000):='';
    v_sql         varchar2(4000) := '';
    v_sql2         varchar2(4000) := '';
    v_sql3         varchar2(4000) := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
    v_num         int := 0;
    v_fullname      varchar2(200);
    v_mobiletelephone varchar2(200);
  begin
    v_self_sql:='select ii.mobiletelephone,ii.fullname from ind_info ii where certid='''||pi_cert_id||'''';
    execute immediate v_self_sql into v_mobiletelephone,v_fullname;
    v_contact_self_sql:=' SELECT customerid FROM customer_relative UNPIVOT '||
                        ' ((mob,fulname,reltion) FOR (mob1,fullname,relation) IN ((mobile,fullname,relation),'||
                        ' (mobile1,fullname1,relation1),(mobile2,fullname2,relation2),(mobile3,fullname3,relation3),'||
                        ' (mobile4,fullname4,relation4),(mobile5,fullname5,relation5),(mobile6,fullname6,relation6),'||
                        '(mobile7,fullname7,relation7),(mobile8,fullname8,relation8),(mobile9,fullname9,relation9)) )'||
                        ' WHERE  MOB ='''||v_mobiletelephone||''' and fulname='''||v_fullname||''' and  '||
                        ' reltion in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')';
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户联系人和电话
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, business_apply ba' ||
                       ' where cr.customerid = ba.customerid  and cr.RELATION'||v_suffix ||
                       ' in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')'||
                       ' and ba.serialno = ''' || pi_ba_serial_no || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的当前客户联系人和电话对应的客户id
    v_contact_sql := v_contact_sql ||
                     ' select ii2.customerid ' ||
                     ' from ind_info ii2 , (' ||v_spouse_sql || ') t1 '||
                     ' where ii2.mobiletelephone=t1.mobile and ii2.fullname=t1.fullname '||
                     ' union all '||v_contact_self_sql;
    v_sql := 'select count(0) from (' || v_contact_sql||')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql2 := 'select 1 from acct_loan where customerid in ('||v_contact_sql||') and months_between(sysdate,to_date(putoutdate,''yyyy/MM/dd''))<=3';
      v_sql3 := 'select count(0) from (' || v_sql2 || ')';
      execute immediate v_sql3
      into v_num;
      if v_num>0 then
        po_reject_reason := '经系统匹配，申请客户的配偶和亲属中在最近的三个月内有放款的，申请人直接拒绝';
      else po_reject_reason := '';
      end if;
    else
      po_reject_reason := '';
    end if;
  end sp_relative_exists3MPutOut;

  /*
薪金贷现金发薪且户籍地与申请地城市不一致，拒绝

*/
  procedure sp_salary_isnative(pi_ba_serial_no  in varchar2,
                                      po_reject_reason out varchar2) is
    v_sql         varchar2(2000) := '';
    v_NATIVECITY  varchar2(200) := '';
    v_cityname  varchar2(200) := '';
    v_index int:=0;
  begin
    v_sql:='select case when ii.NATIVECITY in (''110100'',''110200'',''120100'',''120200'',''310100'',''310200'',''500100'',''500200'',''500300'')'||
    ' then getItemName(''AreaCodeP'',ii.NATIVEPROVINCE) else '||
    ' getItemName(''AreaCodeC'',ii.NATIVECITY) end,GetCityNameFromOrgName(ba.inputorgid) '||
    ' from customer_work cw,ind_info ii,business_apply ba where '||
    ' ii.customerid = cw.customerid and ba.customerid=ii.customerid and instr(getBusinessName(ba.businesstype),''薪金保'')=1 '||
    ' and cw.PAYMENT_TYPE=''0020'' and ba.serialno=cw.objectno and ba.serialno='''||pi_ba_serial_no||'''';

    execute immediate v_sql
      into v_NATIVECITY,v_cityname;
    select instr(v_NATIVECITY,v_cityname) into v_index from dual;
    if v_index<>1 then
      po_reject_reason := '薪金保现金发薪且户籍地与申请地城市不一致，拒绝';
    end if;
    exception
      when no_data_found then
        po_reject_reason := '';
  end sp_salary_isnative;

/*
大数客户，保单贷，保单生效日期小于2年
*/
  procedure sp_dsbaodan_tooShort(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_num   number(10,6);
  begin
    select months_between(to_date(ba.inputdate,'yyyy/MM/dd'),to_date(cl.POLICYOPDATE,'yyyy/MM/dd')) into n_num from business_apply ba,CUSTOMER_LIFEINSURANCE cl where ba.serialno=pi_ba_serial_no and cl.ISINUSE='1' and ba.businesssubtype='sbt002' and instr(getbusinessname(ba.businesstype),'远见保')<>0 and cl.objectno=ba.serialno;
    if n_num<24 then
      po_reject_reason := '大数客户，保单贷保单生效日期小于2年,自动拒绝';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_dsbaodan_tooShort;

/*
大数客户，车供贷，车贷日期小于6个月
*/
  procedure sp_dschegong_tooShort(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_num   number(10,6);
  begin
    select months_between(to_date(ba.inputdate,'yyyy/MM/dd'),to_date(cv.carstartdate,'yyyy/MM/dd')) into n_num from business_apply ba,customer_vehicle cv where ba.serialno=pi_ba_serial_no and ba.businesssubtype='sbt003' and instr(getbusinessname(ba.businesstype),'远见保')<>0 and cv.customerid=ba.customerid;
    if n_num<6 then
      po_reject_reason := '大数客户，车供贷车贷日期小于6个月,自动拒绝';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_dschegong_tooShort;

/*
大数客户，房供贷，房贷已还款期数小于6期
*/
  procedure sp_dsfanggong_tooShort(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    n_num   number(10,6);
  begin
    select cr.houseLoanYetTime into n_num from business_apply ba,customer_realty cr where ba.serialno=pi_ba_serial_no and ba.businesssubtype='sbt001' and instr(getbusinessname(ba.businesstype),'远见保')<>0 and cr.customerid=ba.customerid;
    if n_num<6 then
      po_reject_reason := '大数客户，房供贷房贷已还款期数小于6期,自动拒绝';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_dsfanggong_tooShort;

/*
大数客户，超分贷，风险等级必须为超高分
*/
  procedure sp_dschaofen_tooShort(pi_ba_serial_no       in varchar2, -- 客户身份证信息
                            po_reject_reason out varchar2) is
    level  varchar2(10);
  begin
    select riskLevel into level from business_apply ba where ba.serialno=pi_ba_serial_no and ba.businesssubtype='sbt005' and instr(getbusinessname(ba.businesstype),'远见保')<>0 ;
    if level!='rl001' then
      po_reject_reason := '大数客户，超分贷风险等级不为超高分,自动拒绝';
    end if;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
       po_reject_reason :='';
  WHEN OTHERS THEN
       po_reject_reason :='';
  end sp_dschaofen_tooShort;


  /**
  * 质检审批阶段自动拒绝处理
  */
  procedure sp_ba_audit_auto_reject(pi_ba_serial_no  in varchar2, -- 申请编号
                                    pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2) is -- 拒绝原因
  po_reject_reason_zhongjian varchar2(2000):='';
  begin
    /*if po_reject_reason is null then
      sp_cust_info_unverifiable(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;*/
    if po_reject_reason is null then
      sp_salary_toolittle(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_intime_tooshort(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_age_tooyoung(pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_oldcar_tooShort(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_car_toolittle(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
   /* if po_reject_reason is null then
      sp_car_tooShort(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;*/
    if po_reject_reason is null then
      sp_relative_existsOverdue(pi_ba_serial_no,pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_relative_exists31Overdue(pi_ba_serial_no,pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_relative_exists3MPutOut(pi_ba_serial_no, pi_cert_id,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_salary_isnative(pi_ba_serial_no,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    po_reject_reason :=po_reject_reason_zhongjian;
  end sp_ba_audit_auto_reject;

/**
 * 复核阶段自动拒绝
**/
procedure sp_ba_audit_auto_reject_for_gd(pi_ba_serial_no  in varchar2, -- 申请编号
                                    pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2) is -- 拒绝原因
  po_reject_reason_zhongjian varchar2(2000):='';
  begin
    if po_reject_reason is null then
      sp_salary_isnative(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_salary_toolittle(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_intime_tooshort(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_oldcar_tooShort(pi_ba_serial_no, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_relative_existsOverdue(pi_ba_serial_no,pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_relative_exists31Overdue(pi_ba_serial_no,pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_relative_exists3MPutOut(pi_ba_serial_no, pi_cert_id,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
     if po_reject_reason is null then
      sp_dsbaodan_tooShort(pi_ba_serial_no,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
     if po_reject_reason is null then
      sp_dschegong_tooShort(pi_ba_serial_no,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
     if po_reject_reason is null then
      sp_dsfanggong_tooShort(pi_ba_serial_no,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
     if po_reject_reason is null then
      sp_dschaofen_tooShort(pi_ba_serial_no,po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    po_reject_reason :=po_reject_reason_zhongjian;
  end sp_ba_audit_auto_reject_for_gd;
end pk_ba_auto_reject;
/

