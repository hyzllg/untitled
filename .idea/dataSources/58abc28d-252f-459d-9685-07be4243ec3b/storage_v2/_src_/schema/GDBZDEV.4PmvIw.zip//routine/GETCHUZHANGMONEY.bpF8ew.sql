create function GetChuZhangMoney(ACTUALPAYDATEArg in varchar2,seqidArg in number,loanserialnoArg in varchar2)
--获得出账金额
return number
is
  outmoney number(24,7);
begin
  select sum(nvl(actualpaycorpusamt, 0) +
           nvl(actualpayinteamt, 0) + nvl(actualfineamt, 0) +
           nvl(actualcompdinteamt, 0) +
           nvl(actualpayfeeamt1, 0) +
           nvl(actualpayfeeamt2, 0) +
           nvl(actualpayfeeamt3, 0) +
           nvl(actualpayfeeamt4, 0) +
           nvl(actualpayfeeamt5, 0) +
           nvl(actualpayfeeamt6, 0) +
           nvl(actualexpiationsum, 0)) into outmoney from acct_back_detail_back where ACTUALPAYDATE=ACTUALPAYDATEArg and seqid=seqidArg and LOANSERIALNO=loanserialnoArg and backinputdate=(to_char(trunc(sysdate-1),'yyyy/mm/dd')) group by seqidArg,loanserialnoArg;
  return outmoney;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetChuZhangMoney;
/

