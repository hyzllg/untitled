create package body testpackage is
  /*
  * 检查客户是否有在途申请
  */
  procedure testprocedure(a  in varchar2 ) is
    v_count int := 0;
  begin
    select count(*)
      into v_count
      from dual;

    if v_count > 0 then
      po_reject_reason := '该客户有在途申请，拒绝申请';
    end if;
  end testprocedure;
 end testpackage;
/

