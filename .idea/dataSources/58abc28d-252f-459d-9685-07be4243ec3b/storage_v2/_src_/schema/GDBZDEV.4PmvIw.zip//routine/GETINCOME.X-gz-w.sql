create FUNCTION GETINCOME-THEOAMT-BUSINESSSUM(serialnoArg varchar2)
RETURN SYS_REFCURSOR
        is
               type_cur SYS_REFCURSOR;
        BEGIN
            OPEN type_cur FOR
                     select autocount,COUNTBUSINESSSUM,businesssum from flow_opinion where serialno =
(select max(serialno) from flow_opinion where phaseno in('0040','0035','0030','0045','0047') and objectno = serialnoArg);
        RETURN  type_cur;
        END;

/

