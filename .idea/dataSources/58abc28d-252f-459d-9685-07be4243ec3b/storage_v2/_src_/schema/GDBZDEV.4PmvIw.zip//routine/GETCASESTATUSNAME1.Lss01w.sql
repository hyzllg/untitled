create FUNCTION getCaseStatusName1(phaseno varchar)
--获取案件最新状态
return varchar
is sStatusName varchar(200);
begin
   select case
               when phaseno in ('0030','0035','0040','0045','0047') then '中央审批中'
               when phaseno in ('3093','3094','2040','3020','3021') then '审批拒绝'
               else getitemname('TeleCurrentStatus',phaseno)
          end
          into sStatusName from dual;
   if sStatusName is not null then
      return sStatusName;
   else
       return '';
   end if;
end;
/

