create FUNCTION getrecovery(serialnoArs varchar2)
return number
is amount  number(24,2);
begin
  select sum(nvl(BACKOFFERSUM,0)) into amount
	from BankSubrogationBack
	where dueBillNo=serialnoArs and status='0';
	return amount;
end;
/

