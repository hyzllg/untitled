create Function         checkLoanPlusRule6 ( pCertID IN varchar2 ) RETURN varchar2
IS
     ret varchar2(10);
     ICount number(6);
     IMonthBtw number(10);
     DXSerialNo varchar2(20);
     sMAXPhaseno varchar2(20);
     sOrderDate varchar2(20);
     sEndtime varchar2(20);
BEGIN
     select count(1) into ICount
     from acct_loan al,customer_info ci,business_type bt,acct_payment_schedule aps,business_apply ba
     where al.CUSTOMERID=ci.customerid
       and al.businesstype=bt.typeno
       and aps.objectno=al.serialno
       and al.baserialno=ba.serialno

     --6.客户不在拒绝限制时效内
      and
      (
          (select count(1) from customer_info cii where cii.certid=ci.certid) = 0
          or not exists
          (
          select 1
          from flow_opinion fo, business_apply bt, customer_info cinfo,reason_param rp
          where fo.objectno = bt.serialno
            and fo.phaseno= rp.phaseno
            and fo.reasoncode1=rp.mainreasoncode
            and nvl(fo.reasoncode2,'kong')=nvl(rp.subreasoncode,'kong')
            and bt.customerid=cinfo.customerid
            and cinfo.certid = ci.certid
            and fo.opinionno in (select max(opinionno) from flow_opinion where objectno=bt.serialno)
            and fo.phaseno in (select phaseno from flow_task where flow_task.flowno='CreditFlow' and serialno=(select ft.relativeserialno from flow_task ft where ft.flowno='CreditFlow' and phasetype in ('2000','3000') and ft.objectno=bt.serialno and ft.serialno=(SELECT MAX(ft3.SERIALNO) FROM FLOW_TASK ft3  WHERE bt.SerialNo = ft3.OBJECTNO AND ft3.flowNo='CreditFlow')))
            and (select months_between(trunc(sysdate),max(to_date(ba.inputdate,'yyyy/MM/dd'))) as days from business_apply ba where ba.serialno=bt.serialno group by serialno)-rp.limitday >= 0
          )
      )
     and checkTelsSalesDateLimit(ci.CERTID)='LOVE'
     and ci.certid=pCertID;

     IF ICount=0 THEN
        ret := 'Betray';
     ELSE
        ret := 'LOVE';
     END IF;
     RETURN ret;
END;

/

