create FUNCTION GETCHECKROLEID(pSerialno varchar2,pPhaseno varchar2)
--获取远程面签流程操作人ID
return varchar2
is sobjectno varchar2(40);
begin
   select max(ft.objectno) into sobjectno
   from flow_task ft,user_role ur
   where ft.serialno=(select serialno from (select serialno from flow_task
       where  objectno=pSerialno and phaseno=pPhaseno and endtime is not null
       order by begintime desc
       ) where rownum=1 ) and ft.userid=ur.userid and ur.status='1' and ur.roleid in ('261','262');
   return sobjectno;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

