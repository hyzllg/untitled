create FUNCTION GETORGMANAGER (pSerialno varchar)
return varchar2
is pUsername varchar(20);
begin
select distinct ui.username into pUsername from user_role ur,user_info ui where ur.userid=ui.userid and ur.roleid='401' and ui.attribute3 like '%门店经理' AND UI.STATUS='1' AND UR.STATUS='1' and ui.belongorg=(select inputorgid from business_apply where serialno=pSerialno);
return (pUsername);
end;
/

