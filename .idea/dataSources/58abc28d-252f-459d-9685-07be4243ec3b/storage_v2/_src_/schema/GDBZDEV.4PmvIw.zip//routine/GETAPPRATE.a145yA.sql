create FUNCTION getapprate(pSerialNO varchar)
return varchar
is pAppRate varchar(80);
begin
select PREAPPROVERATE into pAppRate
from Creditaudittable
 where serialno = pSerialNO;
 return pAppRate;
end;
/

