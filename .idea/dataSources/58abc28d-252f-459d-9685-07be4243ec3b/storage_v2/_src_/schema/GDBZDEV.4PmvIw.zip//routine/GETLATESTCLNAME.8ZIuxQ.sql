create FUNCTION getLatestCLName(pCustomerID varchar2)
  return varchar2 is
  pChannel varchar2(80);
begin
  SELECT customersource into pChannel
    FROM business_apply ba
   where ba.serialno =
        (select max(ba.serialno)
            from business_apply ba
           WHERE ba.customerid = (SELECT max(customerid) FROM customer_info WHERE certid = pCustomerID));

   return pChannel;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end;
/

