create function getApproveMainReason(pSerialno in VARCHAR2)
--获得审批策略集拒绝的主原因
return VARCHAR2
IS MainReason VARCHAR2(50);
begin
   SELECT primarycause INTO MainReason FROM STRATEGYRESULT WHERE objecttype = 'CreditApply' AND objectno = pSerialno AND isfinalresult = '3';
	  return MainReason;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getApproveMainReason;
/

