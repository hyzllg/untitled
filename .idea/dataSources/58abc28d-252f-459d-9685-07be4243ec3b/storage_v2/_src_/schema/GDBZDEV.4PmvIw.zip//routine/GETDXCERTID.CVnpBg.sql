create function getDXCertID(sCertID in varchar2)
--电销身份证校验
 return number
 is
  nums  number;
  baserialnos varchar(32);

begin
  select baserialno into baserialnos from retail_sales_apply where serialno in (select max(rs.serialno)from retail_sales_apply rs where rs.creditid =sCertID );
  if  baserialnos is null then
      select count(1) into nums
       from flow_object fo
        where fo.objectno in (select max(serialno)
                         from retail_sales_apply
                        where creditid = sCertID)
                       and fo.phaseno in ('6001', '6002', '6003', '6004') ;
  else
    select count(1) into nums
        from flow_object fo, business_apply ba,retail_sales_apply rs
           where fo.objectno in (select max(serialno)
                             from retail_sales_apply
                             where creditid = sCertID)
                             and fo.phaseno = '6006'
                             and ba.phasetype='2000'
                             and rs.baserialno=ba.serialno
                             and rs.serialno=fo.objectno;
 end if;
 return(nums);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getDXCertID;
/

