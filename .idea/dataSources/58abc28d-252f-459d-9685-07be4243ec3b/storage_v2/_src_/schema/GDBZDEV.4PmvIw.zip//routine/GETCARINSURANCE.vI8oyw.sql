create function getCARINSURANCE(CustomeridArg in varchar2) return varchar2
--车险
is
  cursor cur_m is select getitemname('CarInsurance',CARINSURANCE) as CARINSURANCE from CUSTOMER_VEHICLE where customerid = customeridArg order by serialno;
  purchasesums varchar2(400);
begin
  for cur_r in cur_m
    loop
       purchasesums:=cur_r.CARINSURANCE||' ;'||purchasesums;
       end loop;
  return(purchasesums);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getCARINSURANCE;
/

