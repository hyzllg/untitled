create function GETCANCELTIME(serialnoArg in varchar2)
--获取取消日期
return varchar2
is canceltime  varchar2(20) ;
   num number(1);
begin
select count(1) into num
  from flow_task ft
 where ft.flowno = 'CreditFlow'
   and ft.phaseno in
       ('2020', '2010', '2070', '2050', '2000', '2060', '2030','2090','2095')
   and ft.objectno = serialnoArg;
   if num>0 then
       select substr(ft.EndTime, 1, 10)
         into canceltime
         from flow_task ft
        where ft.flowno = 'CreditFlow'
          and ft.phaseno in
              ('2020', '2010', '2070', '2050', '2000', '2060', '2030','2090','2095')
          and ft.objectno = serialnoArg;

   else
     select substr(max(a.updatedate),1,10) into canceltime from ApplyPolicyNo a where a.status='4' and

a.applyno=serialnoArg and exists(select 1 from business_apply b where b.putoutflag='5' and

b.serialno=a.applyno) ;
   end if;
  return canceltime;
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GETCANCELTIME;
/

