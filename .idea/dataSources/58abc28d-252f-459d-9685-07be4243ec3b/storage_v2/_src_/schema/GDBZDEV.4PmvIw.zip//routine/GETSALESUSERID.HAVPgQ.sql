create FUNCTION getsalesuserid(pSerialnoID varchar)
return varchar is 
   pSalesuserName varchar2(80);
   pSalesuserID  varchar2(80);
begin
select SalesuserName into pSalesuserName from business_apply where serialno = pSerialnoID;
select (case when nvl(SalesuserID,0)=0 then (select userid from user_info where username=pSalesuserName) else SalesuserID end ) into pSalesuserID
  from business_apply
where serialno = pSerialnoID;
  return pSalesuserID;
end;
/

