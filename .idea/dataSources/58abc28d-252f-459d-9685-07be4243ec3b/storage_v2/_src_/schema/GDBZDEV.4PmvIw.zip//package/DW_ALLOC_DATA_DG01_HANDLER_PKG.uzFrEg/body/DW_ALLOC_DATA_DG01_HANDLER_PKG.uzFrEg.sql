create PACKAGE BODY dw_alloc_data_dg01_handler_pkg IS
   c_package_name          CONSTANT VARCHAR2(300) := 'DW_ALLOC_DATA_DG01_HANDLER_PKG';
   c_hpm_schema            CONSTANT VARCHAR2(300) := 'GDBZDEV';
   c_hpm_table             CONSTANT VARCHAR2(300) := 'HPM_LEDGER_STAT';
   c_hpm_achieve_table     CONSTANT VARCHAR2(300) := 'HPM_LEDGER_STAT_ARCHIVE';

/*=========================================
一.待摊数据维度维值处理
=========================================*/
   --1.oracle财务系统待摊处理
   PROCEDURE pre_alloc_financial_sys(x_return_status        OUT VARCHAR2,
                                     p_plan_node_control_id NUMBER,
                                     p_period_name          VARCHAR2,
                                     p_ledger_id            NUMBER) IS
      l_procedure_name        VARCHAR2(300) := 'pre_alloc_financial_sys(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' || 'p_ledger_id => ''' ||
                                             p_ledger_id || '''' || ''',' ||
                                             'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
      l_stage                 VARCHAR2(300);
      l_execute_begining_date DATE := SYSDATE;
      l_bxsr_value            NUMBER;
      l_sjfj_value            NUMBER;
    BEGIN
      dw_util_pkg.log_infor('开始生成DW_PREALLOCATE_GD_FS数据'
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);

      -- 清除数据
      l_stage := '清除已生成数据';
      dw_util_pkg.log_infor(l_stage
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);
      dw_util_pkg.truncate_table(c_hpm_schema
                                ,'DW_PREALLOCATE_GD_FS');

      -- 开启并发
      dw_util_pkg.enable_session_parallel(2);

      -- 生成数据
      l_stage := '生成总账数据';
      dw_util_pkg.log_infor(l_stage
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);
        dbms_output.put_line('0'); 
        INSERT INTO DW_PREALLOCATE_GD_FST
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount  )
        --总账数据
        WITH F AS (SELECT DISTINCT t.src_account_code, t.f_flag FROM DIS_MT_C_GD_O_IDENTIFIER t)
        SELECT  p_period_name          AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F100010'
                   WHEN fier.f_flag ='N' THEN 'F100011' END) AS alloc_flag,
                ''                     AS sales_type,
                nvl((SELECT t.des_company_code  
                       FROM dis_mt_c_gd_com_o_c_mapping t 
                      WHERE t.src_company_code = fs.company_code), fs.company_code) AS company_code,
                fs.account_code        AS account_code       ,
                fs.department_code     AS department_code    ,
                fs.subaccount_code     AS subaccount_code    ,
                fs.product_code        AS product_code       ,
                fs.channel_code        AS channel_code       ,
                fs.intcom_code         AS intcom_code        ,
                ''                     AS budgetaccount_code ,
                /*nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = fs.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = fs.company_code
                 ), 0)*/''             AS area1_code         ,
                /*nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = fs.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = fs.company_code
                 ), 0)*/''              AS area2_code         ,
                 ''                     AS putout_mob         ,
                 ''/*nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = fs.company_code), 0)*/ AS depart_mob,
           
                 ''/*nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = fs.company_code), 0)*/ AS story_mob,
                 ''                    AS putoutno           ,
                 fs.ptd_amount         AS ptd_amount         ,
                 fs.ytd_amount         AS ytd_amount         ,
                 fs.attribute1         AS attribute1         ,
                 fs.attribute2         AS attribute2         ,
                 fs.attribute3         AS attribute3         ,
                 fs.attribute4         AS attribute4         ,
                 fs.attribute5         AS attribute5         ,
                 fs.attribute6         AS attribute6         ,
                 fs.attribute7         AS attribute7         ,
                 fs.attribute8         AS attribute8         ,
                 fs.attribute9         AS attribute9         ,
                 fs.attribute10        AS attribute10        ,
                 fs.attribute11        AS attribute11        ,
                 fs.attribute12        AS attribute12        ,
                 fs.attribute13        AS attribute13        ,
                 fs.attribute14        AS attribute14        ,
                 fs.attribute15        AS attribute15        ,
                 fs.attribute16        AS attribute16        ,
                 fs.attribute17        AS attribute17        ,
                 fs.attribute18        AS attribute18        ,
                 fs.attribute19        AS attribute19        ,
                 fs.attribute20        AS attribute20        ,
                 fs.w_insert_dt        AS w_insert_dt        ,
                 fs.w_update_dt        AS w_update_dt        ,
                 fs.year_begin_amount  AS year_begin_amount

          FROM DW_TRAILBALANCE_FS fs,
               F fier

         WHERE fs.ledger_id = '1002'
           AND fs.currency_code = 'CNY'
           AND fs.period_name = p_period_name
           AND fs.account_code = fier.src_account_code
           AND (fs.ptd_amount <> 0 OR fs.ytd_amount <>0);
         COMMIT;
         dbms_output.put_line('11'); 
         --预处理表处理逻辑（总账数据）再次处理
         /*dw_preallocate_gd_fs.company_code=dis_mt_c_gd_com_mapping.src_company_code,
           且dw_trailbalance_fs.department_code=dis_mt_c_gd_com_mapping.Src_department_code时
           将该机构维的code替换为dis_mt_c_gd_com_mapping.src_story_code*/
        /* INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        \*,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount*\  )
         SELECT p_period_name          AS period_name        ,
                fs.alloc_flag          AS alloc_flag         ,
                fs.sales_type          AS sales_type         ,
                nvl((SELECT m.src_story_code   
                       FROM dis_mt_c_gd_com_mapping m 
                      WHERE fs.company_code = m.src_company_code
                        AND fs.department_code = m.src_department_code), fs.company_code)        AS company_code       ,
                fs.account_code        AS account_code       ,
                fs.department_code     AS department_code    ,
                fs.subaccount_code     AS subaccount_code    ,
                fs.product_code        AS product_code       ,
                fs.channel_code        AS channel_code       ,
                fs.intcom_code         AS intcom_code        ,
                fs.budgetaccount_code  AS budgetaccount_code ,
                fs.area1_code          AS area1_code         ,
                fs.area2_code          AS area2_code         ,
                fs.putout_mob          AS putout_mob         ,
                fs.depart_mob          AS depart_mob         ,       
                fs.story_mob           AS story_mob          ,
                fs.putoutno            AS putoutno           ,
                 fs.ptd_amount         AS ptd_amount         ,
                 fs.ytd_amount         AS ytd_amount         ,
                 fs.attribute1         AS attribute1         ,
                 fs.attribute2         AS attribute2         ,
                 fs.attribute3         AS attribute3         ,
                 fs.attribute4         AS attribute4         ,
                 fs.attribute5         AS attribute5         ,
                 fs.attribute6         AS attribute6         ,
                 fs.attribute7         AS attribute7         ,
                 fs.attribute8         AS attribute8         ,
                 fs.attribute9         AS attribute9         ,
                 fs.attribute10        AS attribute10        ,
                 fs.attribute11        AS attribute11        ,
                 fs.attribute12        AS attribute12        ,
                 fs.attribute13        AS attribute13        ,
                 fs.attribute14        AS attribute14        ,
                 fs.attribute15        AS attribute15        ,
                 fs.attribute16        AS attribute16        ,
                 fs.attribute17        AS attribute17        ,
                 fs.attribute18        AS attribute18        ,
                 fs.attribute19        AS attribute19        ,
                 fs.attribute20        AS attribute20        \*,
                 fs.created_date       AS w_insert_dt        ,
                 fs.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount*\

          FROM DW_PREALLOCATE_GD_FS fs 
         WHERE fs.period_name = p_period_name;*/
         dbms_output.put_line('1'); 
         
         update DW_PREALLOCATE_GD_FST FS
            set FS.COMPANY_CODE = NVL((select M.SRC_STORY_CODE
                                         from DIS_MT_C_GD_COM_MAPPING M
                                        where FS.COMPANY_CODE =
                                              M.SRC_COMPANY_CODE
                                          and FS.DEPARTMENT_CODE =
                                              M.SRC_DEPARTMENT_CODE),
                                       FS.COMPANY_CODE)
          where FS.PERIOD_NAME = P_PERIOD_NAME;
          COMMIT;
           dbms_output.put_line('12'); 
         --处理mob
         INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount  )
        SELECT   period_name                                        ,
                 alloc_flag                   AS alloc_flag         ,
                 sales_type                   AS sales_type         ,
                 company_code                 AS company_code       ,
                 account_code                 AS account_code       ,
                 department_code              AS department_code    ,
                 subaccount_code              AS subaccount_code    ,
                 product_code                 AS product_code       ,
                 channel_code                 AS channel_code       ,
                 intcom_code                  AS intcom_code        ,
                 budgetaccount_code           AS budgetaccount_code ,
                (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = fst.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = fst.company_code
                 )      AS area1_code         ,
                (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = fst.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = fst.company_code
                 )      AS area2_code         ,
                 fst.putout_mob         AS putout_mob         ,
                 (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = fst.company_code) AS depart_mob,
           
                 (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = fst.company_code) AS story_mob,
                 fst.putoutno           AS putoutno           ,
                 fst.ptd_amount         AS ptd_amount         ,
                 fst.ytd_amount         AS ytd_amount         ,
                 fst.attribute1         AS attribute1         ,
                 fst.attribute2         AS attribute2         ,
                 fst.attribute3         AS attribute3         ,
                 fst.attribute4         AS attribute4         ,
                 fst.attribute5         AS attribute5         ,
                 fst.attribute6         AS attribute6         ,
                 fst.attribute7         AS attribute7         ,
                 fst.attribute8         AS attribute8         ,
                 fst.attribute9         AS attribute9         ,
                 fst.attribute10        AS attribute10        ,
                 fst.attribute11        AS attribute11        ,
                 fst.attribute12        AS attribute12        ,
                 fst.attribute13        AS attribute13        ,
                 fst.attribute14        AS attribute14        ,
                 fst.attribute15        AS attribute15        ,
                 fst.attribute16        AS attribute16        ,
                 fst.attribute17        AS attribute17        ,
                 fst.attribute18        AS attribute18        ,
                 fst.attribute19        AS attribute19        ,
                 fst.attribute20        AS attribute20        ,
                 fst.w_insert_dt        AS w_insert_dt        ,
                 fst.w_update_dt        AS w_update_dt        ,
                 fst.year_begin_amount  AS year_begin_amount

          FROM dw_preallocate_gd_fst fst;
         COMMIT;
          dbms_output.put_line('13');   
          
         --清理临时中间表
         EXECUTE IMMEDIATE 'truncate TABLE dw_preallocate_gd_fst';
          
         
         --1.待摊特殊处理逻辑（手工补录调整项（剔跟单）数据数据）
         l_stage := '1.待摊特殊处理逻辑（手工补录调整项（剔跟单）数据数据）';
         dw_util_pkg.log_infor(l_stage
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);
         --计算保费收入的sum(ptd), 和 税金及附加的sum(ptd)（保费收入代码：6032010101）
         BEGIN
           SELECT SUM(fs.ptd_amount) 
             INTO l_bxsr_value
             FROM DW_PREALLOCATE_GD_FS fs
            WHERE fs.account_code = '6032010101'
              AND fs.period_name = p_period_name;
           SELECT SUM(fs.ptd_amount) 
             INTO l_sjfj_value
             FROM DW_PREALLOCATE_GD_FS fs
            WHERE fs.account_code LIKE '6403%'
              AND fs.period_name = p_period_name;
         EXCEPTION
           WHEN OTHERS THEN
           dw_util_pkg.log_error(l_stage || '错误:' || SQLERRM
                                 ,p_plan_node_control_id
                                 ,c_package_name || '.' || l_procedure_name);  
         END;
         dbms_output.put_line('40');
         l_stage := '1.待摊特殊处理逻辑（手工补录调整项（剔跟单）数据数据）';
         dw_util_pkg.log_infor(l_stage
                               ,p_plan_node_control_id
                               ,c_package_name || '.' || l_procedure_name);
         
        /*--201704182237 INSERT INTO DW_PREALLOCATE_GD_FST
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        \*,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount*\  )
        SELECT  p_period_name              AS  period_name,
                alloc_flag         ,
                sales_type         ,
                company_code       ,
                account_code       ,
                department_code    ,
                subaccount_code    ,
                product_code       ,
                channel_code       ,
                intcom_code        ,
                budgetaccount_code ,
                area1_code         ,
                area2_code         ,
                putout_mob         ,
                depart_mob         ,       
                story_mob          ,
                putoutno           ,
                sum(ptd_amount)    ,
                sum(ytd_amount)    ,
                attribute1         ,
                attribute2         ,
                attribute3         ,
                attribute4         ,
                attribute5         ,
                attribute6         ,
                attribute7         ,
                attribute8         ,
                attribute9         ,
                attribute10        ,
                attribute11        ,
                attribute12        ,
                attribute13        ,
                attribute14        ,
                attribute15        ,
                attribute16        ,
                attribute17        ,
                attribute18        ,
                attribute19        ,
                attribute20        \*,
                w_insert_dt        ,
                w_update_dt        ,
                year_begin_amount *\
          FROM 
        (SELECT\* p_period_name          AS period_name        ,*\
                fs.alloc_flag          AS alloc_flag         ,
                fs.sales_type          AS sales_type         ,
                fs.company_code        AS company_code       ,
                fs.account_code        AS account_code       ,
                \*fs.department_code*\''     AS department_code    ,
                \*fs.subaccount_code*\''     AS subaccount_code    ,
                \*fs.product_code*\''        AS product_code       ,
                \*fs.channel_code*\''        AS channel_code       ,
                \*fs.intcom_code*\ ''        AS intcom_code        ,
                \*fs.budgetaccount_code*\''  AS budgetaccount_code ,
                fs.area1_code          AS area1_code         ,
                fs.area2_code          AS area2_code         ,
                fs.putout_mob          AS putout_mob         ,
                fs.depart_mob          AS depart_mob         ,       
                fs.story_mob           AS story_mob          ,
                \*fs.putoutno*\''            AS putoutno           ,
                 (-1*l_bxsr_value*adj.rate)  AS ptd_amount   ,
                 \*fs.ytd_amount*\''          AS ytd_amount         ,
                 adj.attribute1         AS attribute1         ,
                 adj.attribute2         AS attribute2         ,
                 adj.attribute3         AS attribute3         ,
                 adj.attribute4         AS attribute4         ,
                 adj.attribute5         AS attribute5         ,
                 adj.attribute6         AS attribute6         ,
                 adj.attribute7         AS attribute7         ,
                 adj.attribute8         AS attribute8         ,
                 adj.attribute9         AS attribute9         ,
                 adj.attribute10        AS attribute10        ,
                 adj.attribute11        AS attribute11        ,
                 adj.attribute12        AS attribute12        ,
                 adj.attribute13        AS attribute13        ,
                 adj.attribute14        AS attribute14        ,
                 adj.attribute15        AS attribute15        ,
                 adj.attribute16        AS attribute16        ,
                 adj.attribute17        AS attribute17        ,
                 adj.attribute18        AS attribute18        ,
                 adj.attribute19        AS attribute19        ,
                 adj.attribute20        AS attribute20        \*,
                 adj.created_date       AS w_insert_dt        ,
                 adj.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount*\

          FROM DM_C_GD_ADJUSTMENT adj,
               DW_PREALLOCATE_GD_FS fs 
         WHERE adj.status = 'C'
           AND adj.account_code = fs.account_code
           AND adj.account_code IN ('6601015201', '6601015901')
           AND adj.period_name = p_period_name
           AND fs.period_name =  p_period_name
           AND (fs.ptd_amount <>0 OR fs.ytd_amount <> 0)
           
        UNION ALL
        
        SELECT  \*p_period_name        AS period_name        ,*\
                fs.alloc_flag          AS alloc_flag         ,
                fs.sales_type          AS sales_type         ,
                fs.company_code        AS company_code       ,
                fs.account_code        AS account_code       ,
                \*fs.department_code*\''     AS department_code    ,
                \*fs.subaccount_code*\''     AS subaccount_code    ,
                \*fs.product_code*\''        AS product_code       ,
                \*fs.channel_code*\''        AS channel_code       ,
                \*fs.intcom_code*\ ''        AS intcom_code        ,
                \*fs.budgetaccount_code*\''  AS budgetaccount_code ,
                fs.area1_code          AS area1_code         ,
                fs.area2_code          AS area2_code         ,
                fs.putout_mob          AS putout_mob         ,
                fs.depart_mob          AS depart_mob         ,       
                fs.story_mob           AS story_mob          ,
                \*fs.putoutno*\''            AS putoutno           ,
                 (-1*l_bxsr_value*adj.rate*(fs.ptd_amount/l_sjfj_value))  AS ptd_amount   ,
                 \*fs.ytd_amount*\''          AS ytd_amount         ,
                 adj.attribute1         AS attribute1         ,
                 adj.attribute2         AS attribute2         ,
                 adj.attribute3         AS attribute3         ,
                 adj.attribute4         AS attribute4         ,
                 adj.attribute5         AS attribute5         ,
                 adj.attribute6         AS attribute6         ,
                 adj.attribute7         AS attribute7         ,
                 adj.attribute8         AS attribute8         ,
                 adj.attribute9         AS attribute9         ,
                 adj.attribute10        AS attribute10        ,
                 adj.attribute11        AS attribute11        ,
                 adj.attribute12        AS attribute12        ,
                 adj.attribute13        AS attribute13        ,
                 adj.attribute14        AS attribute14        ,
                 adj.attribute15        AS attribute15        ,
                 adj.attribute16        AS attribute16        ,
                 adj.attribute17        AS attribute17        ,
                 adj.attribute18        AS attribute18        ,
                 adj.attribute19        AS attribute19        ,
                 adj.attribute20        AS attribute20       \* ,
                 adj.created_date       AS w_insert_dt        ,
                 adj.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount*\
                 
          FROM DM_C_GD_ADJUSTMENT adj,
               DW_PREALLOCATE_GD_FS fs 
         WHERE adj.status = 'C'
           AND adj.account_code = fs.account_code
           AND adj.account_code LIKE '6403%'
           AND adj.period_name = p_period_name
           AND fs.period_name =  p_period_name
           AND (fs.ptd_amount <>0 OR fs.ytd_amount <> 0)) T
         GROUP BY alloc_flag   ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ;
        COMMIT;--201704182237*/
        
        INSERT INTO DW_PREALLOCATE_GD_FST
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        /*,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount*/  )
        SELECT  p_period_name              AS  period_name,
                alloc_flag         ,
                sales_type         ,
                company_code       ,
                account_code       ,
                department_code    ,
                subaccount_code    ,
                product_code       ,
                channel_code       ,
                intcom_code        ,
                budgetaccount_code ,
                area1_code         ,
                area2_code         ,
                putout_mob         ,
                depart_mob         ,       
                story_mob          ,
                putoutno           ,
                sum(ptd_amount)    ,
                sum(ytd_amount)    ,
                attribute1         ,
                attribute2         ,
                attribute3         ,
                attribute4         ,
                attribute5         ,
                attribute6         ,
                attribute7         ,
                attribute8         ,
                attribute9         ,
                attribute10        ,
                attribute11        ,
                attribute12        ,
                attribute13        ,
                attribute14        ,
                attribute15        ,
                attribute16        ,
                attribute17        ,
                attribute18        ,
                attribute19        ,
                attribute20        /*,
                w_insert_dt        ,
                w_update_dt        ,
                year_begin_amount */
          FROM 
        (SELECT/* p_period_name          AS period_name        ,*/
                fs.alloc_flag          AS alloc_flag         ,
                /*fs.sales_type*/''          AS sales_type         ,
                /*fs.company_code*/''        AS company_code       ,
                fs.account_code        AS account_code       ,
                /*fs.department_code*/''     AS department_code    ,
                /*fs.subaccount_code*/''     AS subaccount_code    ,
                /*fs.product_code*/''        AS product_code       ,
                /*fs.channel_code*/''        AS channel_code       ,
                /*fs.intcom_code*/ ''        AS intcom_code        ,
                /*fs.budgetaccount_code*/''  AS budgetaccount_code ,
                /*fs.area1_code*/''          AS area1_code         ,
                /*fs.area2_code*/''          AS area2_code         ,
                /*fs.putout_mob*/''          AS putout_mob         ,
                /*fs.depart_mob*/''          AS depart_mob         ,       
                /*fs.story_mob*/''           AS story_mob          ,
                /*fs.putoutno*/''            AS putoutno           ,
                 (-1*l_bxsr_value*adj.rate)  AS ptd_amount   ,
                 /*fs.ytd_amount*/''          AS ytd_amount          ,
                 /*adj.attribute1    */ ''     AS attribute1         ,
                 /*adj.attribute2    */ ''     AS attribute2         ,
                 /*adj.attribute3    */ ''     AS attribute3         ,
                 /*adj.attribute4    */ ''     AS attribute4         ,
                 /*adj.attribute5    */ ''     AS attribute5         ,
                 /*adj.attribute6    */ ''     AS attribute6         ,
                 /*adj.attribute7    */ ''     AS attribute7         ,
                 /*adj.attribute8    */ ''     AS attribute8         ,
                 /*adj.attribute9    */ ''     AS attribute9         ,
                 /*adj.attribute10   */ ''     AS attribute10        ,
                 /*adj.attribute11   */ ''     AS attribute11        ,
                 /*adj.attribute12   */ ''     AS attribute12        ,
                 /*adj.attribute13   */ ''     AS attribute13        ,
                 /*adj.attribute14   */ ''     AS attribute14        ,
                 /*adj.attribute15   */ ''     AS attribute15        ,
                 /*adj.attribute16   */ ''     AS attribute16        ,
                 /*adj.attribute17   */ ''     AS attribute17        ,
                 /*adj.attribute18   */ ''     AS attribute18        ,
                 /*adj.attribute19   */ ''     AS attribute19        ,
                 /*adj.attribute20 */''       AS attribute20        /*,
                 adj.created_date       AS w_insert_dt        ,
                 adj.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount*/

          FROM DM_C_GD_ADJUSTMENT adj,
               DW_PREALLOCATE_GD_FS_V fs 
         WHERE adj.status = 'C'
           AND adj.account_code = fs.account_code
           AND adj.account_code IN ('6601015201', '6601015901')
           AND adj.period_name = p_period_name
           
        UNION ALL
        
        SELECT  /*p_period_name        AS period_name        ,*/
                fs.alloc_flag          AS alloc_flag         ,
                /*fs.sales_type*/''          AS sales_type         ,
                /*fs.company_code*/''        AS company_code       ,
                fs.account_code        AS account_code       ,
                /*fs.department_code*/''     AS department_code    ,
                /*fs.subaccount_code*/''     AS subaccount_code    ,
                /*fs.product_code*/''        AS product_code       ,
                /*fs.channel_code*/''        AS channel_code       ,
                /*fs.intcom_code*/ ''        AS intcom_code        ,
                /*fs.budgetaccount_code*/''  AS budgetaccount_code ,
                 /*fs.area1_code*/''          AS area1_code         ,
                /*fs.area2_code*/''          AS area2_code         ,
                /*fs.putout_mob*/''          AS putout_mob         ,
                /*fs.depart_mob*/''          AS depart_mob         ,       
                /*fs.story_mob*/''           AS story_mob          ,
                /*fs.putoutno*/''            AS putoutno           ,
                 (-1*l_bxsr_value*adj.rate*(fs.ptd_amount/l_sjfj_value))  AS ptd_amount   ,
                 /*fs.ytd_amount*/''          AS ytd_amount         ,
                /*adj.attribute1    */ ''     AS attribute1         ,
                 /*adj.attribute2    */ ''     AS attribute2         ,
                 /*adj.attribute3    */ ''     AS attribute3         ,
                 /*adj.attribute4    */ ''     AS attribute4         ,
                 /*adj.attribute5    */ ''     AS attribute5         ,
                 /*adj.attribute6    */ ''     AS attribute6         ,
                 /*adj.attribute7    */ ''     AS attribute7         ,
                 /*adj.attribute8    */ ''     AS attribute8         ,
                 /*adj.attribute9    */ ''     AS attribute9         ,
                 /*adj.attribute10   */ ''     AS attribute10        ,
                 /*adj.attribute11   */ ''     AS attribute11        ,
                 /*adj.attribute12   */ ''     AS attribute12        ,
                 /*adj.attribute13   */ ''     AS attribute13        ,
                 /*adj.attribute14   */ ''     AS attribute14        ,
                 /*adj.attribute15   */ ''     AS attribute15        ,
                 /*adj.attribute16   */ ''     AS attribute16        ,
                 /*adj.attribute17   */ ''     AS attribute17        ,
                 /*adj.attribute18   */ ''     AS attribute18        ,
                 /*adj.attribute19   */ ''     AS attribute19        ,
                 /*adj.attribute20 */''       AS attribute20        /*,
                 adj.created_date       AS w_insert_dt        ,
                 adj.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount*/
                 
          FROM DM_C_GD_ADJUSTMENT adj,
               DW_PREALLOCATE_GD_FS_V fs 
         WHERE adj.status = 'C'
           AND adj.account_code = fs.account_code
           AND adj.account_code LIKE '6403%'
           AND adj.period_name = p_period_name) T
         GROUP BY alloc_flag   ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ;
        COMMIT;
        dbms_output.put_line('45'); 
        --对第一步算的预处理表DW_PREALLOCATE_GD_FS，进行按机构，科目分组后的COMPANY_CODE下的sum(DW_PREALLOCATE_GD_FS.PTD_AMOUNT)）/该科目下的PTD的和DW_PREALLOCATE_GD_FS.PTD_AMOUN
        /*INSERT INTO DW_PREALLOCATE_GD_FS_TMP
           (company_code       ,
            account_code       ,
            ptd_com_acct       ,
            ptd_acct )
            SELECT DISTINCT fs.company_code,
                   fs.account_code,
                   (SUM(ptd_amount)over(PARTITION BY fs.account_code, fs.company_code)) ,
                   (SUM(ptd_amount)over(PARTITION BY fs.account_code)) 
              FROM DW_PREALLOCATE_GD_FS fs
             WHERE fs.period_name = p_period_name;
        COMMIT;*/
        
        INSERT INTO DW_PREALLOCATE_GD_FS_TMP
           (company_code       ,
            account_code       ,
            ptd_com_acct       ,
            ptd_acct )
            SELECT DISTINCT fs.company_code,
                   fs.account_code,
                   (SUM(ptd_amount)over(PARTITION BY fs.account_code, fs.company_code)) ,
                   (SUM(ptd_amount)over(PARTITION BY fs.account_code)) 
              FROM (SELECT t.company_code,
                           t.account_code,
                           SUM(t.ptd_amount) ptd_amount
                      FROM DW_PREALLOCATE_GD_FS t
                     WHERE t.period_name = p_period_name
                     GROUP BY t.company_code,
                              t.account_code) fs;
        COMMIT;
        dbms_output.put_line('50'); 
        --计算amount
        INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            --w_insert_dt        ,
            --w_update_dt        ,
            year_begin_amount  )
         
         SELECT fst.period_name        AS period_name        ,
                fst.alloc_flag          AS alloc_flag         ,
                fst.sales_type          AS sales_type         ,
                tmp.company_code        AS company_code       ,
                fst.account_code        AS account_code       ,
                fst.department_code     AS department_code    ,
                fst.subaccount_code     AS subaccount_code    ,
                fst.product_code        AS product_code       ,
                fst.channel_code        AS channel_code       ,
                fst.intcom_code         AS intcom_code        ,
                fst.budgetaccount_code  AS budgetaccount_code ,
                fst.area1_code          AS area1_code         ,
                fst.area2_code          AS area2_code         ,
                fst.putout_mob          AS putout_mob         ,
                fst.depart_mob          AS depart_mob         ,       
                fst.story_mob           AS story_mob          ,
                fst.putoutno            AS putoutno           ,
                 fst.ptd_amount*(tmp.ptd_com_acct/tmp.ptd_acct)  AS ptd_amount   ,
                 /*fst.ytd_amount*/''          AS ytd_amount        ,
                 fst.attribute1         AS attribute1         ,
                 fst.attribute2         AS attribute2         ,
                 fst.attribute3         AS attribute3         ,
                 fst.attribute4         AS attribute4         ,
                 fst.attribute5         AS attribute5         ,
                 fst.attribute6         AS attribute6         ,
                 fst.attribute7         AS attribute7         ,
                 fst.attribute8         AS attribute8         ,
                 fst.attribute9         AS attribute9         ,
                 fst.attribute10        AS attribute10        ,
                 fst.attribute11        AS attribute11        ,
                 fst.attribute12        AS attribute12        ,
                 fst.attribute13        AS attribute13        ,
                 fst.attribute14        AS attribute14        ,
                 fst.attribute15        AS attribute15        ,
                 fst.attribute16        AS attribute16        ,
                 fst.attribute17        AS attribute17        ,
                 fst.attribute18        AS attribute18        ,
                 fst.attribute19        AS attribute19        ,
                 fst.attribute20        AS attribute20        ,
                 --fst.created_date       AS w_insert_dt        ,
                 --fst.created_date       AS w_update_dt        ,
                 fst.year_begin_amount  AS year_begin_amount

          FROM dw_preallocate_gd_fst fst, dw_preallocate_gd_fs_tmp tmp
         WHERE (fst.account_code IN ('6601015201', '6601015901') OR fst.account_code LIKE '6403%')
           --AND fst.company_code = tmp.company_code
           AND fst.account_code = tmp.account_code
           AND fst.period_name  = p_period_name;
         COMMIT;
         dbms_output.put_line('55'); 
           ----------------------------------------------------
        
         /*--2.待摊特殊处理逻辑（手工补录工资和手续费及佣金支出调整项数据）
         l_stage := '2.待摊特殊处理逻辑（手工补录工资和手续费及佣金支出调整项数据）';
         dw_util_pkg.log_infor(l_stage
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);

         INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount  )
        --2.待摊特殊处理逻辑（手工补录工资和手续费及佣金支出调整项数据）
        SELECT  p_period_name           AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F100010'
                   WHEN fier.f_flag ='N' THEN 'F100011' END)  AS alloc_flag,
                ''                            AS sales_type,
                \*adj.company_code*\''        AS company_code,
                \*adj.account_code*\''        AS account_code       ,
                \*adj.department_code*\ ''    AS department_code    ,
                \*adj.subaccount_code*\ ''    AS subaccount_code    ,
                \*adj.product_code*\   ''     AS product_code       ,
                \*adj.channel_code*\   ''     AS channel_code       ,
                \*adj.intcom_code*\''         AS intcom_code        ,
                ''                            AS budgetaccount_code ,
                nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = adj.company_code 
                  UNION  
                 SELECT  t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = adj.company_code
                 ), 0)      AS area1_code         ,
                nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = adj.company_code 
                  UNION  
                 SELECT  t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = adj.company_code
                 ), 0)                  AS area2_code         ,
                 ''                     AS putout_mob         ,
                 nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = adj.company_code), 0) AS depart_mob,
           
                 nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = adj.company_code), 0) AS story_mob,
                 ''                     AS putoutno           ,
                 (-1*fs.ptd_amount*adj.rate)  AS ptd_amount   ,
                 fs.ytd_amount          AS ytd_amount         ,
                 adj.attribute1         AS attribute1         ,
                 adj.attribute2         AS attribute2         ,
                 adj.attribute3         AS attribute3         ,
                 adj.attribute4         AS attribute4         ,
                 adj.attribute5         AS attribute5         ,
                 adj.attribute6         AS attribute6         ,
                 adj.attribute7         AS attribute7         ,
                 adj.attribute8         AS attribute8         ,
                 adj.attribute9         AS attribute9         ,
                 adj.attribute10        AS attribute10        ,
                 adj.attribute11        AS attribute11        ,
                 adj.attribute12        AS attribute12        ,
                 adj.attribute13        AS attribute13        ,
                 adj.attribute14        AS attribute14        ,
                 adj.attribute15        AS attribute15        ,
                 adj.attribute16        AS attribute16        ,
                 adj.attribute17        AS attribute17        ,
                 adj.attribute18        AS attribute18        ,
                 adj.attribute19        AS attribute19        ,
                 adj.attribute20        AS attribute20        ,
                 adj.created_date       AS w_insert_dt        ,
                 adj.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount

          FROM DM_C_GD_ADJUSTMENT adj,
               DIS_MT_C_GD_O_IDENTIFIER fier,
               DW_PREALLOCATE_GD_FS fs
         WHERE adj.status = 'C'
           AND adj.account_code = fier.src_account_code
           AND adj.account_code = fs.account_code
           AND adj.period_name = p_period_name
           AND (fs.ptd_amount <>0 OR fs.ytd_amount <> 0);
        COMMIT;*/

         --处理hpm_ledger_stat表数据
         INSERT INTO HPM_LEDGER_STAT
             (rule_id              ,
              alloc_flag           ,
              sub_part             ,
              segment1             ,
              segment2             ,
              segment3             ,
              segment4             ,
              segment5             ,
              segment6             ,
              segment7             ,
              segment8             ,
              segment9             ,
              segment10            ,
              segment11            ,
              segment12            ,
              segment13            ,
              segment14            ,
              segment15            ,
              segment16            ,
              segment17            ,
              segment18            ,
              segment19            ,
              segment20            ,
              amount               ,
              request_id           ,
              tolerance_request_id ,
              s_rowid              ,
              s_in_out_type        ,
              creation_date
            )
            SELECT ''                     AS rule_id,
                   prfs.alloc_flag        AS alloc_flag,
                   ''                     AS sub_part,
                   prfs.company_code      AS segment1,
                   prfs.account_code      AS segment2,
                   prfs.budgetaccount_code AS segment3,
                   prfs.department_code    AS segment4,
                   prfs.subaccount_code    AS segment5,
                   prfs.product_code       AS segment6,
                   prfs.channel_code       AS segment7,
                   prfs.intcom_code        AS segment8,
                   prfs.area1_code         AS segment9,
                   prfs.area2_code         AS segment10,
                   prfs.putout_mob         AS segment11,
                   prfs.depart_mob         AS segment12,
                   prfs.story_mob          AS segment13,
                   prfs.putoutno           AS segment14,
                   ''                      AS segment15,
                   ''                      AS segment16,
                   ''                      AS segment17,
                   ''                      AS segment18,
                   ''                      AS segment19,
                   ''                      AS segment20,
                   prfs.ptd_amount         AS amount,
                   ''                      AS request_id,
                   ''                      AS tolerance_request_id,
                   ''                      AS s_rowid,
                   ''                      AS s_in_out_type,
                   l_execute_begining_date AS creation_date
              FROM DW_PREALLOCATE_GD_FS prfs
             WHERE  prfs.alloc_flag = 'F100010';
           COMMIT;

        -- 关闭并发
        dw_util_pkg.disable_session_parallel;
        dw_util_pkg.log_infor('生成数据完成！共执行时间（分钟）：' ||
                              dw_util_pkg.executing_time(l_execute_begining_date)
                              ,p_plan_node_control_id
                              ,c_package_name || '.' || l_procedure_name);

        x_return_status := 'Y';

     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
        dw_util_pkg.log_error(l_stage || '错误:' || SQLERRM
                             ,p_plan_node_control_id
                             ,c_package_name || '.' || l_procedure_name);
     END pre_alloc_financial_sys;


   --2.费控系统待摊处理
   PROCEDURE pre_alloc_expense_control_sys(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2) IS
      l_procedure_name        VARCHAR2(300) := 'pre_alloc_expense_control_sys(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||''',' ||
                                             'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
      l_stage                 VARCHAR2(300);
      l_execute_begining_date DATE := SYSDATE;
     BEGIN
       --预处理表处理逻辑(总账数据)
        INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount  )
        SELECT  lines.period_name                             AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F200010'
                   WHEN fier.f_flag ='N' THEN 'F200011' END)  AS alloc_flag,
                lines.sales_type                              AS sales_type,
                lines.company_code                            AS company_code,
                lines.account_code                            AS account_code       ,
                lines.department_code                         AS department_code    ,
                lines.subaccount_code                         AS subaccount_code    ,
                lines.product_code                            AS product_code       ,
                lines.channel_code                            AS channel_code       ,
                ''                                            AS intcom_code        ,
                lines.budget_item_code                        AS budgetaccount_code ,
                nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = lines.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = lines.company_code
                 ), 0)      AS area1_code         ,
                nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = lines.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = lines.company_code
                 ), 0)      AS area2_code         ,
                 ''                     AS putout_mob         ,
                 nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = lines.company_code), 0) AS depart_mob,
           
                 nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = lines.company_code), 0) AS story_mob   ,
                 ''                    AS putoutno           ,
                 lines.report_amount   AS ptd_amount         ,
                 0                     AS ytd_amount         ,
                 lines.attribute1         AS attribute1         ,
                 lines.attribute2         AS attribute2         ,
                 lines.attribute3         AS attribute3         ,
                 lines.attribute4         AS attribute4         ,
                 lines.attribute5         AS attribute5         ,
                 lines.attribute6         AS attribute6         ,
                 lines.attribute7         AS attribute7         ,
                 lines.attribute8         AS attribute8         ,
                 lines.attribute9         AS attribute9         ,
                 lines.attribute10        AS attribute10        ,
                 lines.attribute11        AS attribute11        ,
                 lines.attribute12        AS attribute12        ,
                 lines.attribute13        AS attribute13        ,
                 lines.attribute14        AS attribute14        ,
                 lines.attribute15        AS attribute15        ,
                 lines.attribute16        AS attribute16        ,
                 lines.attribute17        AS attribute17        ,
                 lines.attribute18        AS attribute18        ,
                 lines.attribute19        AS attribute19        ,
                 lines.attribute20        AS attribute20        ,
                 lines.oda_etl_systime    AS w_insert_dt        ,
                 lines.oda_etl_systime    AS w_update_dt        ,
                 ''                       AS year_begin_amount

          FROM DW_GD_REPORT_LINES lines,
               DIS_MT_C_GD_O_IDENTIFIER fier

         WHERE lines.currency_code = 'CNY'
           AND lines.account_code = fier.src_account_code
           AND lines.report_amount <> 0;
         COMMIT;
         
         --费控系统待摊处理hpm_ledger_stat表数据
         INSERT INTO HPM_LEDGER_STAT
             (rule_id              ,
              alloc_flag           ,
              sub_part             ,
              segment1             ,
              segment2             ,
              segment3             ,
              segment4             ,
              segment5             ,
              segment6             ,
              segment7             ,
              segment8             ,
              segment9             ,
              segment10            ,
              segment11            ,
              segment12            ,
              segment13            ,
              segment14            ,
              segment15            ,
              segment16            ,
              segment17            ,
              segment18            ,
              segment19            ,
              segment20            ,
              amount               ,
              request_id           ,
              tolerance_request_id ,
              s_rowid              ,
              s_in_out_type        ,
              creation_date
            )
            SELECT ''                     AS rule_id,
                   prfs.alloc_flag        AS alloc_flag,
                   ''                     AS sub_part,
                   prfs.company_code      AS segment1,
                   prfs.account_code      AS segment2,
                   prfs.budgetaccount_code AS segment3,
                   prfs.department_code    AS segment4,
                   prfs.subaccount_code    AS segment5,
                   prfs.product_code       AS segment6,
                   prfs.channel_code       AS segment7,
                   prfs.intcom_code        AS segment8,
                   prfs.area1_code         AS segment9,
                   prfs.area2_code         AS segment10,
                   prfs.putout_mob         AS segment11,
                   prfs.depart_mob         AS segment12,
                   prfs.story_mob          AS segment13,
                   prfs.putoutno           AS segment14,
                   prfs.sales_type         AS segment15,
                   ''                      AS segment16,
                   ''                      AS segment17,
                   ''                      AS segment18,
                   ''                      AS segment19,
                   ''                      AS segment20,
                   prfs.ptd_amount         AS amount,
                   ''                      AS request_id,
                   ''                      AS tolerance_request_id,
                   ''                      AS s_rowid,
                   ''                      AS s_in_out_type,
                   l_execute_begining_date AS creation_date
              FROM DW_PREALLOCATE_GD_FS prfs
             WHERE (prfs.ptd_amount<>0 OR prfs.ytd_amount<>0)
               AND prfs.alloc_flag = 'F200010'
               AND prfs.period_name = p_period_name;
           COMMIT;
     END pre_alloc_expense_control_sys; 
   --3.人事系统待摊处理（补录）
   PROCEDURE pre_alloc_hr_sys_apd(x_return_status        OUT VARCHAR2,
                                  p_plan_node_control_id NUMBER,
                                  p_period_name          VARCHAR2) IS
      l_procedure_name        VARCHAR2(300)  :=  'pre_alloc_hr_sys_apd(' ||
                                                 'x_return_status => ''' ||
                                                 x_return_status || ''',' ||
                                                 'p_plan_node_control_id => ''' ||
                                                 p_plan_node_control_id ||''',' ||
                                                 'p_period_name => ''' ||
                                                 p_period_name || '''' || ');';
      l_stage                 VARCHAR2(300);
      l_execute_begining_date DATE           := SYSDATE;
      l_year_begin_time       VARCHAR2(10)   := substr(p_period_name, 1, 4)||'-01';
                                  
     BEGIN
        INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount  )
        SELECT  per.period_name                               AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F300010'
                   WHEN fier.f_flag ='N' THEN 'F300011' END)  AS alloc_flag,
                ''                                            AS sales_type,
                per.company_code                              AS company_code,
                per.account_code                              AS account_code       ,
                per.department_code                           AS department_code    ,
                per.subaccount_code                           AS subaccount_code    ,
                ''                                            AS product_code       ,
                ''                                            AS channel_code       ,
                ''                                            AS intcom_code        ,
                ''                                            AS budgetaccount_code ,
                nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area1_code         ,
                nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area2_code         ,
                 ''                     AS putout_mob         ,
                 nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code), 0) AS depart_mob,
           
                 nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code), 0) AS story_mob   ,
                 0                      AS putoutno           ,
                 per.amount             AS ptd_amount         ,
                 0                      AS ytd_amount         ,
                 per.attribute1         AS attribute1         ,
                 per.attribute2         AS attribute2         ,
                 per.attribute3         AS attribute3         ,
                 per.attribute4         AS attribute4         ,
                 per.attribute5         AS attribute5         ,
                 per.attribute6         AS attribute6         ,
                 per.attribute7         AS attribute7         ,
                 per.attribute8         AS attribute8         ,
                 per.attribute9         AS attribute9         ,
                 per.attribute10        AS attribute10        ,
                 per.attribute11        AS attribute11        ,
                 per.attribute12        AS attribute12        ,
                 per.attribute13        AS attribute13        ,
                 per.attribute14        AS attribute14        ,
                 per.attribute15        AS attribute15        ,
                 per.attribute16        AS attribute16        ,
                 per.attribute17        AS attribute17        ,
                 per.attribute18        AS attribute18        ,
                 per.attribute19        AS attribute19        ,
                 per.attribute20        AS attribute20        ,
                 per.created_date       AS w_insert_dt        ,
                 per.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount

          FROM DM_C_GD_PERSON_DATA per,
               DIS_MT_C_GD_O_IDENTIFIER fier

         WHERE per.status='C'
           AND per.account_code = fier.src_account_code
           AND per.amount <> 0
           AND per.period_name = p_period_name
           
           UNION ALL
       --计算ytd    
       SELECT  per.period_name                               AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F100010'
                   WHEN fier.f_flag ='N' THEN 'F100011' END)  AS alloc_flag,
                ''                                            AS sales_type,
                per.company_code                              AS company_code,
                per.account_code                              AS account_code       ,
                per.department_code                           AS department_code    ,
                per.subaccount_code                           AS subaccount_code    ,
                ''                                            AS product_code       ,
                ''                                            AS channel_code       ,
                ''                                            AS intcom_code        ,
                ''                                            AS budgetaccount_code ,
                nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area1_code         ,
                nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area2_code         ,
                 ''                     AS putout_mob         ,
                 nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code), 0) AS depart_mob,
           
                 nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code), 0) AS story_mob   ,
                 0                      AS putoutno           ,
                 per.amount             AS ptd_amount         ,
                 0                      AS ytd_amount         ,--还未计算
                 per.attribute1         AS attribute1         ,
                 per.attribute2         AS attribute2         ,
                 per.attribute3         AS attribute3         ,
                 per.attribute4         AS attribute4         ,
                 per.attribute5         AS attribute5         ,
                 per.attribute6         AS attribute6         ,
                 per.attribute7         AS attribute7         ,
                 per.attribute8         AS attribute8         ,
                 per.attribute9         AS attribute9         ,
                 per.attribute10        AS attribute10        ,
                 per.attribute11        AS attribute11        ,
                 per.attribute12        AS attribute12        ,
                 per.attribute13        AS attribute13        ,
                 per.attribute14        AS attribute14        ,
                 per.attribute15        AS attribute15        ,
                 per.attribute16        AS attribute16        ,
                 per.attribute17        AS attribute17        ,
                 per.attribute18        AS attribute18        ,
                 per.attribute19        AS attribute19        ,
                 per.attribute20        AS attribute20        ,
                 per.created_date       AS w_insert_dt        ,
                 per.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount

          FROM DM_C_GD_PERSON_DATA per,
               DIS_MT_C_GD_O_IDENTIFIER fier

         WHERE per.status='C'
           AND per.account_code = fier.src_account_code
           AND per.amount <> 0
           AND per.period_name >= l_year_begin_time
           AND per.period_name <= p_period_name;    
           
         COMMIT;
         
         --预处理表中的数据进行以下处理
         INSERT INTO HPM_LEDGER_STAT
             (rule_id              ,
              alloc_flag           ,
              sub_part             ,
              segment1             ,
              segment2             ,
              segment3             ,
              segment4             ,
              segment5             ,
              segment6             ,
              segment7             ,
              segment8             ,
              segment9             ,
              segment10            ,
              segment11            ,
              segment12            ,
              segment13            ,
              segment14            ,
              segment15            ,
              segment16            ,
              segment17            ,
              segment18            ,
              segment19            ,
              segment20            ,
              amount               ,
              request_id           ,
              tolerance_request_id ,
              s_rowid              ,
              s_in_out_type        ,
              creation_date
            )
            SELECT ''                     AS rule_id,
                   prfs.alloc_flag        AS alloc_flag,
                   ''                     AS sub_part,
                   prfs.company_code      AS segment1,
                   prfs.account_code      AS segment2,
                   prfs.budgetaccount_code AS segment3,
                   prfs.department_code    AS segment4,
                   prfs.subaccount_code    AS segment5,
                   prfs.product_code       AS segment6,
                   prfs.channel_code       AS segment7,
                   prfs.intcom_code        AS segment8,
                   prfs.area1_code         AS segment9,
                   prfs.area2_code         AS segment10,
                   prfs.putout_mob         AS segment11,
                   prfs.depart_mob         AS segment12,
                   prfs.story_mob          AS segment13,
                   prfs.putoutno           AS segment14,
                   prfs.sales_type         AS segment15,
                   ''                      AS segment16,
                   ''                      AS segment17,
                   ''                      AS segment18,
                   ''                      AS segment19,
                   ''                      AS segment20,
                   prfs.ptd_amount         AS amount,
                   ''                      AS request_id,
                   ''                      AS tolerance_request_id,
                   ''                      AS s_rowid,
                   ''                      AS s_in_out_type,
                   l_execute_begining_date AS creation_date
              FROM DW_PREALLOCATE_GD_FS prfs
             WHERE (prfs.ptd_amount<>0 OR prfs.ytd_amount<>0)
               AND prfs.alloc_flag = 'F300010'
               AND prfs.period_name = p_period_name;
           COMMIT;
     END pre_alloc_hr_sys_apd;
     
   --4.基本法系统待摊处理（补录）
   PROCEDURE pre_alloc_basic_law_sys_apd(x_return_status        OUT VARCHAR2,
                                         p_plan_node_control_id NUMBER,
                                         p_period_name          VARCHAR2) IS
     l_procedure_name        VARCHAR2(300)  :=  'pre_alloc_basic_law_sys_apd(' ||
                                                 'x_return_status => ''' ||
                                                 x_return_status || ''',' ||
                                                 'p_plan_node_control_id => ''' ||
                                                 p_plan_node_control_id ||''',' ||
                                                 'p_period_name => ''' ||
                                                 p_period_name || '''' || ');';
      l_stage                 VARCHAR2(300);
      l_execute_begining_date DATE           := SYSDATE;
      l_year_begin_time       VARCHAR2(10)   := substr(p_period_name, 1, 4)||'-01';
     BEGIN
        INSERT INTO DW_PREALLOCATE_GD_FS
           (period_name        ,
            alloc_flag         ,
            sales_type         ,
            company_code       ,
            account_code       ,
            department_code    ,
            subaccount_code    ,
            product_code       ,
            channel_code       ,
            intcom_code        ,
            budgetaccount_code ,
            area1_code         ,
            area2_code         ,
            putout_mob         ,
            depart_mob         ,
            story_mob          ,
            putoutno           ,
            ptd_amount         ,
            ytd_amount         ,
            attribute1         ,
            attribute2         ,
            attribute3         ,
            attribute4         ,
            attribute5         ,
            attribute6         ,
            attribute7         ,
            attribute8         ,
            attribute9         ,
            attribute10        ,
            attribute11        ,
            attribute12        ,
            attribute13        ,
            attribute14        ,
            attribute15        ,
            attribute16        ,
            attribute17        ,
            attribute18        ,
            attribute19        ,
            attribute20        ,
            w_insert_dt        ,
            w_update_dt        ,
            year_begin_amount  )
        SELECT  per.period_name                               AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F300010'
                   WHEN fier.f_flag ='N' THEN 'F300011' END)  AS alloc_flag,
                ''                                            AS sales_type,
                per.company_code                              AS company_code,
                per.account_code                              AS account_code       ,
                per.department_code                           AS department_code    ,
                per.subaccount_code                           AS subaccount_code    ,
                ''                                            AS product_code       ,
                ''                                            AS channel_code       ,
                ''                                            AS intcom_code        ,
                ''                                            AS budgetaccount_code ,
                nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area1_code         ,
                nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area2_code         ,
                 ''                     AS putout_mob         ,
                 nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code), 0) AS depart_mob,
           
                 nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code), 0) AS story_mob   ,
                 0                      AS putoutno           ,
                 per.amount             AS ptd_amount         ,
                 0                      AS ytd_amount         ,
                 per.attribute1         AS attribute1         ,
                 per.attribute2         AS attribute2         ,
                 per.attribute3         AS attribute3         ,
                 per.attribute4         AS attribute4         ,
                 per.attribute5         AS attribute5         ,
                 per.attribute6         AS attribute6         ,
                 per.attribute7         AS attribute7         ,
                 per.attribute8         AS attribute8         ,
                 per.attribute9         AS attribute9         ,
                 per.attribute10        AS attribute10        ,
                 per.attribute11        AS attribute11        ,
                 per.attribute12        AS attribute12        ,
                 per.attribute13        AS attribute13        ,
                 per.attribute14        AS attribute14        ,
                 per.attribute15        AS attribute15        ,
                 per.attribute16        AS attribute16        ,
                 per.attribute17        AS attribute17        ,
                 per.attribute18        AS attribute18        ,
                 per.attribute19        AS attribute19        ,
                 per.attribute20        AS attribute20        ,
                 per.created_date       AS w_insert_dt        ,
                 per.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount

          FROM DM_C_GD_PERSON_DATA per,
               DIS_MT_C_GD_O_IDENTIFIER fier

         WHERE per.status='C'
           AND per.account_code = fier.src_account_code
           AND per.amount <> 0
           AND per.period_name = p_period_name
           
           UNION ALL
       --计算ytd    
       SELECT  per.period_name                               AS period_name,
                (CASE
                   WHEN fier.f_flag ='Y' THEN 'F100010'
                   WHEN fier.f_flag ='N' THEN 'F100011' END)  AS alloc_flag,
                ''                                            AS sales_type,
                per.company_code                              AS company_code,
                per.account_code                              AS account_code       ,
                per.department_code                           AS department_code    ,
                per.subaccount_code                           AS subaccount_code    ,
                ''                                            AS product_code       ,
                ''                                            AS channel_code       ,
                ''                                            AS intcom_code        ,
                ''                                            AS budgetaccount_code ,
                nvl((SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area1_code         ,
                nvl((SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code
                 ), 0)      AS area2_code         ,
                 ''                     AS putout_mob         ,
                 nvl((SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = per.company_code), 0) AS depart_mob,
           
                 nvl((SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = per.company_code), 0) AS story_mob   ,
                 0                      AS putoutno           ,
                 per.amount             AS ptd_amount         ,
                 0                      AS ytd_amount         ,--还未计算
                 per.attribute1         AS attribute1         ,
                 per.attribute2         AS attribute2         ,
                 per.attribute3         AS attribute3         ,
                 per.attribute4         AS attribute4         ,
                 per.attribute5         AS attribute5         ,
                 per.attribute6         AS attribute6         ,
                 per.attribute7         AS attribute7         ,
                 per.attribute8         AS attribute8         ,
                 per.attribute9         AS attribute9         ,
                 per.attribute10        AS attribute10        ,
                 per.attribute11        AS attribute11        ,
                 per.attribute12        AS attribute12        ,
                 per.attribute13        AS attribute13        ,
                 per.attribute14        AS attribute14        ,
                 per.attribute15        AS attribute15        ,
                 per.attribute16        AS attribute16        ,
                 per.attribute17        AS attribute17        ,
                 per.attribute18        AS attribute18        ,
                 per.attribute19        AS attribute19        ,
                 per.attribute20        AS attribute20        ,
                 per.created_date       AS w_insert_dt        ,
                 per.created_date       AS w_update_dt        ,
                 ''                     AS year_begin_amount

          FROM DM_C_GD_PERSON_DATA per,
               DIS_MT_C_GD_O_IDENTIFIER fier

         WHERE per.status='C'
           AND per.account_code = fier.src_account_code
           AND per.amount <> 0
           AND per.period_name >= l_year_begin_time
           AND per.period_name <= p_period_name;    
           
         COMMIT;
         
         --预处理表中的数据进行以下处理
         INSERT INTO HPM_LEDGER_STAT
             (rule_id              ,
              alloc_flag           ,
              sub_part             ,
              segment1             ,
              segment2             ,
              segment3             ,
              segment4             ,
              segment5             ,
              segment6             ,
              segment7             ,
              segment8             ,
              segment9             ,
              segment10            ,
              segment11            ,
              segment12            ,
              segment13            ,
              segment14            ,
              segment15            ,
              segment16            ,
              segment17            ,
              segment18            ,
              segment19            ,
              segment20            ,
              amount               ,
              request_id           ,
              tolerance_request_id ,
              s_rowid              ,
              s_in_out_type        ,
              creation_date
            )
            SELECT ''                     AS rule_id,
                   prfs.alloc_flag        AS alloc_flag,
                   ''                     AS sub_part,
                   prfs.company_code      AS segment1,
                   prfs.account_code      AS segment2,
                   prfs.budgetaccount_code AS segment3,
                   prfs.department_code    AS segment4,
                   prfs.subaccount_code    AS segment5,
                   prfs.product_code       AS segment6,
                   prfs.channel_code       AS segment7,
                   prfs.intcom_code        AS segment8,
                   prfs.area1_code         AS segment9,
                   prfs.area2_code         AS segment10,
                   prfs.putout_mob         AS segment11,
                   prfs.depart_mob         AS segment12,
                   prfs.story_mob          AS segment13,
                   prfs.putoutno           AS segment14,
                   prfs.sales_type         AS segment15,
                   ''                      AS segment16,
                   ''                      AS segment17,
                   ''                      AS segment18,
                   ''                      AS segment19,
                   ''                      AS segment20,
                   prfs.ptd_amount         AS amount,
                   ''                      AS request_id,
                   ''                      AS tolerance_request_id,
                   ''                      AS s_rowid,
                   ''                      AS s_in_out_type,
                   l_execute_begining_date AS creation_date
              FROM DW_PREALLOCATE_GD_FS prfs
             WHERE (prfs.ptd_amount<>0 OR prfs.ytd_amount<>0)
               AND prfs.alloc_flag = 'F400010'
               AND prfs.period_name = p_period_name;
           COMMIT;
     END pre_alloc_basic_law_sys_apd;
/*=========================================
二.分摊因子(allocate factor)数据维度维值处理
=========================================*/
  --预处理acct_payment_schedule_tmp
  PROCEDURE alloc_pre_paymt_schdu(x_return_status        OUT VARCHAR2,
                                  p_plan_node_control_id NUMBER,
                                  p_period_name          VARCHAR2) IS
      l_procedure_name        VARCHAR2(300) := 'alloc_pre_paymt_schdu(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id || ''');';
      l_stage                 VARCHAR2(300);
      l_execute_begining_date DATE := SYSDATE;
      l_sql                   VARCHAR2(1000);
      l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/'); 
  BEGIN
      dw_util_pkg.log_infor('开始生成acct_payment_schedule_tmp数据'
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);

      -- 清除数据
      l_stage := '清数acct_payment_schedule_tmp表';
      dw_util_pkg.log_infor(l_stage
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);
      dw_util_pkg.truncate_table(c_hpm_schema
                                ,'acct_payment_schedule_tmp');

      -- 开启并发
      dw_util_pkg.enable_session_parallel(2);

      -- 生成数据
      l_stage := '生成acct_payment_schedule_tmp数据';
      dw_util_pkg.log_infor(l_stage
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);
    
      /*201704191325  大sql取数逻辑有调整,加了参数期间
       INSERT INTO acct_payment_schedule_tmp 
        select count(1) M, aps.serialno
          FROM ACCT_PAYMENT_SCHEDULE APS
         where APS.OBJECTNO in (select distinct ACC.SERIALNO
                                  from ACCT_LOAN ACC)
           and ((TO_DATE(APS.PAYDATE, 'yyyy/mm/dd') < TRUNC(sysdate) and
               FINISHDATE is null) or
               APS.FINISHDATE in (select A.FINISHDATE
                                     from ACCT_PAYMENT_SCHEDULE A
                                    where A.OBJECTNO = APS.OBJECTNO
                                      and A.PAYTYPE = '6'))
         GROUP BY aps.serialno;
      COMMIT;201704191325*/
       insert into ACCT_PAYMENT_SCHEDULE_TMP
         select count(1), ACC.PUTOUTNO
           from ACCT_PAYMENT_SCHEDULE APS, ACCT_LOAN ACC
          where APS.OBJECTNO = ACC.SERIALNO
            and SUBSTR(ACC.PUTOUTDATE, '1', '7') <= l_period_name
            and ((SUBSTR(APS.PAYDATE, 1, 7) <= l_period_name /*参数日期*/
                and APS.FINISHDATE is null) /*or
                                            APS.FINISHDATE in (select A.FINISHDATE
                                                                  from ACCT_PAYMENT_SCHEDULE A
                                                                 where A.OBJECTNO = APS.OBJECTNO
                                                                   and A.PAYTYPE = '6')*/
                )
          group by ACC.PUTOUTNO;
      COMMIT;

        -- 关闭并发
        dw_util_pkg.disable_session_parallel;
        dw_util_pkg.log_infor('生成数据完成！共执行时间（分钟）：' ||
                              dw_util_pkg.executing_time(l_execute_begining_date)
                              ,p_plan_node_control_id
                              ,c_package_name || '.' || l_procedure_name);

        x_return_status := 'Y';

     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
        dw_util_pkg.log_error(l_stage || '错误:' || SQLERRM
                             ,p_plan_node_control_id
                             ,c_package_name || '.' || l_procedure_name);    
  END alloc_pre_paymt_schdu;
  
  /*===========================================================
  视图说明：
   ACCT_LOAN_4_V    --去重"ORGID","PUTOUTNO","PUTOUTDATE", "BUSINESSTYPE", "SERIALNO" + LOANSTATUS <> '20'
   ACCT_LOAN_10_V   --去重"ORGID","PUTOUTNO","PUTOUTDATE", "BUSINESSTYPE", "SERIALNO"
   ACCT_LOAN_1_V    --去重"ORGID","PUTOUTNO","PUTOUTDATE", "BUSINESSTYPE"
   ACCT_LOAN_NOSER_V--去重"ORGID","PUTOUTNO","PUTOUTDATE"
   ===========================================================*/
   --根据跑批日期生产当月的视图
  /*PROCEDURE alloc_pre_view(p_period_name VARCHAR2) IS
      l_stage                 VARCHAR2(300);
      l_execute_begining_date DATE := SYSDATE;
      l_sql                   VARCHAR2(1000);
      l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/'); 
  BEGIN
      -- 重建视图ACCT_LOAN_10_V
      l_sql := 'CREATE OR REPLACE VIEW ACCT_LOAN_10_V AS
                 SELECT "ORGID", "PUTOUTNO","PUTOUTDATE", "BUSINESSTYPE", "SERIALNO", "A" FROM (
                   select LOAN.ORGID, LOAN.PUTOUTNO, LOAN.PUTOUTDATE , loan.businesstype, loan.serialno, 
                     ROW_NUMBER() OVER(partition by LOAN.ORGID, LOAN.PUTOUTNO order by LOAN.PUTOUTDATE) a
                    from ACCT_LOAN LOAN WHERE  SUBSTR(LOAN.PUTOUTDATE, 1, 7) = '''||l_period_name||''') T WHERE T.a =1';
      dbms_output.put_line(l_sql); 
      EXECUTE IMMEDIATE l_sql;
       
  END alloc_pre_view;*/
   
  
  --1.当月新增账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_incremnt_account(x_return_status      OUT VARCHAR2,
                                       p_plan_node_control_id NUMBER,
                                       p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_incremnt_account(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
  BEGIN
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date 
       )
    SELECT ''                  AS rule_id     ,
           'F190001'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           --和文档逻辑不一致，因uat环境数据有问题，通过保单号关联取到多条数据，故人工限制去最大产品，迁到生产不会有此问题
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6, 
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
           (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over (partition by loan.putoutno)  AS amount,
          ''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          l_execute_begining_date                   AS creation_date  
      FROM /*acct_loan*/acct_loan_1_v loan
     WHERE substr(loan.putoutdate, '1', '7') = l_period_name;
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END alloc_fcr_incremnt_account;
  --2.年累计新增账户数ETL处理（个贷系统因子）--删
  --3.累计(cumulative) 新增账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_cum_incremnt_account(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_cum_incremnt_account(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE             := SYSDATE;                                 
    l_period_name           VARCHAR2(10) 	:= replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date 
       )
    SELECT ''                  AS rule_id     ,
           'F190003'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           (SELECT DISTINCT a.businesstype FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
           (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over(partition by loan.putoutno)     AS amount ,
          ''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          l_execute_begining_date                   AS creation_date  
      FROM acct_loan_noser_v loan
     WHERE substr(loan.putoutdate, '1', '7') <= l_period_name;
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END alloc_fcr_cum_incremnt_account;
  
  --4.期末账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_end_account(x_return_status        OUT VARCHAR2,
                                         p_plan_node_control_id NUMBER,
                                         p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_period_end_account(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
    l_last_month            VARCHAR2(20) := dw_getdimwid_pkg.get_last_period_name(p_period_name); 
    l_before_36month        VARCHAR2(20) := to_char(add_months(to_date(p_period_name, 'yyyy-mm'), -36), 'yyyy-mm'); 
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          creation_date 
       )
     SELECT rule_id              ,
            alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          l_execute_begining_date AS creation_date  
       FROM   
    (SELECT ''                  AS rule_id    ,
           'F190004'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
           (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          ''                   AS creation_date  
      FROM ACCT_LOAN_4_V loan/*,  acct_payment_schedule_tmp aps
     WHERE loan.putoutno =  aps.serialno */  -- 本来通过outputno（保单号）关联，因aps表没有保单号，故用serialno去关联 
/*       AND aps.M = 7*/
     WHERE  substr(loan.startdate, '1', '7') <= l_period_name
       AND substr(loan.startdate, '1', '7') >= l_before_36month
       --AND loan.loanstatus <> '20'  在视图中做了剔除
       
       MINUS
     
    SELECT ''                  AS rule_id    ,
           'F190004'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
           (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          ''                   AS creation_date  
      FROM ACCT_LOAN_4_V loan,  acct_payment_schedule_tmp aps
     WHERE loan.putoutno =  aps.serialno   -- 本来通过outputno（保单号）关联，因aps表没有保单号，故用serialno去关联 
       AND aps.M >= 7
       AND substr(loan.startdate, '1', '7') <= l_period_name
       AND substr(loan.startdate, '1', '7') >= l_before_36month
       --AND loan.loanstatus <> '20'  在视图中做了剔除 */   
     /*UNION ALL
     
     SELECT ''                           AS rule_id     ,
            lsa.alloc_flag               AS alloc_flag  ,
            lsa.sub_part                 AS sub_part    ,
            lsa.segment1                 AS segment1    ,
            lsa.segment2                 AS segment2    ,
            lsa.segment3                 AS segment3    ,
            lsa.segment4                 AS segment4    ,
            lsa.segment5                 AS segment5    ,
            lsa.segment6                 AS segment6    ,
            lsa.segment7                 AS segment7    ,
            lsa.segment8                 AS segment8    ,
            lsa.segment9                 AS segment9    ,
            lsa.segment10                 AS segment10   ,
            lsa.segment11                 AS segment11   ,
            lsa.segment12                 AS segment12   ,
            lsa.segment13                 AS segment13   ,
            lsa.segment14                 AS segment14            ,
            lsa.segment15                 AS segment15            ,
            lsa.segment16                 AS segment16            ,
            lsa.segment17                 AS segment17            ,
            lsa.segment18                 AS segment18            ,
            lsa.segment19                 AS segment19            ,
            lsa.segment20                 AS segment20            ,
            lsa.amount                   AS amount               ,
         \* ''                             AS request_id           ,
          ''                             AS tolerance_request_id ,
          ''                             AS s_rowid              ,
          ''                             AS s_in_out_type        ,*\
          ''                             AS creation_date  
      FROM hpm_ledger_stat_archive lsa
     WHERE lsa.alloc_flag = 'F190004'
       AND lsa.ledger_period >= l_before_36month
       AND lsa.ledger_period <= l_last_month*/) T
     GROUP BY rule_id          ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ;
              
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
       
  END alloc_fcr_period_end_account;
  
  --5.期末账户数与当月新增账户数差值（个贷系统因子）ETL处理
  PROCEDURE alloc_fcr_period_end_acontblac(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_period_end_acontblac(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
    l_last_month            VARCHAR2(20) := dw_getdimwid_pkg.get_last_period_name(p_period_name); 
    l_before_36month        VARCHAR2(20) := to_char(add_months(to_date(p_period_name, 'yyyy-mm'), -36), 'yyyy-mm'); 
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          creation_date 
       )
     SELECT rule_id              ,
            'F190002'            AS alloc_flag,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          l_execute_begining_date AS creation_date  
       FROM   
    (SELECT ''                          AS rule_id     ,
            /*ls.alloc_flag*/''               AS alloc_flag  ,
            ls.sub_part                 AS sub_part    ,
            ls.segment1                 AS segment1    ,
            ls.segment2                 AS segment2    ,
            ls.segment3                 AS segment3    ,
            ls.segment4                 AS segment4    ,
            ls.segment5                 AS segment5    ,
            ls.segment6                 AS segment6    ,
            ls.segment7                 AS segment7    ,
            ls.segment8                 AS segment8    ,
            ls.segment9                 AS segment9    ,
            ls.segment10                AS segment10   ,
            ls.segment11                 AS segment11   ,
            ls.segment12                 AS segment12   ,
            ls.segment13                 AS segment13   ,
            ls.segment14                 AS segment14            ,
            ls.segment15                 AS segment15            ,
            ls.segment16                 AS segment16            ,
            ls.segment17                 AS segment17            ,
            ls.segment18                 AS segment18            ,
            ls.segment19                 AS segment19            ,
            ls.segment20                 AS segment20            ,
            ls.amount                    AS amount               
         /* ''                           AS request_id           ,
          ''                             AS tolerance_request_id ,
          ''                             AS s_rowid              ,
          ''                             AS s_in_out_type        ,
          ''                             AS creation_date  */
      FROM hpm_ledger_stat ls
     WHERE ls.alloc_flag = 'F190004' 
       
     UNION ALL
     
     SELECT ''                          AS rule_id     ,
            /*ls.alloc_flag*/''               AS alloc_flag  ,
            ls.sub_part                 AS sub_part    ,
            ls.segment1                 AS segment1    ,
            ls.segment2                 AS segment2    ,
            ls.segment3                 AS segment3    ,
            ls.segment4                 AS segment4    ,
            ls.segment5                 AS segment5    ,
            ls.segment6                 AS segment6    ,
            ls.segment7                 AS segment7    ,
            ls.segment8                 AS segment8    ,
            ls.segment9                 AS segment9    ,
            ls.segment10                AS segment10   ,
            ls.segment11                 AS segment11   ,
            ls.segment12                 AS segment12   ,
            ls.segment13                 AS segment13   ,
            ls.segment14                 AS segment14            ,
            ls.segment15                 AS segment15            ,
            ls.segment16                 AS segment16            ,
            ls.segment17                 AS segment17            ,
            ls.segment18                 AS segment18            ,
            ls.segment19                 AS segment19            ,
            ls.segment20                 AS segment20            ,
            -1*ls.amount                 AS amount               
         /* ''                           AS request_id           ,
          ''                             AS tolerance_request_id ,
          ''                             AS s_rowid              ,
          ''                             AS s_in_out_type        ,
          ''                             AS creation_date  */
      FROM hpm_ledger_stat ls
     WHERE ls.alloc_flag = 'F190001' ) T
     GROUP BY rule_id          ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ;
              
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
       
  END alloc_fcr_period_end_acontblac;
  
  --6.期末账户数（逾期期数为M2）ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_end_accountm2(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_period_end_accountm2(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
    l_last_month            VARCHAR2(20) := dw_getdimwid_pkg.get_last_period_name(p_period_name); 
    l_before_36month        VARCHAR2(20) := to_char(add_months(to_date(p_period_name, 'yyyy-mm'), -36), 'yyyy-mm'); 
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          creation_date 
       )
       SELECT rule_id          ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)          ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          l_execute_begining_date AS creation_date  
       FROM 
    (SELECT ''                  AS rule_id     ,
           'F190005'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
           (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
           (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
           (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                 AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          ''                   AS creation_date  
      FROM ACCT_LOAN_4_V loan, acct_payment_schedule_tmp aps
     WHERE loan.putoutno =  aps.serialno   -- 本来通过outputno（保单号）关联，因aps表没有保单号，故用serialno去关联 
       AND aps.M = 2
       AND substr(loan.startdate , '1', '7') >= to_char(add_months(to_date(l_period_name, 'yyyy/mm'), -35), 'yyyy/mm')  --参数期间-startdate+1
      -- AND substr(loan.startdate, '1', '7') > l_before_36month
       --AND loan.loanstatus <> '20'
       
     /*UNION ALL
     
     SELECT ''                           AS rule_id     ,
            lsa.alloc_flag               AS alloc_flag  ,
            lsa.sub_part                 AS sub_part    ,
            lsa.segment1                 AS segment1    ,
            lsa.segment2                 AS segment2    ,
            lsa.segment3                 AS segment3    ,
            lsa.segment4                 AS segment4    ,
            lsa.segment5                 AS segment5    ,
            lsa.segment6                 AS segment6    ,
            lsa.segment6                 AS segment7    ,
            lsa.segment6                 AS segment8    ,
            lsa.segment6                 AS segment9    ,
            lsa.segment6                 AS segment10   ,
            lsa.segment6                 AS segment11   ,
            lsa.segment6                 AS segment12   ,
            lsa.segment6                 AS segment13   ,
            lsa.segment6                 AS segment14            ,
            lsa.segment6                 AS segment15            ,
            lsa.segment6                 AS segment16            ,
            lsa.segment6                 AS segment17            ,
            lsa.segment6                 AS segment18            ,
            lsa.segment6                 AS segment19            ,
            lsa.segment6                 AS segment20            ,
            lsa.amount                   AS amount               ,
         \* ''                             AS request_id           ,
          ''                             AS tolerance_request_id ,
          ''                             AS s_rowid              ,
          ''                             AS s_in_out_type        ,*\
          ''                             AS creation_date  
      FROM hpm_ledger_stat_archive lsa
     WHERE lsa.alloc_flag = 'F190005'
       AND lsa.ledger_period >= l_before_36month
       AND lsa.ledger_period <= l_last_month*/) T
     GROUP BY rule_id          ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ;
         
    COMMIT;   
    x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END alloc_fcr_period_end_accountm2;
  --7.当月逾期账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_overdue_acout(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_period_overdue_acout(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          creation_date 
       )
       SELECT rule_id              ,
            alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          l_execute_begining_date AS creation_date  
      FROM   
    (SELECT ''                  AS rule_id     ,
           'F190006'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          ''                   AS creation_date  
      FROM ACCT_LOAN_10_V loan
     WHERE  substr(loan.putoutdate, '1', '7') = l_period_name   
       
    MINUS
       
    SELECT ''                  AS rule_id     ,
           'F190006'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          ''                   AS creation_date  
      FROM ACCT_LOAN_10_V loan, acct_payment_schedule_tmp aps
     WHERE loan.PUTOUTNO =  aps.serialno   -- 本来通过outputno（保单号）关联，因aps表没有保单号，故用serialno去关联 
       AND (aps.M >= 7 OR aps.M = 0)  --取保单的逾期期数1~6（逾期期数的全量是0~7， 所以当<>0 且<>7时，就取到了1~6）
       AND substr(loan.putoutdate, '1', '7') = l_period_name) T
     GROUP BY rule_id          ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ;
    COMMIT;   
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';        
     
  END alloc_fcr_period_overdue_acout;
  
  --8.年累计平均逾期账户数（不含M7）ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_avgytd_overdue_acout(x_return_status        OUT VARCHAR2,
                                           p_plan_node_control_id NUMBER,
                                           p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_avgytd_overdue_acout(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;    
    l_year_begin            VARCHAR2(20) := substr(p_period_name, 1, 4)||'/01'; --e.g:2016/01
    l_last_month            VARCHAR2(20) := dw_getdimwid_pkg.get_last_period_name(p_period_name); 
    l_month_number_factor   NUMBER       := 1/substr(p_period_name, 6, 2);         
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
    --l_temp_num              NUMBER       := replace(substr(p_period_name, 6, 2), 0, '');
    l_temp_num              NUMBER       :=to_number(replace(p_period_name, '-', ''));
    l_temp_num_start        NUMBER       :=to_number(substr(p_period_name, 1, 4)||'01');
    l_sql                   CLOB;
    l_sql1                  VARCHAR2(5000);
    l_execute_begining_var  VARCHAR2(20);
  BEGIN
    dbms_output.put_line('1'); 
    EXECUTE IMMEDIATE 'TRUNCATE TABLE HPM_LEDGER_STAT_TMP';
    EXECUTE IMMEDIATE 'TRUNCATE TABLE L_TEMP_SQL';
   /* alloc_pre_view(p_period_name);*/--注意： 待权限放开后放开这句sql
    
    dbms_output.put_line('122');
    l_execute_begining_var :=  to_char(l_execute_begining_date, 'yyyy-mm-dd hh24:mi:ss');
    dbms_output.put_line('2'); 
    
    FOR i IN l_temp_num_start ..l_temp_num LOOP
      dbms_output.put_line('3'); 
      l_sql:= ' INSERT INTO HPM_LEDGER_STAT_TMP
       (  ledger_period        ,
          rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          ytd                  ,
          creation_date        )
       
     SELECT  substr('''||i||''', 1,4)||''-''||substr('''||i||''', 5,2)     ,
          rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)          ,
          sum(ytd)             ,
          to_date('''||l_execute_begining_var ||''',''yyyy-mm-dd hh24:mi:ss'')                
        FROM 
            (   /*20170420 SELECT ''          AS rule_id     ,
                   decode(ls.alloc_flag, ''F190006'', ''F190007'', ls.alloc_flag) AS alloc_flag  , 
                   ls.sub_part         AS sub_part    ,
                   ls.segment1         AS segment1    ,
                   ls.segment2         AS segment2    ,
                   ls.segment3         AS segment3    ,
                   ls.segment4         AS segment4    ,
                   ls.segment5         AS segment5    ,
                   ls.segment6         AS segment6    ,
                   ls.segment7         AS segment7    ,
                   ls.segment8         AS segment8    ,
                   ls.segment9         AS segment9    ,
                   ls.segment10        AS segment10   ,
                   ls.segment11        AS segment11   ,
                   ls.segment12        AS segment12   ,
                   ls.segment13        AS segment13   ,
                   ls.segment14        AS segment14            ,
                   ls.segment15        AS segment15            ,
                   ls.segment16        AS segment16            ,
                   ls.segment17        AS segment17            ,
                   ls.segment18        AS segment18            ,
                   ls.segment19        AS segment19            ,
                   ls.segment20        AS segment20            ,
                   ls.amount           AS amount               ,
                   ls.amount           AS ytd                  \*
                   ls.request_id       AS request_id           ,
                   ls.tolerance_request_id                   AS tolerance_request_id ,
                   ls.s_rowid                                AS s_rowid              ,
                   ls.s_in_out_type                          AS s_in_out_type        ,
                   ls.creation_date                          AS creation_date  *\
              FROM hpm_ledger_stat ls
             WHERE ls.alloc_flag = ''F190006''
             
             UNION ALL 20170420*/
             
         (SELECT ''''            AS rule_id     ,
           ''F190007''           AS alloc_flag  ,
           ''''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''''                  AS segment2    ,
           ''''                  AS segment3    ,
           ''''                  AS segment4    ,
           ''''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''''                   AS segment15            ,
          ''''                   AS segment16            ,
          ''''                   AS segment17            ,
          ''''                   AS segment18            ,
          ''''                   AS segment19            ,
          ''''                   AS segment20            ,
          0                    AS amount               ,
          count(1) over( partition by loan.putoutno)     AS ytd
          /*''                 AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          ''                   AS creation_date  */
      FROM acct_loan_10_v loan
     WHERE substr(loan.putoutdate, ''1'', ''7'') >= '''||l_year_begin||'''    
       AND replace(substr(loan.putoutdate, ''1'', ''7''), ''/'', '''') <= '''||i||'''
       
    MINUS
       
    SELECT ''''                  AS rule_id     ,
           ''F190007''           AS alloc_flag  ,
           ''''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''''                  AS segment2    ,
           ''''                  AS segment3    ,
           ''''                  AS segment4    ,
           ''''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''''                   AS segment15            ,
          ''''                   AS segment16            ,
          ''''                   AS segment17            ,
          ''''                   AS segment18            ,
          ''''                   AS segment19            ,
          ''''                   AS segment20            ,
          0                    AS amount               ,
          count(1) over( partition by loan.putoutno)     AS ytd
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          ''                   AS creation_date  */
      FROM acct_loan_10_v loan, acct_payment_schedule_tmp aps
     WHERE loan.PUTOUTNO =  aps.serialno   -- 本来通过outputno（保单号）关联，因aps表没有保单号，故用serialno去关联 
       AND (aps.M =0 or aps.M >=7)  --取保单的逾期期数1~6（逾期期数的全量是0~7， 所以当<>0 且<>7时，就取到了1~6）
       AND substr(loan.putoutdate, ''1'', ''7'') >= '''||l_year_begin||'''        
       AND replace(substr(loan.putoutdate, ''1'', ''7''), ''/'', '''') <= '''||i||'''
             /*20170419
               SELECT lsa.rule_id       AS rule_id     ,
                   lsa.alloc_flag       AS alloc_flag  ,
                   lsa.sub_part         AS sub_part    ,
                   lsa.segment1         AS segment1    ,
                   lsa.segment2         AS segment2    ,
                   lsa.segment3         AS segment3    ,
                   lsa.segment4         AS segment4    ,
                   lsa.segment5         AS segment5    ,
                   lsa.segment6         AS segment6    ,
                   lsa.segment7         AS segment7    ,
                   lsa.segment8         AS segment8    ,
                   lsa.segment9         AS segment9    ,
                   lsa.segment10        AS segment10   ,
                   lsa.segment11        AS segment11   ,
                   lsa.segment12        AS segment12   ,
                   lsa.segment13        AS segment13   ,
                   lsa.segment14        AS segment14            ,
                   lsa.segment15        AS segment15            ,
                   lsa.segment16        AS segment16            ,
                   lsa.segment17        AS segment17            ,
                   lsa.segment18        AS segment18            ,
                   lsa.segment19        AS segment19            ,
                   lsa.segment20        AS segment20            ,
                   0                    AS amount               ,
                   lsa.amount           AS ytd                  \*,
                   lsa.request_id       AS request_id           ,
                   lsa.tolerance_request_id                   AS tolerance_request_id ,
                   lsa.s_rowid                                AS s_rowid              ,
                   lsa.s_in_out_type                          AS s_in_out_type        ,
                   lsa.creation_date                          AS creation_date*\  
              FROM hpm_ledger_stat_archive lsa
             WHERE lsa.alloc_flag = ''F190007''
               AND lsa.ledger_period >= l_year_begin
               AND lsa.ledger_period <= l_last_month
               AND p_period_name NOT LIKE ''%01''--201704192110*/)) T 
     GROUP BY rule_id              ,
              alloc_flag           ,
              sub_part             ,
              segment1             ,
              segment2             ,
              segment3             ,
              segment4             ,
              segment5             ,
              segment6             ,
              segment7             ,
              segment8             ,
              segment9             ,
              segment10            ,
              segment11            ,
              segment12            ,
              segment13            ,
              segment14            ,
              segment15            ,
              segment16            ,
              segment17            ,
              segment18            ,
              segment19            ,
              segment20            ';
     dbms_output.put_line('s'); 
                     
     INSERT INTO l_temp_sql (script, period, insert_date, wid) VALUES (l_sql, i, SYSDATE, l_temp_sql_s.nextval);
     COMMIT;
     
     --dbms_output.put_line(l_sql);  
     dbms_output.put_line('c');        
     
     END LOOP;
     
     FOR j IN (SELECT * FROM l_temp_sql t ORDER BY period) LOOP
       dbms_output.put_line('bb');
     EXECUTE IMMEDIATE j.script;
     dbms_output.put_line('b');
     END LOOP;
     COMMIT;
     
     dbms_output.put_line('22'); 
     INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          creation_date 
       )
    SELECT ls.rule_id          AS rule_id     ,
           ls.alloc_flag       AS alloc_flag  ,
           ls.sub_part         AS sub_part    ,
           ls.segment1         AS segment1    ,
           ls.segment2         AS segment2    ,
           ls.segment3         AS segment3    ,
           ls.segment4         AS segment4    ,
           ls.segment5         AS segment5    ,
           ls.segment6         AS segment6    ,
           ls.segment7         AS segment7    ,
           ls.segment8         AS segment8    ,
           ls.segment9         AS segment9    ,
           ls.segment10        AS segment10   ,
           ls.segment11        AS segment11   ,
           ls.segment12        AS segment12   ,
           ls.segment13        AS segment13   ,
           ls.segment14        AS segment14   ,
           ls.segment15        AS segment15   ,
           ls.segment16        AS segment16   ,
           ls.segment17        AS segment17   ,
           ls.segment18        AS segment18   ,
           ls.segment19        AS segment19   ,
           ls.segment20        AS segment20   ,
           sum(ls.ytd * l_month_number_factor)       AS amount               /*,
           ls.request_id                             AS request_id           ,
           ls.tolerance_request_id                   AS tolerance_request_id ,
           ls.s_rowid                                AS s_rowid              ,
           ls.s_in_out_type                          AS s_in_out_type        */,
           l_execute_begining_date                   AS creation_date  
      FROM HPM_LEDGER_STAT_TMP ls
     WHERE ls.alloc_flag = 'F190007'
       AND replace(ls.ledger_period, '-', '') <= replace(p_period_name, '-', '')
       AND replace(ls.ledger_period, '-', '') >= replace(l_year_begin, '/', '')
     GROUP BY  ls.rule_id       ,
               ls.alloc_flag    ,
               ls.sub_part      ,
               ls.segment1      ,
               ls.segment2      ,
               ls.segment3      ,
               ls.segment4      ,
               ls.segment5      ,
               ls.segment6      ,
               ls.segment7      ,
               ls.segment8      ,
               ls.segment9      ,
               ls.segment10     ,
               ls.segment11     ,
               ls.segment12     ,
               ls.segment13     ,
               ls.segment14     ,
               ls.segment15     ,
               ls.segment16     ,
               ls.segment17     ,
               ls.segment18     ,
               ls.segment19     ,
               ls.segment20     ;
    COMMIT;
    dbms_output.put_line('3'); 
    x_return_status := 'Y';

     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
        dw_util_pkg.log_error(l_stage || '错误:' || SQLERRM
                             ,p_plan_node_control_id
                             ,c_package_name || '.' || l_procedure_name); 
  END alloc_fcr_avgytd_overdue_acout;
  --9.累计逾期账户数ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_cum_overdue_acout(x_return_status        OUT VARCHAR2,
                                        p_plan_node_control_id NUMBER,
                                        p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_cum_overdue_acout(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
    l_year_begin_time       VARCHAR2(10)   := substr(p_period_name, 1, 4)||'-01';
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
         /* request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          creation_date 
       )
       
     SELECT rule_id              ,
            alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)               ,
          /*request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,*/
          l_execute_begining_date AS creation_date  
      FROM   
    (SELECT ''                  AS rule_id     ,
           'F190008'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          /*l_execute_begining_date*/''                   AS creation_date  
      FROM ACCT_LOAN_10_V loan
     WHERE  substr(loan.putoutdate, '1', '7') <= l_period_name
       /*AND substr(loan.putoutdate, '1', '7') >= l_year_begin_time*/
       
     MINUS
          
    SELECT ''                  AS rule_id     ,
           'F190008'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           loan. businesstype/*(SELECT DISTINCT a.BusinessType FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6,
           (SELECT DISTINCT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over( partition by loan.putoutno)     AS amount ,
          /*''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,*/
          /*l_execute_begining_date*/''                   AS creation_date  
      FROM ACCT_LOAN_10_V loan, acct_payment_schedule_tmp aps
     WHERE loan.putoutno =  aps.serialno   -- 本来通过outputno（保单号）关联，因aps表没有保单号，故用serialno去关联 
       AND (aps.M >= 7 OR aps.M = 0)  --取保单的逾期期数1~6（逾期期数的全量是0~7， 所以当<>0 且<>7时，就取到了1~6）
       AND substr(loan.putoutdate, '1', '7') <= l_period_name
       /*AND substr(loan.putoutdate, '1', '7') >= l_year_begin_time*/) T
     GROUP BY rule_id          ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ;
       
     COMMIT;   
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N'; 
  END alloc_fcr_cum_overdue_acout;
  --10.当月申请量ETL处理（个贷系统因子）
  PROCEDURE alloc_fcr_period_apply_num(x_return_status        OUT VARCHAR2,
                                       p_plan_node_control_id NUMBER,
                                       p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_period_apply_num(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date 
       )
       
    SELECT rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          sum(amount)          ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date  
      FROM    
    (SELECT ''                  AS rule_id     ,
           'F190009'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           --和文档逻辑不一致，因uat环境数据有问题，通过保单号关联取到多条数据，故人工限制去最大产品，迁到生产不会有此问题
           loan.businesstype /*(SELECT max(a.BusinessType) FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6, 
           (SELECT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over (partition by loan.putoutno)  AS amount,
          ''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          l_execute_begining_date                   AS creation_date  
      FROM ACCT_LOAN_1_V loan
     WHERE substr(loan.putoutdate, '1', '7') = l_period_name  
     
     UNION ALL
     
     SELECT ''                  AS rule_id     ,
           'F190009'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           loan.orgid          AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           --和文档逻辑不一致，因uat环境数据有问题，通过保单号关联取到多条数据，故人工限制去最大产品，迁到生产不会有此问题
           loan.businesstype /*(SELECT max(a.BusinessType) FROM business_apply a WHERE a.policyno = loan.putoutno)*/ AS segment6, 
           (SELECT a.channel FROM business_apply a WHERE a.policyno = loan.putoutno) AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = loan.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = loan.orgid)            AS segment13  ,
          loan.putoutno        AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          count(1) over (partition by loan.serialno)  AS amount,
          ''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          l_execute_begining_date                   AS creation_date  
      FROM ACCT_LOAN_10_V loan, retail_sales_apply rsa
     WHERE substr(loan.putoutdate, '1', '7') = l_period_name
       AND loan.serialno = rsa.baserialno) T
     GROUP BY rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date ;
     COMMIT;
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END alloc_fcr_period_apply_num;
  --11.有效保单剩余本金ETL处理（个贷系统因子） --删
  --12.保单1号UPR ETL处理（ORACLE系统因子）
  PROCEDURE alloc_fcr_ipo1_upr(x_return_status      OUT VARCHAR2,
                                     p_plan_node_control_id NUMBER,
                                     p_period_name          VARCHAR2) IS
                                     
    l_procedure_name        VARCHAR2(300) := 'alloc_fcr_ipo1_upr(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
  BEGIN
    
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date 
       )
    SELECT ''                  AS rule_id     ,
           'F190011'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           fs.company_code     AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           --和文档逻辑不一致，因uat环境数据有问题，通过保单号关联取到多条数据，故人工限制去最大产品，迁到生产不会有此问题
           fs.product_code     AS segment6, 
           fs.channel_code     AS segment7         ,
           ''                  AS segment8    ,
           fs.area1_code       AS segment9    ,
          fs.area2_code        AS segment10   ,
          ''                   AS segment11   ,
          fs.depart_mob        AS segment12  ,
          fs.story_mob         AS segment13  ,
          fs.putoutno          AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          fs.ptd_amount        AS amount,
          ''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          l_execute_begining_date                   AS creation_date  
      FROM dw_preallocate_gd_fs fs
     WHERE fs.account_code = '2601010101'
       AND fs.subaccount_code = 'GZ01'
       AND fs.period_name = p_period_name;
     COMMIT;
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END alloc_fcr_ipo1_upr;

  --13.佣金占比ETL处理（基本法-手工补录系统因子）  --需求待定，待开发
  PROCEDURE alloc_fcr_commission_percent (x_return_status        OUT VARCHAR2,
                                          p_plan_node_control_id NUMBER,
                                          p_period_name          VARCHAR2) IS
     l_procedure_name        VARCHAR2(300) := 'alloc_fcr_commission_percent(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' ||'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;                                 
    l_period_name           VARCHAR2(10) := replace(p_period_name, '-', '/');  --将p_period_name中的'-'转为'/'，例如'2017-01' => '2017/01', 为了提高下面取参数期间运算效率
  BEGIN
    INSERT INTO HPM_LEDGER_STAT
       (  rule_id              ,
          alloc_flag           ,
          sub_part             ,
          segment1             ,
          segment2             ,
          segment3             ,
          segment4             ,
          segment5             ,
          segment6             ,
          segment7             ,
          segment8             ,
          segment9             ,
          segment10            ,
          segment11            ,
          segment12            ,
          segment13            ,
          segment14            ,
          segment15            ,
          segment16            ,
          segment17            ,
          segment18            ,
          segment19            ,
          segment20            ,
          amount               ,
          request_id           ,
          tolerance_request_id ,
          s_rowid              ,
          s_in_out_type        ,
          creation_date 
       )
    SELECT ''                  AS rule_id     ,
           'F190012'           AS alloc_flag  ,
           ''                  AS sub_part    ,
           al.orgid            AS segment1    ,
           ''                  AS segment2    ,
           ''                  AS segment3    ,
           ''                  AS segment4    ,
           ''                  AS segment5    ,
           --和文档逻辑不一致，因uat环境数据有问题，通过保单号关联取到多条数据，故人工限制去最大产品，迁到生产不会有此问题
           al.businesstype     AS segment6, 
           ''                  AS segment7         ,
           ''                  AS segment8    ,
           (SELECT DISTINCT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = al.orgid 
                  UNION  
                 SELECT t.dest_area1_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = al.orgid
                 )         AS segment9    ,
          (SELECT DISTINCT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = al.orgid 
                  UNION  
                 SELECT t.dest_area2_code FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = al.orgid
                 )         AS segment10   ,
          ''                   AS segment11   ,
          (SELECT DISTINCT t.depart_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_depart_code = al.orgid) AS segment12  ,
          (SELECT t.story_mob FROM DIS_MT_C_GD_MAPPING t WHERE t.src_story_code = al.orgid)            AS segment13  ,
          al.putoutno          AS segment14            ,
          ''                   AS segment15            ,
          ''                   AS segment16            ,
          ''                   AS segment17            ,
          ''                   AS segment18            ,
          ''                   AS segment19            ,
          ''                   AS segment20            ,
          al.businesssum*r.rate        AS amount       ,
          ''                   AS request_id           ,
          ''                   AS tolerance_request_id ,
          ''                   AS s_rowid              ,
          ''                   AS s_in_out_type        ,
          l_execute_begining_date                   AS creation_date  
      FROM acct_loan al, dm_c_gd_rate r

     WHERE al.businesstype = r.product_code
       AND al.loanterm = r.loan_time_limit
       AND substr(al.putoutdate, '1', '7') = l_period_name;
     COMMIT;  
     x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END;  
                                          
/*=========================================
三.分摊过程特殊处理
=========================================*/
  --1.？期末账户数对前期累计费用进行分摊
  PROCEDURE c(x_return_status         OUT VARCHAR2
              ,p_plan_node_control_id NUMBER) IS
  BEGIN
    x_return_status := 'Y';
     EXCEPTION
       WHEN OTHERS THEN
        x_return_status := 'N';
  END;
  --2.清空分摊表分摊数据

  --3.分摊数据归档
    PROCEDURE alloc_spec_achieve(x_return_status         OUT VARCHAR2
                                 ,p_plan_node_control_id NUMBER
                                 ,p_period_name          VARCHAR2
                                 ,p_coa_id               NUMBER) IS
    l_procedure_name        VARCHAR2(300) := 'alloc_spec_achieve(' ||
                                             'x_return_status => ''' ||
                                             x_return_status || ''',' ||
                                             'p_plan_node_control_id => ''' ||
                                             p_plan_node_control_id ||
                                             ''',' || 'p_period_name => ''' ||
                                             p_period_name || '''' || ');';
    l_stage                 VARCHAR2(300);
    l_execute_begining_date DATE := SYSDATE;
    l_period_name           VARCHAR2(300) := REPLACE(p_period_name
                                                    ,'-'
                                                    ,'');
    l_step_name     VARCHAR2(300) := 'hpm_ledger_stat数据插入历史表';
    l_alloc_flag    VARCHAR2(300) := 'gen_achieve_alloc';
  BEGIN  
    -- 开启并发
    dw_util_pkg.enable_session_parallel(2);  
    dw_util_pkg.log_infor('开始生成hpm_ledger_stat_archive数据'
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
  
    -- 清除数据
   /* l_stage := '清除已生成数据';
    dw_util_pkg.log_infor(l_stage
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
                    
      dw_util_pkg.truncate_table('GDBZDEV'
                                ,'HPM_LEDGER_STAT_ARCHIVE'
                                ,l_period_name);*/
  
    -- 增加分区
    /*l_stage := '增加分区';
    dw_util_pkg.log_infor(l_stage
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
    FOR r_partition IN (SELECT partition_name
                          FROM all_tab_partitions
                         WHERE table_owner = c_hpm_schema
                           AND table_name = c_hpm_table)
    LOOP
      dw_util_pkg.add_partition(c_hpm_schema
                               ,c_hpm_achieve_table
                               ,REPLACE(p_period_name ,'-' ,'')
                               ,p_period_name
                               ,r_partition.partition_name
                               ,r_partition.partition_name);
    END LOOP;*/
  
    -- 生成数据
    l_stage := '生成数据';
    dw_util_pkg.log_infor(l_stage
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
    
      INSERT INTO  hpm_ledger_stat_archive
     (  ledger_period,
        rule_id,
        alloc_flag,
        sub_part,
        segment1,
        segment2,
        segment3,
        segment4,
        segment5,
        segment6,
        segment7,
        segment8,
        segment9,
        segment10,
        segment11,
        segment12,
        segment13,
        segment14,
        segment15,
        segment16,
        segment17,
        segment18,
        segment19,
        segment20,
        amount,
        request_id,
        tolerance_request_id,
        s_rowid,
        s_in_out_type,
        creation_date
     )
     select p_period_name  AS ledger_period,
            rule_id,
            alloc_flag,
            sub_part,
            segment1,
            segment2,
            segment3,
            segment4,
            segment5,
            segment6,
            segment7,
            segment8,
            segment9,
            segment10,
            segment11,
            segment12,
            segment13,
            segment14,
            segment15,
            segment16,
            segment17,
            segment18,
            segment19,
            segment20,
            amount,
            request_id,
            tolerance_request_id,
            s_rowid,
            s_in_out_type,
            creation_date
       from HPM_LEDGER_STAT T;
     COMMIT;   
    -- 关闭并发
    dw_util_pkg.disable_session_parallel;
    -- 数据统计收集
    l_stage := '数据统计收集';
    dw_util_pkg.log_infor(l_stage
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
    dw_util_pkg.gather_stats('GDBZDEV'
                            ,'HPM_LEDGER_STAT_ARCHIVE'
                            ,l_period_name);
  
    -- 重建索引
    l_stage := '重建索引';
    dw_util_pkg.log_infor(l_stage
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
    dw_util_pkg.rebuild_index('GDBZDEV'
                             ,'HPM_LEDGER_STAT_ARCHIVE'
                             ,l_period_name);
  
    dw_util_pkg.log_infor('生成数据完成！共执行时间（分钟）：' ||
                          dw_util_pkg.executing_time(l_execute_begining_date)
                         ,p_plan_node_control_id
                         ,c_package_name || '.' || l_procedure_name);
  
    x_return_status := 'Y';
  
  EXCEPTION
    WHEN OTHERS THEN
      x_return_status := 'N';
      -- 关闭并发
      dw_util_pkg.disable_session_parallel;
      dw_util_pkg.log_error(l_stage || '错误:' || SQLERRM
                           ,p_plan_node_control_id
                           ,c_package_name || '.' || l_procedure_name);
  END alloc_spec_achieve;
END dw_alloc_data_dg01_handler_pkg;
/

