create function getitemattr(pCodeNo varchar,pItemNo varchar)
return varchar
is pItemAttr varchar(250);


--Author:Zxu
--Date:  2005-09-16
--Action:    ?????itemattribute

begin
pItemAttr:='';
select trim(itemattribute) into pItemAttr
 from Code_Library
 where CodeNo=pCodeNo and ItemNo=pItemNo;
if pItemAttr is null then
  return '';
else
  return pItemAttr;
end if;
end;

/

