create FUNCTION GETBAORGID(pSerialno varchar)
return varchar2
is pOrgid varchar(20);
begin
select distinct ba.inputorgid into pOrgid
  from repayment_list  rl,
       collection_info ci,
       acct_loan       al,
       business_apply  ba
 where rl.serialno = ci.serialno
   and ci.lnsacct = al.serialno
   and al.baserialno = ba.serialno and rl.serialno=pSerialno;
return (pOrgid);
end;
/

