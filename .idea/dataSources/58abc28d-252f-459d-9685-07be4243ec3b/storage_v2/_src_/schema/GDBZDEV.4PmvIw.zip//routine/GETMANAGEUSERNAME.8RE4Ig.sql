create function GETMANAGEUSERNAME
(
   pCustomerID VARCHAR2
)
RETURN VARCHAR2 is pUserName VARCHAR2(80); BEGIN
select
UserName into pUserName
from USER_INFO
where UserId =
(
   select
   UserID
   from CUSTOMER_BELONG
   where CustomerID = pCustomerID
   and BelongAttribute = '1'
);
return pUserName;
END;

/

