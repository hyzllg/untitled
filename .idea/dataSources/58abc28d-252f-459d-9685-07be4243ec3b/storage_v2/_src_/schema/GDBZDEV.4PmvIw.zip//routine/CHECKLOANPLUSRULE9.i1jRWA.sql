create Function         checkLoanPlusRule9 ( pCertID IN varchar2 ) RETURN varchar2
IS
     ret varchar2(10);
     ICount number(6);
     IMonthBtw number(10);
     DXSerialNo varchar2(20);
     sMAXPhaseno varchar2(20);
     sOrderDate varchar2(20);
     sEndtime varchar2(20);
BEGIN
     select count(1) into ICount
     from acct_loan al,customer_info ci,business_type bt,acct_payment_schedule aps,business_apply ba
     where al.CUSTOMERID=ci.customerid
       and al.businesstype=bt.typeno
       and aps.objectno=al.serialno
       and al.baserialno=ba.serialno

     --9.非黑名单客户，包括个贷黑名单和INS黑名单，ins黑名单取ins同步给个贷的名单，故本规则不需要调用ins INS黑名单
      and NOT EXISTS
      (
          select bi.certid
          from black_info bi
          where nvl(bi.status,'1')='1'
            and (case when bi.CASERESULT='05' then 0 when bi.CASERESULT = '01' then 3 when bi.CASERESULT = '02' then 6 else 9999 end)
                 -
                 months_between(trunc(sysdate),case when substr(bi.begindate, 3, 1) = '/' then to_date(bi.begindate, 'dd/MM/yyyy') else to_date(bi.begindate, 'yyyy-MM-dd') end)
                 >=0
            and bi.certid=ci.certid
      )
      and NOT EXISTS
      (
          select da.ID_NUMBER2
          from DX_Applicant da
          where da.ID_NUMBER2=ci.certid
      )
     and ci.certid=pCertID;

     IF ICount=0 THEN
        ret := 'Betray';
     ELSE
        ret := 'LOVE';
     END IF;
     RETURN ret;
END;

/

