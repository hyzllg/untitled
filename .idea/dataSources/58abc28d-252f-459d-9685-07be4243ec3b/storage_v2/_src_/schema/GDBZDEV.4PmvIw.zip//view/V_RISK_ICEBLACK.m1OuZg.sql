create view V_RISK_ICEBLACK as
SELECT
SERIALNO,  ----流水号
BASERIALNO,  ----申请编号
BUSINESSTYPE,  ----申请产品
CUSTOMERID,  ----客户ID
ICENAME,  ----客户姓名
NVL2(CERTID,SUBSTR(CERTID,1,10)||'*****'||SUBSTR(CERTID,16),'') CERTID,  ----客户身份证号
NVL2(MOBILETELEPHONE,SUBSTR(MOBILETELEPHONE,1,6)||'***'||SUBSTR(MOBILETELEPHONE,10),'') MOBILETELEPHONE,  ----申请人手机号码
BELONGTO,  ----客户号码归属地
RETCODE,  ----响应标识
RESULTSCORE,
SWIFTID,  ----冰鉴返回流水号
MESSAGE,  ----冰鉴响应消息
BLACKLISTSCORE,
INPUTTIME,  ----冰鉴反馈时间
EDITTYPE,  ----操作类型   insert:为新查询的数据；copy：为该客户该申请产品下在复用天数内的数据复制值
SERVICENAME,  ----服务商
SERVICEPRODUCT,  ----服务产品
SENDTIME,  ----发送时间
HITSTATUS,  ----是否命中  01：命中，00：未命中
MODELSCORELIST,
RISKINFO,  ----命中详情 (若命中，会输出  信贷黑名单  或    执行黑名单)
RESPONSEMSG,  ----是否命中
REPORTCODE,
RESPONSERESOURCE
FROM RISK_ICEBLACK
/

