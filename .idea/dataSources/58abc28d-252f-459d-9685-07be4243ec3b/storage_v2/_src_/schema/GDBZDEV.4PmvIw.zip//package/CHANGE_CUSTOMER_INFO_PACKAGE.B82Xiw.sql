create package change_customer_info_package  is
      -- function checkParamsIsNull(custinfo azhi_customer_info%RowType) return varchar2(100);
      -- function replaceInfo(custinfo azhi_customer_info%RowType,custid varchar2(40)) return azhi_customer_info%RowType;
       function replaceOtherInfoID(certid varchar2,custid varchar2) return varchar2;
end change_customer_info_package;
/

