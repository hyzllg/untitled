create FUNCTION getPolicyParamTypeName(pTypeNo varchar2)
return varchar2
is pTypeNameTemp varchar2(80);
   pTypeNoTemp varchar2(20);
   pTypeName varchar2(80);
begin
  if nvl(pTypeNo,'NULL')='NULL' then
    pTypeName:='';
  else
    if(instr(pTypeNo,'@')=0) then
      select nvl((select TypeName from BUSINESS_TYPE where TypeNo=pTypeNo),'NULL') into pTypeNameTemp from dual;
      if(pTypeNameTemp = 'NULL') then
        select nvl((select TypeName from BUSINESS_TYPE_OL where TypeNo=pTypeNo),'') into pTypeNameTemp from dual;
        pTypeName:='【'||pTypeNameTemp||'】';
      else
        pTypeName:='【'||pTypeNameTemp||'】';
      end if;
    else
      pTypeNoTemp:=substr(pTypeNo,0,instr(pTypeNo,'@')-1);
      select nvl((select TypeName from BUSINESS_TYPE where TypeNo=pTypeNoTemp),'NULL') into pTypeNameTemp from dual;
      if(pTypeNameTemp = 'NULL') then
        select nvl((select TypeName from BUSINESS_TYPE_OL where TypeNo=pTypeNoTemp),'NULL') into pTypeNameTemp from dual;
        pTypeName:='【'||pTypeNameTemp||'】等...';
      else
        pTypeName:='【'||pTypeNameTemp||'】等...';
      end if;
    end if;
  end if;

  return pTypeName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

