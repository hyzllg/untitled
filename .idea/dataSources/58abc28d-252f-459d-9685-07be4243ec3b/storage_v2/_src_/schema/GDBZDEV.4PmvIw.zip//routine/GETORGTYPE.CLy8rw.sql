create FUNCTION getOrgType(pOrgname varchar)
return varchar
is pType  varchar(10);
begin
select orgtype into pType
  from org_info
where orgname = pOrgname;
  return pType;
end;
/

