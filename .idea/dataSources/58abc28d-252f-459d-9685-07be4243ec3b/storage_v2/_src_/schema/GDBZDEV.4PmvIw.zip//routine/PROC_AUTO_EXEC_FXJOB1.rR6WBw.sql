create procedure proc_auto_exec_FXjob1 as
begin
  declare
    job number;
    BEGIN
      DBMS_JOB.SUBMIT(
        JOB => job,  /*自动生成JOB_ID*/
        WHAT => 'FX_bal_principle;',  /*需要执行的过程或SQL语句*/
        NEXT_DATE => TRUNC(SYSDATE+1)+(15*60+40)/(24*60),  /*初次执行时间，13点*/
        INTERVAL => 'sysdate+2/24*60'  /*每天12点30分*/
      );
      COMMIT;

      DBMS_JOB.RUN(job);
    end;
end proc_auto_exec_FXjob1;

/

