create function getmanageorgname(pCustomerID varchar)
return varchar
is
pOrgName  varchar2(80);
begin
select getOrgName(OrgID) into pOrgName
  from CUSTOMER_BELONG
  where CustomerID = pCustomerID
  and BelongAttribute = '1';
return pOrgName;
end;

/

