create function getICRAssureType(pSerialNo varchar2)
 return varchar2
is
pGuarantyType varchar2(30);
pAllpGuarantyType varchar(400);
iGTypeSum integer;
iGAllSum integer;
iIndGuarnSum integer;
pReturnValue varchar(40);-- 1-????????2-???3-??????4-??/????5-???????????6-????????????7-?????9-???
--??????????????
CURSOR c_temp is
    select GC.GuarantyType from GUARANTY_RELATIVE GR,GUARANTY_CONTRACT GC,BUSINESS_DUEBILL BD where BD.RelativeSerialNo2=GR.ObjectNo and GR.ContractNo=GC.SerialNo and BD.SerialNo=pSerialNo and GR.ObjectType='BusinessContract';
begin
  pAllpGuarantyType := '';
  pGuarantyType := '';
  pReturnValue := '';
  iGTypeSum := 0;
  iGAllSum := 0;
  --??????????
  select count(GC.GuarantyType) into iIndGuarnSum from GUARANTY_RELATIVE GR,GUARANTY_CONTRACT GC,BUSINESS_DUEBILL BD where BD.RelativeSerialNo2=GR.ObjectNo and GR.ContractNo=GC.SerialNo and BD.SerialNo=pSerialNo and GR.ObjectType='BusinessContract' and GC.GuarantyType in('010010','010020','010030') and GC.CertType like 'Ind%';
  --???????????????
  OPEN c_temp;
 LOOP
  FETCH c_temp INTO pGuarantyType;
  EXIT WHEN c_temp%NOTFOUND;
	pAllpGuarantyType := pAllpGuarantyType||','||pGuarantyType;
	iGAllSum := iGAllSum +1;
 end loop;
 --????????
 if pAllpGuarantyType like '%010030%' or pAllpGuarantyType  like '%010020%' or pAllpGuarantyType  like '%010010%' then iGTypeSum := iGTypeSum+1;
 end if;
 --????????
 if pAllpGuarantyType like '050%'  then iGTypeSum := iGTypeSum+1;
 end if;
 --????????
 if pAllpGuarantyType like '060%' or pAllpGuarantyType  like '%010040%' then iGTypeSum := iGTypeSum+1;
 end if;

 --??????????????? 4 ??/???
 if iGTypeSum = 0 then pReturnValue := '4';
 end if;
 --???????????? 1-?? ,2-?? ,3-?????
 if iGTypeSum = 1 then
 	--??
 	if pAllpGuarantyType like '050%' then pReturnValue := '2';
 	end if;
 	--??(?????)
 	if pAllpGuarantyType like '060%' or pAllpGuarantyType  like '%010040%' then pReturnValue := '1';
 	end if;
 	--??????
	if pAllpGuarantyType like '%010030%' or pAllpGuarantyType  like '%010020%' or pAllpGuarantyType  like '%010010%' then
	 	if iIndGuarnSum = iGAllSum then pReturnValue := '3';
	 	else if iIndGuarnSum>0 then pReturnValue := '5';
		else pReturnValue := '9';
		end if;
		end if;
    end if;
 end if;
 --??????????? 5 6 ??
 if iGTypeSum > 1 then
 	if iIndGuarnSum = 0 then pReturnValue := '6';
 	else pReturnValue := '5';
 	end if;
 end if;

 --?????? 9 ??
 if pReturnValue is null then pReturnValue := '9';
 end if;
 return pReturnValue;
end ;

/

