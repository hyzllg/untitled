create FUNCTION getflowname(sFlowNo varchar)
return varchar
is sFlowName varchar(80);
begin
select FlowName into sFlowName from FLOW_CATALOG
where FlowNo = sFlowNo;
return sFlowName;
end;

/

