create function getremark(serialnoArg in varchar2)
--备注
return varchar2
is remark varchar2(400);
begin
  select distinct fo.phaseopinion3 into remark
   from reason_param ra, flow_opinion fo
   where reasontype = '10'
   and fo.phaseno = ra.phaseno
   and fo.phaseno = '0030'
   and fo.reasoncode1 = ra.mainreasoncode
   and fo.opinionno = (select max(fo1.opinionno) from flow_opinion fo1 where objectno=serialnoArg);
  return(remark);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getremark;

/

