create function getwormtime(serialnoArg in varchar2)
return varchar2
is signtime varchar2(20) ;
begin
select to_char((SYSDATE - to_date(ft.START_DATE,'yyyy/MM/dd'))*12/365) into signtime
  from customer_work ft
 WHERE  ft.customerid = serialnoArg;
   if signtime is not null then
     if(signtime<=3) THEN SIGNtime:='1' ;
     ELSIF (3<signtime AND signtime<=6) THEN signtime:='2' ;
       ELSIF (6<signtime AND signtime<=12) THEN signtime:='3';
         ELSIF(12<signtime AND signtime<=24) THEN signtime:='4' ;
           ELSIF(24<signtime AND signtime<=36) THEN signtime:='5' ;
             ELSIF (signtime>36) THEN signtime:='6' ;

     else signtime:='无' ;
     end if;
   end if;
  return signtime;
END  GETworkTIME;

/

