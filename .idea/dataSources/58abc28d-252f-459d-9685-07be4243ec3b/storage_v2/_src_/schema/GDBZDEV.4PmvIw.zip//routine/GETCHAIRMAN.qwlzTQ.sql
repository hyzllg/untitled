create function GETCHAIRMAN(useridArg in varchar2)
return  varchar2
is chairman varchar2(20) ;
begin
select ui1.userid into chairman
  from user_info ui1, user_info ui2
 where ui1.belongteam = ui2.belongteam
   and ui1.position = '061'
   and ui2.userid = useridArg;
  return chairman ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     --DBMS_OUTPUT.put_line(SQLERRM);
  return '';
  WHEN OTHERS THEN
    --DBMS_OUTPUT.put_line(SQLERRM);
  return '';

end GETCHAIRMAN;

/

