create FUNCTION GETCHECKNAME(pSerialno varchar,pPhaseno varchar)
--获取流程操作人名称
return varchar
is userName varchar(200);
begin
   select username into userName
   from flow_task
   where serialno=(select serialno from (select serialno from flow_task
       where  objectno=pSerialno and phaseno=pPhaseno
       order by begintime desc
       ) where rownum=1 );
   return userName;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

