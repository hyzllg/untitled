create FUNCTION         countsort3(sReportNo in varchar2)
return integer is
  Counts  integer;
begin
  Counts := 0;
  if Counts = 0 then
    select count(*) into Counts from icr_rpt_t46 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t48 where rptno = sReportNo;
  end if;
  if Counts = 0 then
    select count(*) into Counts from icr_rpt_t52 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t54 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t73 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t70 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t71 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t78 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t79 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t77 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t76 where rptno = sReportNo;
  end if;
    if Counts = 0 then
    select count(*) into Counts from icr_rpt_t72 where rptno = sReportNo;
  end if;
  return(Counts);
end;

/

