create PACKAGE         dw_getdimwid_pkg IS

  -- get_month_wid
  FUNCTION get_month_wid(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE;

  -- get_last_month_wid
  FUNCTION get_last_month_wid(p_month_wid VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE;

  -- get_last_year_month_wid
  FUNCTION get_last_year_month_wid(p_month_wid VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE;

  -- get_last_year_end_month_wid
  FUNCTION get_last_year_end_month_wid(p_month_wid VARCHAR2)
    RETURN dw_gd_month_d.month_wid%TYPE
    PARALLEL_ENABLE;

  -- get_last_period_name
  FUNCTION get_last_period_name(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_name%TYPE
    PARALLEL_ENABLE;

  -- get_last_year_period_name
  FUNCTION get_last_year_period_name(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_name%TYPE
    PARALLEL_ENABLE;

  -- get_last_year_end_period_name
  FUNCTION get_last_year_end_period_name(p_period_name VARCHAR2)
    RETURN dw_gd_month_d.month_name%TYPE
    PARALLEL_ENABLE;

END dw_getdimwid_pkg;

/

