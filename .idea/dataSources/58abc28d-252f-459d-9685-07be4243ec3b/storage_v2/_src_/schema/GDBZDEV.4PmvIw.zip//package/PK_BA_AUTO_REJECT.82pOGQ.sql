create package pk_ba_auto_reject is

  -- Author  : LINCM
  -- Created : 2016/1/4 17:16:37
  -- Purpose :

  /**
  * 申请阶段自动拒绝处理
  */
  procedure sp_ba_apply_auto_reject(pi_ba_serial_no  in varchar2, -- 申请编号
                                    pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2); -- 拒绝原因

  /**
  * 质检审批阶段自动拒绝处理
  */
  procedure sp_ba_audit_auto_reject(pi_ba_serial_no  in varchar2, -- 申请编号
                                    pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2); -- 拒绝原因
 /**
 * 复核阶段自动拒绝
**/
  procedure sp_ba_audit_auto_reject_for_gd(pi_ba_serial_no  in varchar2, -- 申请编号
                                    pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2); -- 拒绝原因

end pk_ba_auto_reject;

/

