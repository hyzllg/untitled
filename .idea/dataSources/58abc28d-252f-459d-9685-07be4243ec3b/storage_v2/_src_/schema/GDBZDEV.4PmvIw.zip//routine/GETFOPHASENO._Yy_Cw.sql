create FUNCTION getFOPhaseNo(pObjectNo varchar, pObjectType varchar)
return varchar
is returnPhaseno varchar2(100);
   rcertid varchar2(100);
   countNum number(1);
   flag varchar2(1);
begin
   if pObjectType='TeleSaleApply' then ---若是电销进件
       select rsa.creditid into rcertid from retail_sales_apply rsa,flow_object fo where rsa.serialno=fo.objectno and fo.objecttype=pObjectType and fo.objectno=pObjectNo;
       select count(1) into countNum from flow_object ft, business_apply bt, customer_info ci where ft.objectno = bt.serialno and bt.customerid=ci.customerid and ft.flowno='CreditFlow' and ft.phasetype <=1000 AND nvl(bt.putoutflag,'1') IN ('1','10','4','7','8') and ci.certid=rcertid and instr(nvl(bt.businesstypename,'NONE'),'追加贷')=0;
       ---优先校验在途申请
       ---有在途申请
       if countNum>0 then
         flag:='Y'; ---无需再走下去了
       else
         flag:='N';
       end if;

       ---无在途申请
       if flag='N' then
         select PhaseNo into returnPhaseno from Flow_Object where ObjectType=pObjectType and ObjectNo=pObjectNo;
       else
         returnPhaseno:='ZAITU';
       end if;
   else   ---非电销进件
       select PhaseNo into returnPhaseno from Flow_Object where ObjectType=pObjectType and ObjectNo=pObjectNo;
   end if;
   return returnPhaseno;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

