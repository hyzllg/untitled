create function GetFOBusinessNum(serialnoArg in varchar2)
--获取Flow_opinion审批金额
return varchar2
is CountBusinessSum varchar2(20);
begin
  select trim(to_char(fo.businesssum,'99999990.99')) into CountBusinessSum
  from flow_opinion fo
  where fo.opinionno =
      ( select max(opinionno)
                 from flow_opinion where phaseno in ('0030','0035','0040','0045','0047') and objectno=serialnoArg);
  return CountBusinessSum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFOBusinessNum;
/

