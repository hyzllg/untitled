create FUNCTION getAppointmentTime(pRelserialno varchar)
return varchar
is pAppointmentTime  varchar(40);
begin
	select AppointmentTime into pAppointmentTime
	from telsignrecord
	where relserialno=pRelserialno;
	return pAppointmentTime;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
END getAppointmentTime;
/

