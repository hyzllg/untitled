create FUNCTION getsalesdirectorname(pSerialnoID varchar)
return varchar
is pSalesdirectorName  varchar(80);
begin
select salesdirectorname into pSalesdirectorName
  from business_apply
where serialno = pSerialnoID;
  return pSalesdirectorName;
end;
/

