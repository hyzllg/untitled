create FUNCTION getrecommend(pSerialno varchar)
return varchar
is
 pItemName varchar(80);
 pSegmentrecommend varchar(80);
begin
  select Segmentrecommend into pSegmentrecommend
  from business_apply
  where serialno = pSerialno;
  pItemName:='';
  select ItemName into pItemName
  from Code_Library
  where CodeNo='YesNo' and ItemNo=pSegmentrecommend;
  return pItemName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

