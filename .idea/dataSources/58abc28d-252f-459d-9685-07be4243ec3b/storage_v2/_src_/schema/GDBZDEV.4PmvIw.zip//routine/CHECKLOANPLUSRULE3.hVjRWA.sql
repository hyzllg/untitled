create Function         checkLoanPlusRule3 ( pCertID IN varchar2 ) RETURN varchar2
IS
     ret varchar2(10);
     ICount number(6);
     IMonthBtw number(10);
     DXSerialNo varchar2(20);
     sMAXPhaseno varchar2(20);
     sOrderDate varchar2(20);
     sEndtime varchar2(20);
BEGIN
     select count(1) into ICount
     from acct_loan al,customer_info ci,business_type bt,acct_payment_schedule aps,business_apply ba
     where al.CUSTOMERID=ci.customerid
       and al.businesstype=bt.typeno
       and aps.objectno=al.serialno
       and al.baserialno=ba.serialno

     --3.当前非逾期状态（注：历史有逾期记录但当前状态非逾期的客户，符合要求）
     and al.overduedays=0
     and ci.certid=pCertID;

     IF ICount=0 THEN
        ret := 'Betray';
     ELSE
        ret := 'LOVE';
     END IF;
     RETURN ret;
END;

/

