create function getpaydate4(serialnoArg in varchar2)
--获得最近一次逾期日期
return varchar2
IS
  paydate varchar2(20);
  finishdate varchar2(20);
begin
  select case when loanstatus in('90','91','92') then 'true' else 'false' end  into paydate from acct_loan where baserialno=serialnoArg ;
  SELECT CASE WHEN finishdate IS NULL THEN 'Yes' ELSE 'No' END INTO finishdate FROM acct_payment_schedule WHERE baserialno = serialnoArg AND serialno =
  (SELECT MAX(serialno) FROM acct_payment_schedule WHERE baserialno = serialnoArg and to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate));
  IF paydate='true' THEN
      SELECT MIN(paydate) INTO paydate FROM acct_payment_schedule
      where baserialno = serialnoArg
      AND finishdate = (SELECT MAX(finishdate) FROM acct_payment_schedule WHERE baserialno = serialnoArg and to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate));
  ELSE
      if finishdate='Yes' then
      select MIN(paydate)
        into paydate
        from acct_payment_schedule
       where baserialno = serialnoArg
       AND finishdate IS NULL and to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate);
     else
       select max(paydate)
        into paydate
        from acct_payment_schedule
       where baserialno = serialnoArg
         and paydate < finishdate and to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate);
     end if;
  END IF;
  return(paydate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getpaydate4;
/

