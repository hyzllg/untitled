create FUNCTION GETJOBTYPE(pUserid varchar2)
    return varchar2
    is pJobType  varchar2(500);
    begin
    select nvl(pJobType,'') into pJobType
      from user_info
   where userid = pUserid;
  return pJobType;
end;
/

