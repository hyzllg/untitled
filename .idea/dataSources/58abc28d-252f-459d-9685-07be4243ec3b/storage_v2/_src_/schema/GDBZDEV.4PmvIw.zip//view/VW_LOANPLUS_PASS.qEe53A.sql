create view VW_LOANPLUS_PASS as
select
serialno             ,
objectno             ,
customerid           ,
city                 ,
obusinesstype        ,
obusinesssum         ,
opolicyrate          ,
oputoutdate          ,
oloanterm            ,
orepayloanterm       ,
oinputorgid          ,
nbusinesstype        ,
nbusinesstypename    ,
ilogbusinesssum      ,
ilogpolicyrate       ,
inputdate            ,
real_serialno        ,
batchno              ,
passcount            ,
lastnewapprovalno    ,
channelname          ,
activeloanscorev5    ,
totalscorev5         ,
digitalinterpretscore,
pbscore
from GDBZDEV.loanplus_pass
/

