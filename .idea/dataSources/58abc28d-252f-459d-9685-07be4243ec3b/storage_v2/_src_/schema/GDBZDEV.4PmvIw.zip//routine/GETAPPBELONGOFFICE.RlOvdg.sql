create function getAppBelongOffice(pSerialno in VARCHAR2)
--获取展业app的归属营业部
return VARCHAR2
IS sInputDate VARCHAR2(20);
   sSalesUserID VARCHAR2(100);
   sBelongTeam VARCHAR2(32);
   sBelongoffice VARCHAR2(100);
   sBelongofficeName VARCHAR2(100);
BEGIN
   SELECT nvl(inputDate,to_char(SYSDATE,'yyyy/MM/dd')),salesuserid INTO sInputDate,sSalesUserID FROM business_apply WHERE serialno = pSerialno;
   select belongteam into sBelongTeam from user_info where userid = sSalesUserID;
   select oi.Belongoffice INTO sBelongoffice from org_info oi where oi.orgid = sBelongTeam
and oi.Officeeffecttime <= sInputDate and oi.Status='1';
   SELECT orgname INTO sBelongofficeName FROM org_info WHERE orgid = sBelongoffice;
  return sBelongofficeName;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getAppBelongOffice;
/

