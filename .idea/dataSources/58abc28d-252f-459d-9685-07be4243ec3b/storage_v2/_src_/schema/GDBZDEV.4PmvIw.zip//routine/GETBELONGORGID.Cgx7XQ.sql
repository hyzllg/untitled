create FUNCTION GetBELONGORGID(pOrgID varchar2)
return varchar2
is
 pRelativeOrgID  varchar2(80) ;
begin
 select BELONGORGID into pRelativeOrgID from ORG_INFO where OrgID = pOrgID;
 return pRelativeOrgID;
end ;

/

