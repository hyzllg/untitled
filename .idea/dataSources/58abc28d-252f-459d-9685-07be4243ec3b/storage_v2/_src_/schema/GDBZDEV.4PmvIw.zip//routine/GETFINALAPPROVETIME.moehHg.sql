create function getfinalapprovetime(serialnoArg in varchar2)
--终审时效
return varchar2

is
  times varchar2(30);
begin
  SELECT
   EXTRACT(DAY FROM (decode(GetFinalEndTime(serialnoArg),'',sysdate,to_date(GetFinalEndTime(serialnoArg),'YYYY/MM/DD HH24:MI:ss'))-to_date(getfinaltaskdate(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'天'
   || EXTRACT(HOUR FROM (decode(GetFinalEndTime(serialnoArg),'',sysdate,to_date(GetFinalEndTime(serialnoArg),'YYYY/MM/DD HH24:MI:ss'))-to_date(getfinaltaskdate(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'时'
   || EXTRACT(MINUTE FROM (decode(GetFinalEndTime(serialnoArg),'',sysdate,to_date(GetFinalEndTime(serialnoArg),'YYYY/MM/DD HH24:MI:ss'))-to_date(getfinaltaskdate(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'分' into times
FROM DUAL;
  return(times);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfinalapprovetime;
/

