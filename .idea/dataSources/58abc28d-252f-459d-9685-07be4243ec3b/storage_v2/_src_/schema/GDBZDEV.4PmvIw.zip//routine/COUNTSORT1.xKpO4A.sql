create FUNCTION         countsort1(sReportNo IN VARCHAR2)
RETURN INTEGER IS Counts INTEGER;
BEGIN
  Counts :=0;
  IF Counts = 0 THEN
      SELECT COUNT(1) INTO Counts FROM icr_rpt_t22 WHERE rptno = sReportNo;
      END IF;
      IF Counts = 0 THEN
        SELECT COUNT(1) INTO Counts FROM icr_rpt_t23 WHERE rptno = sReportNo;
        END IF;
        IF Counts = 0 THEN
         SELECT COUNT(1) INTO Counts FROM icr_rpt_t24 WHERE rptno= sReportNo;
         END IF;
         IF Counts = 0 THEN
           SELECT COUNT(1) INTO Counts FROM icr_rpt_t25 WHERE rptno= sReportNo;
           END IF;
           IF Counts = 0 THEN
           SELECT COUNT(1) INTO Counts FROM icr_rpt_t26 WHERE rptno= sReportNo;
           END IF;
            IF Counts = 0 THEN
           SELECT COUNT(1) INTO Counts FROM icr_rpt_t27 WHERE rptno= sReportNo;
           END IF;
           RETURN Counts;
           END;

/

