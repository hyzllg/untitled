create function getoutteam(manuidArg in varchar2)
--获取委外小组名
return varchar2
is
  teamId varchar2(20);
begin
 select teamid into teamId from out_manufacturer omf where omf.manuid = manuidArg;

  return(teamId);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getoutteam;
/

