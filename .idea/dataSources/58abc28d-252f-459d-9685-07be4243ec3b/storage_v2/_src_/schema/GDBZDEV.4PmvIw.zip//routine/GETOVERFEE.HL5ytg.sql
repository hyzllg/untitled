create function getoverfee (serialnoArg in varchar2)
--获取溢缴金额
return varchar2
is
  overfee number(24,6);
begin
  select nvl(actualcredere, 0) - nvl(paycredere, 0) into overfee
    from acct_recovery_loss
   where serialno = (select serialno
                       from acct_loan
                      where finishdate is not null
                        and serialno = serialnoArg);
  return(overfee);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getoverfee ;
/

