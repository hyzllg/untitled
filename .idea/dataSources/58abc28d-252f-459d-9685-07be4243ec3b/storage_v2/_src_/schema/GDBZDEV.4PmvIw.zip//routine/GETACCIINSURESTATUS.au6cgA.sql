create FUNCTION getAcciInsureStatus(pcertid varchar,priskCode varchar, pinsurestatus varchar)
return varchar
is  res  varchar(10);
begin
  res:='';
  select nvl(ia.insurestatus,pinsurestatus) into res
  from insure_apply ia
  where ia.certid=pcertid and ia.riskcode=priskCode and insurestatus='1' and rownum=1;
  return res;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '0';
  WHEN OTHERS THEN
  return pinsurestatus;
end;
/

