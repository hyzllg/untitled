create function getCurrentTime
--获取数据库当前时间
return varchar2
is
sTime       varchar2(20);
begin

   select to_char(sysdate,'yyyy/mm/dd hh24:mi:ss') into sTime from dual;
   return sTime;

end;
/

