create function GetFinalBeginTime(serialnoArg in varchar2)
--获取进入终审时间
return varchar2
is FinalBeginTime  varchar2(200) ;
begin
   select begintime into FinalBeginTime
     from flow_task
    where phaseno = '0040'
      and serialno =
          (select max(serialno)
             from flow_task where phaseno = '0040' and objectno = serialnoArg);
  return FinalBeginTime;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFinalBeginTime;

/

