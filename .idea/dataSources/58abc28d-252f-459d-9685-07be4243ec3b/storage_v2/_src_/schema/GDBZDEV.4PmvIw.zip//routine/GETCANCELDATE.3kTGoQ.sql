create function getCancelDate(serialnoArg in varchar2)
--获取取消日期
return varchar2
is canceltime  varchar2(20) ;
begin
SELECT NVL(ft.endtime,'xx') into canceltime
  from flow_task ft
 where ft.flowno = 'CreditFlow'
   and ft.phaseno in
       ('2020', '2010', '2070', '2050', '2000', '2060', '2030','2090','2095')
   and ft.objectno = serialnoArg;
   if canceltime ='xx' then
     SELECT updatedate into canceltime from ApplyPolicyNo where status='4' and applyno=serialnoArg;
   end if;
  return canceltime;
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getCancelDate;

/

