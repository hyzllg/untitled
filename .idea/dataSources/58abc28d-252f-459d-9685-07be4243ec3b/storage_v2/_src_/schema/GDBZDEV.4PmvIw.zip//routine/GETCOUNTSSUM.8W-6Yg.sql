create function GETCOUNTSSUM(serialnoArg in varchar2)
--获取理论审批金额
return varchar2
is CountBusinessSum varchar2(20);
begin
select distinct LAST_VALUE(COUNTBUSINESSSUM) OVER(PARTITION BY objectno ORDER BY serialno rows between unbounded preceding and unbounded following )
into CountBusinessSum from flow_opinion where  updatetime is not null
and phaseno in('0030','0035','0045','0040','0047') and objectno=serialnoArg;

return CountBusinessSum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GETCOUNTSSUM;

/

