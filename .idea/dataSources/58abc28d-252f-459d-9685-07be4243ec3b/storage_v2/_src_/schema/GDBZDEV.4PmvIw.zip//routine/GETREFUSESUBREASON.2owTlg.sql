create function GetRefuseSubReason(serialnoArg in varchar2)
--获取拒绝子原因
return varchar2
is refuseMainReason  varchar2(200) ;
begin
  select phaseopinion2 into refuseMainReason
  from flow_opinion
 where (phasechoice like '%未通过%' or phasechoice like '%拒绝%')
 and reasoncode1 is not null
 and reasoncode2 is not null
 and serialno = (select max(serialno)
                     from flow_opinion
                    where objectno=serialnoArg);
  return refuseMainReason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetRefuseSubReason;

/

