create function getCSManageOrg(serialnoArg in varchar2)
--获取催收管理门店
return varchar2
is cslastorgid varchar2(100);
begin
  select lastorgid into cslastorgid
     from  collection_info where isinuse='1' and lnsacct=serialnoArg ;
  return cslastorgid;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getCSManageOrg;
/

