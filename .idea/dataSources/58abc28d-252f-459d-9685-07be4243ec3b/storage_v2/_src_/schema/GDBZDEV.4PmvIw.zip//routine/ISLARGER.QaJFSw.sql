create function ISLARGER(pObject in number, pNum in number)
return integer
is
------------------------------------------------------
--判断两数之间的大小，若对象数大于比较数返回 1 ，反之，返回 0
--RINK 2004-11-8
------------------------------------------------------
  v_Result integer;
begin
  v_Result := 0;
  IF (pObject >= pNum) THEN
	RETURN 1;
  END IF ;
  return(v_Result);
end ISLARGER;

/

