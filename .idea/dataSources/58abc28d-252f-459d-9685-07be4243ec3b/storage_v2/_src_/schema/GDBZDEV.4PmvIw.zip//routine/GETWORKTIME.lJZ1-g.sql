create function GETworkTIME(serialnoArg in varchar2)
return varchar2
is signtime varchar2(20) ;
begin
select to_char(round((SYSDATE - to_date(ft.START_DATE,'yyyy/MM/dd'))*12/365,2)) into signtime
  from customer_work ft
 WHERE  ft.customerid = serialnoArg;
   if signtime is not null then
     if(signtime<=3) THEN SIGNtime:='3001' ;
     ELSIF (3<signtime AND signtime<=6) THEN signtime:='3002' ;
       ELSIF (6<signtime AND signtime<=12) THEN signtime:='3003';
         ELSIF(12<signtime AND signtime<=24) THEN signtime:='3004' ;
           ELSIF(24<signtime AND signtime<=36) THEN signtime:='3005' ;
             ELSIF (signtime>36) THEN signtime:='3006' ;

     else signtime:='3001' ;
     end if;
   end if;
  return signtime;
END  GETworkTIME;

/

