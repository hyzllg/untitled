create function firoverdue30(serialnoArg in varchar2)
--获得首次逾期30天日期
return varchar2
is
  paytype varchar2(20);
  paydate1 carchar2(20);

begin
  select case when loanstatus in('90','91','92') then 'true' else 'false' end  into paytype from acct_loan where baserialno=serialnoArg ;
  if paytype='true' then

 select  paydate into paydate1 from
 (select  paydate,months_between(lead(to_date(paydate, 'yyyy/mm/dd'),1) over(order by seqid),to_date(paydate, 'yyyy/mm/dd') )as diff,
 rownum rn
    from acct_payment_schedule
   where to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate)
     and nvl(finishdate,'2999/12/31')>paydate
     and baserialno = serialnoArg ) where rn=2 and diff=1;

 else
 select  paydate into paydate1 from
 (select  paydate,months_between(lead(to_date(paydate, 'yyyy/mm/dd'),1) over(order by seqid),to_date(paydate, 'yyyy/mm/dd') )as diff,
 rownum rn
    from acct_payment_schedule
   where to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate)
     and (finishdate is null or finishdate >paydate)
     and baserialno = serialnoArg ) where rn=2 and diff=1;
 end if;
  return(paydate1);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end firoverdue30;

/

