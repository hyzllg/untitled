create FUNCTION getMaxFtUserName(sobjectno varchar,sphaseno varchar)
return varchar
is  mUserName  varchar(200);
begin
  mUserName:='';
  select ft.userid||' '||ft.username into mUserName
  from flow_task ft
  where ft.serialno=(select max(ftt.serialno) from flow_task ftt where ftt.objectno=(select max(bci.serialno) from bankclaimtaskinfo bci where bci.lnsacct=sobjectno ) and ftt.phaseno=sphaseno);
  return mUserName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

