create FUNCTION nvl(PString VARCHAR, PToString VARCHAR)
  RETURN VARCHAR is
  pReturn VARCHAR(1000);
BEGIN
  if (PString is null) then
    pReturn := PToString;
  ELSE
    pReturn := PString;
  END IF;
  return pReturn;
END;

/

