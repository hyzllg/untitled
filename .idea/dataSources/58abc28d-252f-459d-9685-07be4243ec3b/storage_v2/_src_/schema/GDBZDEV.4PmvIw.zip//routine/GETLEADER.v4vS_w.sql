create FUNCTION GETLEADER(teamidArg in varchar2)
return varchar2
is
  leadername varchar2(20);
begin
  select username into leadername
    from user_info ui, user_role ur
   where ui.teamid = (select teamid
                        from urge_team_info uti
                       where uti.teamid = teamidArg)
     and ui.userid = ur.userid
     and ur.roleid = '612';

  return(leadername);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getleader;
/

