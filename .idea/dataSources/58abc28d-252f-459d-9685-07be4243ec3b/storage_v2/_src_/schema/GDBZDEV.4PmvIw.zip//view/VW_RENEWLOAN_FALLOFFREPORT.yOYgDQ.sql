create view VW_RENEWLOAN_FALLOFFREPORT as
select
serialno    ,
ruleno      ,
rulemainname,
rulecount   ,
batchno     ,
updatetime
from GDBZDEV.renewloan_falloffreport
/

