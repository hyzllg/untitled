create FUNCTION getteamleader(pteamid varchar)
--获取团队的所有的组长
return varchar
is pUserName  varchar(80);
begin
select listagg(username,',')within group (order by username) into pUserName from
(select ui.userid,ui.username,ui.teamid from user_info ui where ui.userid in
(select ur.userid from user_role ur where ur.roleid in ('612','614','616','618','619','621','622') and ur.status='1')
and ui.teamid is not null and status='1') where teamid = pteamid;
return pUserName;
end getteamleader;
/

