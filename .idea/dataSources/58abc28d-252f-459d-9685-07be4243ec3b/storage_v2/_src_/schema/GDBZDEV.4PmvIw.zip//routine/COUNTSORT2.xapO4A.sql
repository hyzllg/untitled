create FUNCTION         countsort2(sReportNo in varchar2)
return integer is
  Counts  integer;
begin
  Counts := 0;
  if Counts = 0 then
    select count(*) into Counts from icr_rpt_t30 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t32 where rptno = sReportNo;
  end if;
  if Counts = 0 then
    select count(*) into Counts from icr_rpt_t33 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t40 where rptno = sReportNo;
  end if;
   if Counts = 0 then
    select count(*) into Counts from icr_rpt_t43 where rptno = sReportNo;
  end if;
  return(Counts);
end;

/

