create view VW_LOANPLUS_TENRULESRECORDS_R7 as
select
serialno        ,
batchno         ,
baserialno      ,
ruleflag        ,
customertype    ,
businesstype    ,
businesstypename,
businesssum     ,
putoutdate      ,
loanterm        ,
inputorgid      ,
fee1rate        ,
residueterm     ,
customerid      ,
created_date
from GDBZDEV.loanplus_tenrulesrecords_r7
/

