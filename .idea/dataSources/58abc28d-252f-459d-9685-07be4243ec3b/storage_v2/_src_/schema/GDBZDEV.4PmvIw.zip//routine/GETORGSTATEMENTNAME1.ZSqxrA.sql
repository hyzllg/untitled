create FUNCTION getOrgStatementName1(pOrgid varchar)
	return varchar2 is pOrgName varchar2(80);
	begin
	select OrgName into pOrgName
	from Org_Statement_Info_New
 	where Orgid = pOrgID;
 	return pOrgName;
 	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
  end;
/

