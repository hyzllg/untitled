create function getnumber2(idArg in varchar2,isGuaranty in varchar2)
--获得某催收员下昨天下了code命令的案件数目
 return integer is
  num integer;
begin
  select count(1) into num
    from collection_info
   where serialno in
         (select relserialno
            from cuishou_remark
           where substr(remarktime, 1, 10) = select to_char(trunc(sysdate-1),'yyyy/MM/dd') from dual)
     and collectionuserid = idArg and isguaranty = isGuaranty and isinuse = '1';
  return(num);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getnumber2;
/

