create function isdate(mydate in varchar2) return char is
  tmp date;
begin
  tmp := to_date(mydate, 'yyyy/mm');
  return '1';
exception
  when others then
    return '0';
end isdate;
/

