create function getyyRemark(SerialNoArg in varchar2)
--电销得到预约备注
return varchar2
is
  baserialno varchar2(32);
  PhaseOpinion varchar2(3000);
begin
  select rs.baserialno into baserialno from retail_sales_apply rs where rs.serialno=SerialNoArg;
  if baserialno is null then
    select phaseopinion||' '||phaseopinion3 into PhaseOpinion from flow_opinion fo where
fo.phaseno='6002'  and  fo.serialno in
(select max(serialno) from flow_opinion where objectno=SerialNoArg and objecttype='TeleSaleApply' and phaseno='6002')
AND fo.objecttype='TeleSaleApply' and fo.objectno=SerialNoArg;
  else
    select fo.phaseopinion into  PhaseOpinion from flow_opinion fo where   fo.phasechoice like '%终止%' and fo.objecttype='CreditApply' and fo.objectno in
       (select rs.baserialno from retail_sales_apply rs where rs.serialno=SerialNoArg );
  end if;
 return(PhaseOpinion);

  EXCEPTION

  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getyyRemark;
/

