create FUNCTION getH5(pSerialNo varchar)
/**
* 获取电销H5标识 2018/11/06
*/
return varchar
is  pReason  varchar(600);
begin
  pReason:='';
  select isH5 into pReason from CreditAuditTable where serialno=pSerialNo;
  if pReason is null then
            return '';
  else
            return pReason;
  end if;
end;
/

