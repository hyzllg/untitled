create FUNCTION gettermname(pTermType varchar,pTermId varchar)
return varchar
is  pTermname  varchar(200);
begin
  pTermname:='';
  select termname into pTermname
  from acct_term_library
  where TermType=pTermType and TermId=pTermId AND status ='1';
  if pTermname is null then
            return pTermId;
  else
            return pTermname;
  end if;
end;

/

