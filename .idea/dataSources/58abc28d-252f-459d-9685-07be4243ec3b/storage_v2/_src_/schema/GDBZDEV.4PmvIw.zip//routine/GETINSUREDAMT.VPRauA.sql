create FUNCTION getInsuredAmt(pserialno varchar)
return Number
is  insuredAmt  number(20,2);
begin
  insuredAmt:='';
  select round(nvl2(ba.policyRatio,ba.signsum*ba.policyRatio,ba.signsum * (1 + 0.063 * ba.signterm / 12)),2) into insuredAmt
  from business_apply ba where ba.serialno=pserialno;
  return insuredAmt;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return null;
  WHEN OTHERS THEN
  return null;
end;
/

