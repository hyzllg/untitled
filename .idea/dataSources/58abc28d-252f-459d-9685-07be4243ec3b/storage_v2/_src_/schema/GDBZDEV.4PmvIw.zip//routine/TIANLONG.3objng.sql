create procedure tianlong(SS in varchar2) as
       begin
              update business_apply set approvesum=(select approvesum from ds_business_apply where objectno=SS and status='1') where serialno=SS and channelcode='partner001';
              update flow_task fo set fo.orgname=(select ui.orgname from org_info ui where ui.orgid=fo.orgid) where fo.objectno=SS and fo.phaseno='0020' and fo.orgname is null and fo.orgid is not null;
              commit;
       end tianlong;
/

