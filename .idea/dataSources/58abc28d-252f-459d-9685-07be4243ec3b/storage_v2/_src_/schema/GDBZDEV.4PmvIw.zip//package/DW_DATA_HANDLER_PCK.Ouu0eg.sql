create PACKAGE         dw_data_handler_pck IS

   --dw_trailbalance_fs的预处理,主要求期初余额（科目不同，计算方式不同），再者使用预处理表只保存一个月数据，提高计算效率
   PROCEDURE gen_fst_trailbalance(p_period_name VARCHAR2);

   --dw_trailbalance_fs的处理, 主要计算上期，去年等不同期间下的度量数据，保存历史数据
   PROCEDURE gen_fs_trailbalance(x_return_status        OUT VARCHAR2,
                                 p_plan_node_control_id NUMBER,
                                 p_period_name          VARCHAR2,
                                 p_ledger_id            NUMBER);
END;

/

