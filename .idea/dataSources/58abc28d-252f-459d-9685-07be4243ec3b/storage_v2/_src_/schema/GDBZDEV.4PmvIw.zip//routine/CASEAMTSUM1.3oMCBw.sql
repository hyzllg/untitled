create function         caseamtsum1(idArg in varchar2,isinuseArg in integer,isguaranty in varchar2)
--获得某个委外厂商的新案或旧案的月初分案剩余总金额
return number
is
  amtsum number;
begin
  select sum(caseresidualamount) into amtsum
    from collection_info
   where collectionuserid = idArg
     and isinuse = isinuseArg and isguaranty = isguaranty;
  return(amtsum);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end caseamtsum1;

/

