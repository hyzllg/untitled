create function getCreditCardSixMUseRate(serialnoArg in varchar2)
--人行信用卡近6个月的使用率
return varchar2
is creditCardMaxNum  varchar2(200) ;
 irt22f8 varchar2(30);
 irt23f7 varchar2(30);
begin
  select to_char(to_number(nvl(irt22.f8,'0'))*6/to_number(nvl(irt22.f4,0)),'9999990.9999'),
         to_char(to_number(nvl(irt23.f7,'0'))*6/to_number(nvl(irt23.f4,0)),'9999990.9999') into irt22f8,irt23f7
    from ICR_RPT_T22 irt22,ICR_RPT_T23 irt23, icr_cda ic
   where ic.reportno = irt22.rptno
     and ic.reportno = irt23.rptno
     and ic.objectno = serialnoArg;
  if irt22f8>=irt23f7 then
    creditCardMaxNum:=irt22f8 ;
  else
    creditCardMaxNum:=irt23f7 ;
  end if;
  return creditCardMaxNum;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end getCreditCardSixMUseRate;

/

