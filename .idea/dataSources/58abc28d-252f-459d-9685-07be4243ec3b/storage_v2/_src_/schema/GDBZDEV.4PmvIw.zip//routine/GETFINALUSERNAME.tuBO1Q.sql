create function GetFinalUserName(serialnoArg in varchar2)
--获取终审姓名
return varchar2
is FinalUserName  varchar2(200) ;
begin
   select username into FinalUserName
     from flow_task
    where phaseno = '0040' and flowno='CreditFlow'
      and serialno =(select serialno from 
          (select serialno
             from flow_task where phaseno = '0040' and flowno='CreditFlow' 
             and objectno = serialnoArg order by begintime desc) where rownum=1);
  return FinalUserName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFinalUserName;
/

