create function GETLASTAPPLYTIME(serialnoArg in varchar2)
return varchar2
is LastApplyTime varchar2(20);
begin
  select to_char(max(to_date(al.bainputdate, 'yyyy/MM/dd')),'yyyy/MM/dd') into LastApplyTime
    from acct_loan al, business_apply ba
   where ba.customerid = al.customerid
     and al.baserialno !=serialnoArg
     and al.customerid= (select ba1.customerid from business_apply ba1 where ba1.serialno=serialnoArg);
  return LastApplyTime;
end GETLASTAPPLYTIME;

/

