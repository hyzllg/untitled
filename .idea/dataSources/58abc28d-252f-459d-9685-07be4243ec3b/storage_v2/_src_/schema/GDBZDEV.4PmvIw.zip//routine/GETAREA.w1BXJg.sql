create function GetArea(orgArg in varchar2)
--获取门店所在区域
 return varchar2 is
  vBelongArea varchar2(32);
  vBelongAreaName varchar2(32);
begin
  select t.belongarea
    into vBelongArea
    from org_info t
   where t.orgid = orgArg;
   select orgname into vBelongAreaName from org_info where orgid = vBelongArea;
  return vBelongAreaName;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end GetArea;
/

