create function getApproveSum(pStatus in VARCHAR2)
--获得最终的审批状态
return VARCHAR2
IS sSerialno VARCHAR2(50);
   sPhaseno  VARCHAR2(50);
BEGIN
	IF pStatus = '0050'
   SELECT MAX(serialno) INTO sSerialno FROM flow_task WHERE objecttype = 'CreditApply' AND objectno = pSerialno;
	 SELECT ft.phaseno INTO sPhaseno FROM flow_task ft WHERE ft.objecttype = 'CreditApply' AND ft.serialno = sSerialno;
  return sPhaseno;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getApproveSum;
--
case when ba.status = '0050' then BA.APPROVESUMED else null end as ApproveSum

--
GetFinalApproveSum


case when getApproveRefuse(BUSINESS_APPLY.serialno) in ('2040','3020','3021','3091','3092','3090')
	then BUSINESS_APPLY.APPROVEREFUSEREASON when getApproveRefuse(BUSINESS_APPLY.serialno)='3093'
		then getApproveMainReason(BUSINESS_APPLY.serialno)  else '' END
IN ('2040','3020','3021','3091','3092','3090')
create or replace function getMainReason(pSerialno in VARCHAR2)
--获得拒绝原因
return VARCHAR2
IS sSerialno VARCHAR2(50);
   sPhaseno  VARCHAR2(50);
	 sMainReasonCode  VARCHAR2(50);
	 MainReason  VARCHAR2(100);
BEGIN
	SELECT MAX(serialno) INTO sSerialno FROM flow_task WHERE objecttype = 'CreditApply' AND objectno = pSerialno;
	SELECT ft.phaseno INTO sPhaseno FROM flow_task ft WHERE ft.objecttype = 'CreditApply' AND ft.serialno = sSerialno;
  IF sPhaseno IN ('2040','3020','3021','3091','3092','3090') THEN
		 SELECT ba.APPROVEREFUSEREASON INTO MainReason FROM business_apply ba WHERE ba.serialno = pSerialno;
	elsif sPhaseno = '3093' THEN
		 SELECT DISTINCT primarycause INTO sMainReasonCode FROM STRATEGYRESULT WHERE objecttype = 'CreditApply' AND objectno = pSerialno AND  strategyresult = '3';
	   SELECT DISTINCT mainreason INTO MainReason FROM reason_param WHERE mainreasoncode = sMainReasonCode AND phaseno = '0030' AND subreason IS NOT NULL;
	ELSE
			SELECT '' INTO MainReason FROM dual;
	END IF;
	return MainReason;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getMainReason;

--
SELECT * FROM  STRATEGYRESULT WHERE  objectno = '2017062000000037';

IF sPhaseno = '3093' THEN
		 SELECT primarycause INTO MainReason FROM STRATEGYRESULT WHERE objecttype = 'CreditApply' AND objectno = pSerialno AND  strategyresult = '3';
	ELSE
			MainReason = '';
	END IF;

ELSE IF sPhaseno = '2040'	THEN
		 SELECT ba.APPROVEREFUSEREASON INTO MainReason FROM business_apply ba WHERE ba.serialno = pSerialno;
-----
getBelongTeam
		SELECT s.primarycause,s.*  FROM STRATEGYRESULT s WHERE objectno = '2017080900000056' FOR UPDATE ;
		--1	SP1	2017080900000033	2017080900000041	CreditApply	0	SP1	SP101	限制地区拒绝	2017/08/09 16:03:14	3
SELECT ''  FROM dual;
SELECT ba.IsMentionedFraud,ba.ISSUSPENDED,ba.* FROM business_apply ba WHERE serialno = '2017072800000052' FOR UPDATE ;--8000553898  8000553898  8000553898  8000533984
SELECT * FROM flow_task WHERE objectno IN ('2017072800000052','2017080800000200') FOR UPDATE ;
select ItemNo,ItemName from CODE_LIBRARY where CodeNo = 'StrategyResult' and isinuse='1'
SELECT '' INTO MainReason FROM dual;
SELECT * FROM flow_opinion
SELECT * FROM reason_param WHERE mainreasoncode = 'SP1';

select  strategyresult,message,SerialNo,inputtime from STRATEGYRESULT

select substr(max(t.approveendtime), 0, 10) from quality_apply t where t.approveendtime >= ''
and t.approveendtime < '" + endDate + "'
Select Count(1) From Quality_APPLY ft
where QualityMan ='OPS' And nvl(ft.STATUS,'0') = '0' and
substr(ft.approveendtime, 0, 10) =
(select substr(max(t.approveendtime), 0, 10) from quality_apply t where t.approveendtime >=	'2017/08/02 '
and t.approveendtime < '2017/08/10 ')

SELECT * FROM class_method FOR UPDATE  WHERE
"PublicMethod","DeleteUserRole"
--delete from quality_apply where QualityMan ='OPS' And nvl(STATUS,'0') = '0'
					t.QualityMan ='OPS' And nvl(t.STATUS,'0') = '0')
--PublicMethod 			DeleteQualityPool    DeleteUserRole
--
SELECT * FROM quality_apply

SELECT ba.approvesum,ba.businessSum,ba.lateststatus,ba.status,ba.* FROM business_apply ba WHERE serialno = '2017080900000056';--3093

getCaseStatusName1()

SELECT  getCaseStatusName1(BUSINESS_APPLY.lateststatus)  AS a  FROM business_apply WHERE serialno = '2017080900000041';			--3093
SELECT  ba.lateststatus,ba.*  FROM business_apply ba WHERE serialno = '2017080900000041';

SELECT * FROM dataobject_library WHERE dono = 'ApplyInfoPreson' FOR UPDATE;	--Customer_Work	  ApplyInfoPreson
CustomerInfoJob.jsp
--公用方法","GetColValue
SELECT * FROM Class_Method FOR UPDATE  WHERE classname = 'PublicMethod' AND methodname = 'GetColValue';
com.amarsoft.app.lending.bizlets.InitializeQualityAPPLYPool
--PublicMethod	 InsertQualityPool
String businesssum1,String businesssum2,String businessType,String ReturnStore,String FallBackReason,String SubFallBackReason,
String ReasonRefusal,String SubReasonRefusal,String ApprovalDate1,String ApprovalDate2

					SELECT getMainReason('2017080900000056') FROM dual
					SELECT * FROM flow_task WHERE objectno = '2017080900000056';
SELECT MAX(serialno)  FROM flow_task WHERE objecttype = 'CreditApply' AND objectno = '2017080900000056';
	SELECT ft.phaseno  FROM flow_task ft WHERE ft.objecttype = 'CreditApply' AND ft.serialno = '2017081100000025';
	3093
	SELECT t.message,t.* FROM STRATEGYRESULT t WHERE objecttype = 'CreditApply' AND objectno = '2017080900000056' AND  strategyresult = '3' ;
SELECT DISTINCT primarycause INTO MainReason FROM STRATEGYRESULT WHERE objecttype = 'CreditApply' AND objectno = pSerialno AND  strategyresult = '3';
SELECT mainreason INTO mainreason FROM reason_param WHERE mainreasoncode = 'SP1' AND phaseno = '0030' AND subreason IS NOT NULL;
SELECT * FROM reason_param WHERE mainreasoncode = 'SP1';--primarycause
--
getendresultapprove
---------------------------------------------------------------------------------------------------------------
create or replace function getMainReason(pSerialno in VARCHAR2)
--获得拒绝原因
return VARCHAR2
IS sSerialno VARCHAR2(50);
   sPhaseno  VARCHAR2(50);
	 sMainReasonCode  VARCHAR2(50);
	 MainReason  VARCHAR2(100);
BEGIN
	SELECT MAX(serialno) INTO sSerialno FROM flow_task WHERE objecttype = 'CreditApply' AND objectno = pSerialno;
	SELECT ft.phaseno INTO sPhaseno FROM flow_task ft WHERE ft.objecttype = 'CreditApply' AND ft.serialno = sSerialno;
  IF sPhaseno IN ('2040','3020','3021','3091','3092','3090') THEN
		 SELECT ba.APPROVEREFUSEREASON INTO MainReason FROM business_apply ba WHERE ba.serialno = pSerialno;
	elsif sPhaseno = '3093' THEN
		 SELECT DISTINCT primarycause INTO sMainReasonCode FROM STRATEGYRESULT WHERE objecttype = 'CreditApply' AND objectno = pSerialno AND  strategyresult = '3';
	   SELECT mainreason INTO MainReason FROM reason_param WHERE mainreasoncode = sMainReasonCode AND phaseno = '0030' AND subreason IS NOT NULL;
	ELSE
			SELECT '' INTO MainReason FROM dual;
	END IF;
	return MainReason;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getMainReason;


----------------------------------------------------------
SELECT BA.SERIALNO AS BASERIALNO,
       BA.CONTRACTSERIALNO,
       BA.LOANSERIALNO,
       BA.CUSTOMERID,
       BA.CUSTOMERNAME,
       BA.INPUTORGID,
       II.MANAGEORGID,
       GETORGFENBU(II.MANAGEORGID) AS SUBDEPTID,
       GETORGAREA(II.MANAGEORGID) AS AREAID,
       BA.POLICYNO,
       FT.ENDTIME,
       II.CERTID,
       BA.BUSINESSSUM,
       DECODE(FT.PHASEACTION, '初审未通过', 'r', 'p') AS AUDITSTATUS,
       GETENDRESULTAPPROVE(BA.SERIALNO) AS PHASEACTION,
       BA.BUSINESSTYPE,
       FT.USERID AS TRIALUSERID,
       (SELECT USERID
          FROM FLOW_TASK
         WHERE SERIALNO = (SELECT MAX(SERIALNO)
                             FROM FLOW_TASK
                            WHERE OBJECTNO = BA.SERIALNO
                              AND PHASENAME LIKE '%终审%'
                              AND PHASENAME <> ('组长回退终审'))) AS USERID,
       '' AS GROUPLEADERMAN,
       'OPS' AS QUALITYMAN,
       FT.PHASENO
  FROM BUSINESS_APPLY BA, IND_INFO II, FLOW_TASK FT, FLOW_OBJECT FO
 WHERE BA.CUSTOMERID = II.CUSTOMERID
   AND BA.SERIALNO = FO.OBJECTNO
   AND FO.OBJECTNO = FT.OBJECTNO
   AND FT.FLOWNO = FO.FLOWNO
   AND FT.PHASEACTION <> '初审通过强制上签'
   AND FT.PHASEACTION <> '初审未通过强制上签'
   AND FT.ENDTIME IS NOT NULL
   AND FO.FLOWNO = 'CreditFlow'
   AND NVL(BA.ISINQCTASKPOOL, 'N') = 'N'
   AND FT.SERIALNO IN (SELECT MAX(SERIALNO)
                         FROM FLOW_TASK
                        WHERE PHASENO IN ('0030', '0035')
                          AND OBJECTNO = BA.SERIALNO
                          AND FLOWNO = 'CreditFlow')
   AND FT.PHASENO IN ('0030', '0035')
   AND EXISTS (SELECT OBJECTNO
          FROM FLOW_TASK
         WHERE PHASENO IN ('2040', '0050', '3020', '3021')
           AND FLOWNO = 'CreditFlow'
           AND OBJECTNO = BA.SERIALNO)
   AND SUBSTR(FT.ENDTIME, 0, 10) >= '"+lastDate+"'

SELECT * FROM Approval_Code WHERE tp1= '3@599';

SELECT * FROM role_info
SELECT * FROM user_role WHERE roleid = '229';
--QualityTran","InsertQualityTran
WorkFlowEngine","InitializePutOut
WorkFlowEngine InitializePutOut
SELECT * FROM class_method WHERE classname = 'PublicMethod' AND methodname = 'InsertQualityPool' FOR UPDATE ;
SELECT * FROM class_method WHERE classname = 'PublicMethod' AND methodname = 'DeleteQualityPool';
--delete from quality_apply where QualityMan ='OPS' And nvl(STATUS,'0') = '0'
--PublicMethod","DeleteQualityPool
SELECT * FROM quality_opionon
select t.itemno, t.itemname from code_library t where codeno = 'QualityRole'
01	初审
02	终审
03	组长
select * from code_library WHERE codeno = 'QualityResults' and ISINUSE='1'
--PublicMethod","InsertQualityPool

--
SELECT DISTINCT SubReasonCode,SubReason FROM reason_param WHERE isinuse = '1';
SELECT * FROM business_apply;
SELECT * FROM quality_apply;
SELECT * FROM flow_opinion;
SELECT * FROM Approval_Code WHERE baserialno = '2017081400000033';
SELECT * FROM Flow_Opinion WHERE objectno = '';
select * from code_library WHERE codeno = 'QualityResults' and ISINUSE='1' FOR UPDATE
SELECT QA.caseendstatus,QA.* FROM  Quality_APPLY QA WHERE baserialno = '2015082700000046';
SELECT QA.caseendstatus,case QA.caseendstatus when '10' then '正常' when '20'
then '一般差错' when '30' then '重大差错' when '40' then '其他' END FROM Quality_APPLY QA
	WHERE baserialno = '2015082700000046';

	SELECT * FROM repayment_list

	SELECT COUNT(1) FROM Quality_APPLY --441

	SELECT * FROM flow_task WHERE objectno = '2017081500000002'  FOR UPDATE ;--2017/08/15 17:33:08  0035
		SELECT * FROM flow_task WHERE objectno = '2017081400000033'  FOR UPDATE ;
	SELECT ba.IsMentionedFraud,ba.issuspended,ba.* FROM business_apply ba
	WHERE serialno = '2017081500000002' FOR UPDATE ;--QZSQ

	--
	SELECT fo.PREMIUM,fo.* FROM Flow_Opinion fo WHERE objectno = '2017072600000118' FOR UPDATE ;
	SELECT * FROM reason_param WHERE reasontype = '20' AND isinuse = '1';
	SELECT * FROM code_library WHERE codeno = 'ReasonType';
10
20
30
拒绝原因
退回原因
取消原因
/

