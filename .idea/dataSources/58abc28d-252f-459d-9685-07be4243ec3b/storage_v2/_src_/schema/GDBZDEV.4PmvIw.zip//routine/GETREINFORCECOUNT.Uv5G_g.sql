create FUNCTION getReinforceCount
(
   pManageOrgID varchar2,pReinforceFlag varchar2
)
RETURN INTEGER
IS
v_Result INTEGER;
BEGIN
select
count(SerialNo) into v_Result
FROM BUSINESS_CONTRACT
WHERE ManageOrgID = pManageOrgID
AND ReinforceFlag = pReinforceFlag
;
return v_Result;
END;

/

