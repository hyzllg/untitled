create function getPremiumSum(args in varchar2)

return varchar2
is
   preSum varchar2(40);
begin
   select premium*signsum*0.01 into preSum from business_apply where serialno = args;
return preSum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getPremiumSum;
/

