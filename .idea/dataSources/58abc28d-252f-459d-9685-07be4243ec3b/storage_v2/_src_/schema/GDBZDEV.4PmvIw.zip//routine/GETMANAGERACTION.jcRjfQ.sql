create function GetManagerAction(pSerialno varchar)
return varchar
is
pUserid  varchar2(20);
pCount  varchar2(20);
begin
   select count(1) into pCount from Business_Apply ba where ba.Serialno=pSerialno and ba.Channelcode='ZYApp' and ba.Channel='CH2016032400000002';
  if (pCount>0) then
  select distinct ui.userid into pUserid
     from user_info ui, user_role ur
    where ur.userid = ui.userid
      and ur.roleid = '401'
      and ui.status = '1'
      and ur.status = '1'
      and ui.belongorg in
          (select inputorgid from business_apply where serialno = pSerialno);
   elsif (pCount<1) then 
     select distinct ui.userid  into pUserid from user_info ui,user_role ur where ur.userid = ui.userid and ur.roleid ='401' and ui.status='1' and ur.status='1' and ui.belongorg in (select ft1.orgid from flow_task ft1 where ft1.serialno in (select max(ft2.serialno) from flow_task ft2,flow_catalog fc where fc.flowno=ft2.flowno and fc.flowno='creditflow' and fc.initphase=ft2.phaseno and ft2.objectno=pserialno));
end if;
return pUserid;
end;

/

