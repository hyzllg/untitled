create function         approvelongtime(serialnoArg in varchar2)
--审批总时效
 return varchar2

 is
  longtimes varchar2(30);
  sApprovalTime varchar2(30);
  sApprovendtime varchar2(30);
begin
  select nvl(ba.approvebegintime,''),nvl(ba.approveendtime,'') into sApprovalTime,sApprovendtime from business_apply ba where ba.serialno=serialnoArg;
  SELECT

   EXTRACT(DAY FROM (decode(sApprovendtime,'',sysdate,to_date(sApprovendtime,'YYYY/MM/DD HH24:MI:ss'))-to_date(sApprovalTime,'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'天'
   || EXTRACT(HOUR FROM (decode(sApprovendtime,'',sysdate,to_date(sApprovendtime,'YYYY/MM/DD HH24:MI:ss'))-to_date(sApprovalTime,'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'时'
   || EXTRACT(MINUTE FROM (decode(sApprovendtime,'',sysdate,to_date(sApprovendtime,'YYYY/MM/DD HH24:MI:ss'))-to_date(sApprovalTime,'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'分' into longtimes
FROM DUAL;
  return(longtimes);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end approvelongtime;

/

