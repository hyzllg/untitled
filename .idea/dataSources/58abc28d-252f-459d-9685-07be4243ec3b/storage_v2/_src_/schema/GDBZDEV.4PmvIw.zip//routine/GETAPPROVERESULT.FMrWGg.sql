create FUNCTION getApproveResult(objectnoArg varchar2)
return varchar2
is
Results varchar2(100);
BEGIN
  SELECT phaseaction into Results FROM flow_task WHERE serialno IN (
  SELECT MAX(serialno) FROM flow_task WHERE objectno=objectnoArg AND flowno='CreditFlow'
  AND phaseno IN ('0030','0035','0040') AND endtime IS NOT NULL AND phaseaction IS NOT NULL);
  return(Results);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getApproveResult;
/

