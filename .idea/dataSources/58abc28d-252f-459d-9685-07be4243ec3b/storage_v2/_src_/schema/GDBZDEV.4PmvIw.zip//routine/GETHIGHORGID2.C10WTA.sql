create FUNCTION gethighorgid2(pOrgid varchar)
return varchar2
is pBelongorgid varchar(10);
begin
select belongorgid into pBelongorgid from org_info where orgid=(select belongorgid from org_info where orgid=pOrgid);
return pBelongorgid;
end;
/

