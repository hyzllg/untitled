create function GetFinalEndTime(serialnoArg in varchar2)
--获取终审审批结束时间
return varchar2
is FinalBeginTime  varchar2(200) ;
begin
   select endtime into FinalBeginTime
     from flow_task
    where flowno='CreditFlow'
      and serialno =(select serialno from 
          (select serialno
             from flow_task where phaseno in( '0040','0045') and objectno = serialnoArg and flowno='CreditFlow'order by begintime desc)where rownum=1);
  return FinalBeginTime;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFinalEndTime;

/

