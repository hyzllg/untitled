create FUNCTION getLastPhaseOpinion(pObjectType varchar,pObjectNo VARCHAR,pFlowNo VARCHAR)
return varchar
is pPhaseOpinion1  varchar(80);
BEGIN
  SELECT PhaseOpinion1 INTO pPhaseOpinion1 FROM FLOW_TASK WHERE serialno =(
	SELECT nvl(relativeserialno,serialno)
  FROM FLOW_TASK
 WHERE SERIALNO = (select serialno from (SELECT SERIALNO
                     FROM FLOW_TASK
                    WHERE OBJECTTYPE = pObjectType
                      AND OBJECTNO = pObjectNo
                      AND FLOWNO = pFlowNo order by begintime desc)where rownum=1));
	return pPhaseOpinion1;
end;

/

