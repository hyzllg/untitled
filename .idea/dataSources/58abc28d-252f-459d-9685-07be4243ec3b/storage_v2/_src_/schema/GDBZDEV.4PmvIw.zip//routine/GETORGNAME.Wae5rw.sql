create FUNCTION getorgname(pOrgID varchar)
return varchar
is pOrgName varchar(80);
begin
select OrgName into pOrgName
from Org_info
 where Orgid = pOrgID;
 return pOrgName;
end;
/

