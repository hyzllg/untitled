create function getFistOverDue(pSerialno in varchar2)
--获得首逾
return varchar2
is
  FistOverDue varchar2(10);
begin
     select 'Y' into FistOverDue from acct_payment_schedule ap
     where ap.seqid = 1 and nvl(ap.finishdate,to_char(SYSDATE,'yyyy/MM/dd')) > ap.paydate
     AND SUBSTR(AP.PAYDATE, 1, 7) = TO_CHAR(SYSDATE-1, 'yyyy/mm')
     and ap.objectno= pSerialno ;
     return  FistOverDue;
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getFistOverDue;
/

