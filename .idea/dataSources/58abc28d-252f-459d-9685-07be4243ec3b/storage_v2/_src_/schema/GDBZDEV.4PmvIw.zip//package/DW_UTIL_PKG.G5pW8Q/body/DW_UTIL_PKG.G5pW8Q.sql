create PACKAGE BODY dw_util_pkg IS

  c_enable_parallel CONSTANT BOOLEAN := TRUE;
  --c_package_name    CONSTANT VARCHAR2(300) := 'dw_util_pkg';
  PROCEDURE log_into_table(p_message_type         VARCHAR2,
                           p_message              VARCHAR2,
                           p_plan_node_control_id NUMBER,
                           p_procedure_name       VARCHAR2) IS
    PRAGMA AUTONOMOUS_TRANSACTION;
  BEGIN
    INSERT INTO dw_etl_logs
      (log_id, log_type, log_message, log_date, plan_node_control_id, procedure_name)
    VALUES
      (dw_etl_logs_s.nextval,
       p_message_type,
       p_message,
       SYSDATE,
       p_plan_node_control_id,
       p_procedure_name);
    COMMIT;
  END log_into_table;

  PROCEDURE log(p_message_type         VARCHAR2,
                p_message              VARCHAR2,
                p_plan_node_control_id NUMBER DEFAULT -1,
                p_procedure_name       VARCHAR2 DEFAULT '') AS
  BEGIN
    log_into_table(p_message_type, p_message, p_plan_node_control_id, p_procedure_name);

  END log;

  PROCEDURE log_infor(p_message              VARCHAR2,
                      p_plan_node_control_id NUMBER DEFAULT -1,
                      p_procedure_name       VARCHAR2 DEFAULT '') AS
  BEGIN
    log(c_log_infor, p_message, p_plan_node_control_id, p_procedure_name);

  END log_infor;

  PROCEDURE log_warning(p_message              VARCHAR2,
                        p_plan_node_control_id NUMBER DEFAULT -1,
                        p_procedure_name       VARCHAR2 DEFAULT '') AS
  BEGIN
    log(c_log_warning, p_message, p_plan_node_control_id, p_procedure_name);

  END log_warning;

  PROCEDURE log_error(p_message              VARCHAR2,
                      p_plan_node_control_id NUMBER DEFAULT -1,
                      p_procedure_name       VARCHAR2 DEFAULT '') AS
  BEGIN
    log(c_log_error, p_message, p_plan_node_control_id, p_procedure_name);

  END log_error;

  FUNCTION executing_time(p_execute_begining_date DATE) RETURN NUMBER IS
  BEGIN
    RETURN round((SYSDATE - p_execute_begining_date) * 24 * 60, 1);
  END executing_time;

  PROCEDURE enable_session_parallel(p_level NUMBER DEFAULT 64) IS
    l_level VARCHAR(30) := CASE
                             WHEN p_level = 0 THEN
                              ''
                             ELSE
                              ' ' || p_level
                           END;
  BEGIN
    IF c_enable_parallel THEN
      EXECUTE IMMEDIATE 'ALTER SESSION FORCE PARALLEL QUERY PARALLEL' || l_level;
      EXECUTE IMMEDIATE 'ALTER SESSION FORCE PARALLEL DML PARALLEL' || l_level;
      EXECUTE IMMEDIATE 'ALTER SESSION FORCE PARALLEL DDL PARALLEL' || l_level;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END enable_session_parallel;

  PROCEDURE disable_session_parallel IS
  BEGIN
    EXECUTE IMMEDIATE 'ALTER SESSION DISABLE PARALLEL QUERY';
    EXECUTE IMMEDIATE 'ALTER SESSION DISABLE PARALLEL DML';
    EXECUTE IMMEDIATE 'ALTER SESSION DISABLE PARALLEL DDL';
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END disable_session_parallel;

  PROCEDURE gather_stats(p_owner     VARCHAR2,
                         p_table     VARCHAR2 DEFAULT NULL,
                         p_partition VARCHAR2 DEFAULT NULL) IS
    l_execute_begining_date DATE;
    l_message_type          VARCHAR2(300) := 'Gather Table Stat';
    l_granularity           VARCHAR2(300);
  BEGIN
    l_execute_begining_date := SYSDATE;
    IF p_table IS NOT NULL THEN
      BEGIN
        dbms_stats.unlock_table_stats(p_owner, p_table);
      EXCEPTION
        WHEN OTHERS THEN
          NULL;
      END;

      BEGIN
        SELECT decode(t.partitioned, 'YES', 'PARTITION', 'AUTO')
          INTO l_granularity
          FROM all_tables t
         WHERE t.owner = p_owner
           AND t.table_name = p_table;
      EXCEPTION
        WHEN OTHERS THEN
          l_granularity := 'AUTO';
      END;

      IF p_partition IS NULL THEN
        log(l_message_type, '开始统计收集表状态: ' || p_owner || '.' || p_table);
        dbms_stats.gather_table_stats(p_owner, p_table, granularity => l_granularity,cascade => true,degree => 64);
      ELSE
        log(l_message_type,
            '开始统计收集表分区状态: ' || p_owner || '.' || p_table || '.' || p_partition);
        dbms_stats.gather_table_stats(p_owner,
                                      p_table,
                                      '"' || p_partition || '"',
                                      granularity => l_granularity,cascade => true,degree => 64);
      END IF;
    ELSE
      log(l_message_type, '开始统计收集用户状态: ' || p_owner);
      dbms_stats.gather_schema_stats(p_owner);
    END IF;
    log(l_message_type,
        '统计收集完成！共执行时间（分钟）：' || executing_time(l_execute_begining_date));
  END gather_stats;

  FUNCTION exists_partition(p_owner VARCHAR2, p_table VARCHAR2, p_partition_name VARCHAR2)
    RETURN VARCHAR2 IS
    l_exists_flag VARCHAR2(1) := 'N';
  BEGIN
    SELECT 'Y'
      INTO l_exists_flag
      FROM all_tab_partitions p
     WHERE p.table_owner = p_owner
       AND p.table_name = p_table
       AND p.partition_name = p_partition_name;
    RETURN l_exists_flag;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_exists_flag;
  END exists_partition;

  FUNCTION exists_subpartition(p_owner             VARCHAR2,
                               p_table             VARCHAR2,
                               p_partition_name    VARCHAR2,
                               p_subpartition_name VARCHAR2) RETURN VARCHAR2 IS
    l_exists_flag VARCHAR2(1) := 'N';
  BEGIN
    SELECT 'Y'
      INTO l_exists_flag
      FROM all_tab_subpartitions p
     WHERE p.table_owner = p_owner
       AND p.table_name = p_table
       AND p.partition_name = p_partition_name
       AND p.subpartition_name = p_subpartition_name;
    RETURN l_exists_flag;
  EXCEPTION
    WHEN OTHERS THEN
      RETURN l_exists_flag;
  END exists_subpartition;

  PROCEDURE add_partition(p_owner                 VARCHAR2,
                          p_table                 VARCHAR2,
                          p_partition_name        VARCHAR2,
                          p_partition_value       VARCHAR2,
                          p_subpartition_name     VARCHAR2 DEFAULT NULL,
                          p_subpartition_value    VARCHAR2 DEFAULT NULL,
                          p_gen_subpartition_name BOOLEAN DEFAULT TRUE) IS
    l_add_partition_sql      VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ ADD PARTITION "$partition_name$" VALUES(''$partition_value$'')';
    l_add_subpartition_sql   VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ ADD PARTITION "$partition_name$" VALUES(''$partition_value$'')
    (SUBPARTITION "$subpartition_name$" VALUES(''$subpartition_value$''))';
    l_apend_subpartition_sql VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ MODIFY PARTITION "$partition_name$"
    ADD SUBPARTITION "$subpartition_name$" VALUES(''$subpartition_value$'')';
    l_sql                    VARCHAR2(4000);
    l_subpartition_name      VARCHAR2(4000);
  BEGIN
    IF p_subpartition_name IS NULL THEN
      IF exists_partition(p_owner, p_table, p_partition_name) = 'Y' THEN
        RETURN;
      ELSE
        l_sql := REPLACE(REPLACE(REPLACE(REPLACE(l_add_partition_sql, '$owner$', p_owner),
                                         '$table_name$',
                                         p_table),
                                 '$partition_name$',
                                 p_partition_name),
                         '$partition_value$',
                         p_partition_value);
        EXECUTE IMMEDIATE l_sql;
      END IF;
    ELSE
      IF p_gen_subpartition_name THEN
        l_subpartition_name := p_partition_name || p_subpartition_name;
      ELSE
        l_subpartition_name := p_subpartition_name;
      END IF;
      IF exists_subpartition(p_owner, p_table, p_partition_name, l_subpartition_name) = 'Y' THEN
        RETURN;
      ELSE
        IF exists_partition(p_owner, p_table, p_partition_name) = 'Y' THEN
          l_sql := REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(l_apend_subpartition_sql,
                                                           '$owner$',
                                                           p_owner),
                                                   '$table_name$',
                                                   p_table),
                                           '$partition_name$',
                                           p_partition_name),
                                   '$subpartition_name$',
                                   l_subpartition_name),
                           '$subpartition_value$',
                           p_subpartition_value);
          EXECUTE IMMEDIATE l_sql;
        ELSE
          l_sql := REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(l_add_subpartition_sql,
                                                                   '$owner$',
                                                                   p_owner),
                                                           '$table_name$',
                                                           p_table),
                                                   '$partition_name$',
                                                   p_partition_name),
                                           '$partition_value$',
                                           p_partition_value),
                                   '$subpartition_name$',
                                   l_subpartition_name),
                           '$subpartition_value$',
                           p_subpartition_value);

          EXECUTE IMMEDIATE l_sql;
        END IF;
      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END add_partition;

  PROCEDURE drop_partition(p_owner             VARCHAR2,
                           p_table             VARCHAR2,
                           p_partition_name    VARCHAR2,
                           p_subpartition_name VARCHAR2 DEFAULT NULL) IS
    l_drop_partition_sql    VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ DROP PARTITION "$partition_name$"';
    l_drop_subpartition_sql VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ DROP SUBPARTITION "$subpartition_name$"';
    l_sql                   VARCHAR2(4000);
  BEGIN
    IF p_subpartition_name IS NOT NULL THEN
      FOR r_subpartition IN (SELECT *
                               FROM all_tab_subpartitions t
                              WHERE t.table_owner = upper(p_owner)
                                AND t.table_name = upper(p_table)
                                AND t.partition_name LIKE p_partition_name
                                AND t.partition_name NOT LIKE 'INIT%'
                                AND t.subpartition_name LIKE p_subpartition_name
                                AND t.subpartition_name NOT LIKE 'INIT%') LOOP
        l_sql := REPLACE(REPLACE(REPLACE(l_drop_subpartition_sql,
                                         '$owner$',
                                         r_subpartition.table_owner),
                                 '$table_name$',
                                 r_subpartition.table_name),
                         '$subpartition_name$',
                         r_subpartition.subpartition_name);
        EXECUTE IMMEDIATE l_sql;
      END LOOP;

    ELSE
      FOR r_partition IN (SELECT *
                            FROM all_tab_partitions t
                           WHERE t.table_owner = upper(p_owner)
                             AND t.table_name = upper(p_table)
                             AND t.partition_name LIKE p_partition_name
                             AND t.partition_name NOT LIKE 'INIT%') LOOP
        l_sql := REPLACE(REPLACE(REPLACE(l_drop_partition_sql, '$owner$', r_partition.table_owner),
                                 '$table_name$',
                                 r_partition.table_name),
                         '$partition_name$',
                         r_partition.partition_name);
        EXECUTE IMMEDIATE l_sql;
      END LOOP;

    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END drop_partition;

  PROCEDURE exchange_partition(p_owner           VARCHAR2,
                               p_table           VARCHAR2,
                               p_partition_name  VARCHAR2,
                               p_partition_value VARCHAR2,
                               p_target_owner    VARCHAR2,
                               p_target_table    VARCHAR2) IS
    l_exchange_partition_sql VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ EXCHANGE PARTITION "$partition_name$" WITH TABLE $target_owner$.$target_table_name$ WITHOUT VALIDATION';
    l_sql                    VARCHAR2(4000);
  BEGIN
    -- drop partition
    drop_partition(p_owner, p_table, p_partition_name);

    -- add subpartition to table if target table is partitioned table
    FOR r_partition IN (SELECT *
                          FROM all_tab_partitions t
                         WHERE t.table_owner = p_target_owner
                           AND t.table_name = p_target_table
                           AND t.partition_name LIKE 'INIT%') LOOP
      add_partition(p_owner,
                    p_table,
                    p_partition_name,
                    p_partition_value,
                    p_partition_name || 'INIT',
                    '0',
                    FALSE);
    END LOOP;
    FOR r_partition IN (SELECT *
                          FROM all_tab_partitions t
                         WHERE t.table_owner = p_target_owner
                           AND t.table_name = p_target_table
                           AND t.partition_name NOT LIKE 'INIT%') LOOP
      add_partition(p_owner,
                    p_table,
                    p_partition_name,
                    p_partition_value,
                    r_partition.partition_name,
                    REPLACE(r_partition.high_value, '''', ''),
                    FALSE);
    END LOOP;

    -- exchage partition
    l_sql := REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(l_exchange_partition_sql, '$owner$', p_owner),
                                             '$table_name$',
                                             p_table),
                                     '$partition_name$',
                                     p_partition_name),
                             '$target_owner$',
                             p_target_owner),
                     '$target_table_name$',
                     p_target_table);
    EXECUTE IMMEDIATE l_sql;

  END exchange_partition;

  PROCEDURE truncate_table(p_owner             VARCHAR2,
                           p_table             VARCHAR2,
                           p_partition_name    VARCHAR2 DEFAULT NULL,
                           p_subpartition_name VARCHAR2 DEFAULT NULL) IS
    l_truncate_table        VARCHAR2(4000) := 'TRUNCATE TABLE $owner$.$table_name$';
    l_truncate_partition    VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ TRUNCATE PARTITION "$partition_name$"';
    l_truncate_subpartition VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ TRUNCATE SUBPARTITION "$subpartition_name$"';
    l_sql                   VARCHAR2(4000);
    l_subpartition_name     VARCHAR2(4000);
  BEGIN
    IF p_partition_name IS NULL THEN
      l_sql := REPLACE(REPLACE(l_truncate_table, '$owner$', upper(p_owner)),
                       '$table_name$',
                       upper(p_table));

      EXECUTE IMMEDIATE l_sql;

    ELSE
      IF p_subpartition_name IS NULL THEN
        l_sql := REPLACE(REPLACE(REPLACE(l_truncate_partition, '$owner$', upper(p_owner)),
                                 '$table_name$',
                                 upper(p_table)),
                         '$partition_name$',
                         p_partition_name);

        EXECUTE IMMEDIATE l_sql;

      ELSE
        l_subpartition_name := p_partition_name || p_subpartition_name;
        l_sql               := REPLACE(REPLACE(REPLACE(l_truncate_subpartition,
                                                       '$owner$',
                                                       upper(p_owner)),
                                               '$table_name$',
                                               upper(p_table)),
                                       '$subpartition_name$',
                                       l_subpartition_name);

        EXECUTE IMMEDIATE l_sql;

      END IF;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END truncate_table;

  PROCEDURE disable_index(p_owner VARCHAR2, p_table VARCHAR2, p_partition VARCHAR2 DEFAULT NULL) IS
    l_disable_index           VARCHAR2(4000) := 'ALTER INDEX $owner$.$index_name$ UNUSABLE';
    l_disable_index_partition VARCHAR2(4000) := 'ALTER INDEX $owner$.$index_name$ MODIFY PARTITION "$partition_name$" UNUSABLE';
    l_sql                     VARCHAR2(4000);
  BEGIN
    FOR r_index IN (SELECT *
                      FROM all_indexes i
                     WHERE i.table_owner = p_owner
                       AND i.table_name = p_table) LOOP
      IF r_index.partitioned = 'YES' THEN

        FOR r_ind_partition IN (SELECT *
                                  FROM all_ind_partitions ip
                                 WHERE ip.index_owner = r_index.owner
                                   AND ip.index_name = r_index.index_name
                                   AND ip.partition_name = nvl(p_partition, ip.partition_name)) LOOP
          l_sql := REPLACE(REPLACE(REPLACE(l_disable_index_partition,
                                           '$owner$',
                                           r_ind_partition.index_owner),
                                   '$index_name$',
                                   r_ind_partition.index_name),
                           '$partition_name$',
                           r_ind_partition.partition_name);
          EXECUTE IMMEDIATE l_sql;
        END LOOP;

      ELSE
        l_sql := REPLACE(REPLACE(l_disable_index, '$owner$', r_index.owner),
                         '$index_name$',
                         r_index.index_name);
        EXECUTE IMMEDIATE l_sql;

      END IF;
    END LOOP;
  END disable_index;

  PROCEDURE rebuild_unusable_index(p_owner VARCHAR2, p_table VARCHAR2, p_partition VARCHAR2) IS
    l_message_type               VARCHAR2(300) := 'Rebuild Unusable Local Index';
    l_execute_begining_date      DATE := SYSDATE;
    l_rebuild_index              VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ MODIFY PARTITION "$partition_name$" REBUILD UNUSABLE LOCAL INDEXES';
    l_rebuild_index_subpartition VARCHAR2(4000) := 'ALTER TABLE $owner$.$table_name$ MODIFY SUBPARTITION "$subpartition_name$" REBUILD UNUSABLE LOCAL INDEXES';
    l_rebuild_flag               VARCHAR2(1) := 'N';
    l_sql                        VARCHAR2(4000);
  BEGIN
    -- 开启并发
    enable_session_parallel;

    log(l_message_type || ' - ' || p_owner || '.' || p_table || ' - ' || p_partition,
        '开始重建索引...');

    FOR r_index IN (SELECT *
                      FROM all_indexes i
                     WHERE i.table_owner = p_owner
                       AND i.table_name = p_table) LOOP
      l_rebuild_flag := 'N';

      FOR r_subpartition IN (SELECT *
                               FROM all_ind_subpartitions p
                              WHERE p.index_owner = r_index.owner
                                AND p.index_name = r_index.index_name
                                AND p.partition_name = nvl(p_partition, p.partition_name)) LOOP
        l_sql := REPLACE(REPLACE(REPLACE(l_rebuild_index_subpartition, '$owner$', r_index.owner),
                                 '$table_name$',
                                 p_table),
                         '$subpartition_name$',
                         r_subpartition.subpartition_name);

        EXECUTE IMMEDIATE l_sql;

        l_rebuild_flag := 'Y';
      END LOOP;

      IF l_rebuild_flag = 'N' THEN
        FOR r_partition IN (SELECT *
                              FROM all_ind_partitions p
                             WHERE p.index_owner = r_index.owner
                               AND p.index_name = r_index.index_name
                               AND p.partition_name = nvl(p_partition, p.partition_name)) LOOP
          l_sql := REPLACE(REPLACE(REPLACE(l_rebuild_index, '$owner$', r_index.owner),
                                   '$table_name$',
                                   p_table),
                           '$partition_name$',
                           r_partition.partition_name);

          EXECUTE IMMEDIATE l_sql;

          l_rebuild_flag := 'Y';
        END LOOP;
      END IF;
    END LOOP;

    log(l_message_type || ' - ' || p_owner || '.' || p_table || ' - ' || p_partition,
        '重建索引完成！共执行时间（分钟）：' || dw_util_pkg.executing_time(l_execute_begining_date));

    -- 关闭并发
    disable_session_parallel;
  EXCEPTION
    WHEN OTHERS THEN
      dbms_output.put_line(l_sql);
  END rebuild_unusable_index;

  PROCEDURE rebuild_index(p_owner VARCHAR2, p_table VARCHAR2, p_partition VARCHAR2 DEFAULT NULL) IS
    l_message_type               VARCHAR2(300) := 'Rebuild Index';
    l_execute_begining_date      DATE := SYSDATE;
    l_rebuild_index_table        VARCHAR2(4000) := 'ALTER INDEX $owner$.$index_name$ REBUILD';
    l_rebuild_index_partition    VARCHAR2(4000) := 'ALTER INDEX $owner$.$index_name$ REBUILD PARTITION "$partition_name$"';
    l_rebuild_flag               VARCHAR2(1) := 'N';
    l_rebuild_index_subpartition VARCHAR2(4000) := 'ALTER INDEX $owner$.$index_name$ REBUILD SUBPARTITION "$subpartition_name$"';
    l_sql                        VARCHAR2(4000);
  BEGIN
    -- 开启并发
    enable_session_parallel;

    log(l_message_type || ' - ' || p_owner || '.' || p_table || ' - ' || p_partition,
        '开始重建索引...');
    FOR r_index IN (SELECT *
                      FROM all_indexes i
                     WHERE i.table_owner = p_owner
                       AND i.table_name = p_table) LOOP
      l_rebuild_flag := 'N';

      FOR r_subpartition IN (SELECT *
                               FROM all_ind_subpartitions p
                              WHERE p.index_owner = r_index.owner
                                AND p.index_name = r_index.index_name
                                AND p.partition_name = nvl(p_partition, p.partition_name)) LOOP
        l_sql := REPLACE(REPLACE(REPLACE(l_rebuild_index_subpartition, '$owner$', r_index.owner),
                                 '$index_name$',
                                 r_index.index_name),
                         '$subpartition_name$',
                         r_subpartition.subpartition_name);

        EXECUTE IMMEDIATE l_sql;

        l_rebuild_flag := 'Y';
      END LOOP;

      IF l_rebuild_flag = 'N' THEN
        FOR r_partition IN (SELECT *
                              FROM all_ind_partitions p
                             WHERE p.index_owner = r_index.owner
                               AND p.index_name = r_index.index_name
                               AND p.partition_name = nvl(p_partition, p.partition_name)) LOOP
          l_sql := REPLACE(REPLACE(REPLACE(l_rebuild_index_partition, '$owner$', r_index.owner),
                                   '$index_name$',
                                   r_index.index_name),
                           '$partition_name$',
                           r_partition.partition_name);

          EXECUTE IMMEDIATE l_sql;

          l_rebuild_flag := 'Y';
        END LOOP;
      END IF;

      IF l_rebuild_flag = 'N' THEN
        l_sql := REPLACE(REPLACE(l_rebuild_index_table, '$owner$', r_index.owner),
                         '$index_name$',
                         r_index.index_name);

        EXECUTE IMMEDIATE l_sql;

      END IF;
    END LOOP;
    log(l_message_type || ' - ' || p_owner || '.' || p_table || ' - ' || p_partition,
        '重建索引完成！共执行时间（分钟）：' || dw_util_pkg.executing_time(l_execute_begining_date));

    -- 关闭并发
    disable_session_parallel;
  END rebuild_index;

  -- submit_job
  PROCEDURE submit_job(p_job_name VARCHAR2, p_statement VARCHAR2, p_date DATE DEFAULT SYSDATE) IS
  BEGIN
    BEGIN
      dbms_scheduler.stop_job(p_job_name);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    BEGIN
      dbms_scheduler.drop_job(p_job_name);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    dbms_scheduler.create_job(job_name   => p_job_name,
                              job_type   => 'PLSQL_BLOCK',
                              job_action => p_statement,
                              start_date => p_date,
                              enabled    => TRUE);
  END submit_job;

  PROCEDURE gen_parallel_chunks(p_task_name VARCHAR2, p_chunks_sql VARCHAR2) IS
    l_sql VARCHAR2(4000) := '
    insert into dw_etl_chunks(job_name,
                                   start_id,
                                   end_id,
                                   start_value,
                                   end_value,
                                   execute_date)
    SELECT ''' || p_task_name ||
                            ''', rownum start_id, rownum end_id, start_value, end_value ,SYSDATE FROM (' ||
                            p_chunks_sql || ')';
  BEGIN
    DELETE FROM dw_etl_chunks WHERE job_name = p_task_name;

    EXECUTE IMMEDIATE l_sql;
    COMMIT;

  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END gen_parallel_chunks;

  PROCEDURE get_parallel_chunks(p_task_name   VARCHAR2,
                                p_start_id    NUMBER,
                                p_end_id      NUMBER,
                                x_start_value OUT VARCHAR2,
                                x_end_value   OUT VARCHAR2) IS
  BEGIN
    SELECT start_value, end_value
      INTO x_start_value, x_end_value
      FROM dw_etl_chunks
     WHERE job_name = p_task_name
       AND start_id = p_start_id
       AND end_id = p_end_id;
  EXCEPTION
    WHEN OTHERS THEN
      NULL;
  END get_parallel_chunks;

  -- parallel_execute
  PROCEDURE parallel_execute(p_task_name      VARCHAR2,
                             p_chunks_sql     VARCHAR2,
                             p_execute_sql    VARCHAR2,
                             p_parallel_level NUMBER DEFAULT 32) IS
    l_real_chunks_sql  VARCHAR2(32767);
    l_real_execute_sql VARCHAR2(32767);
  BEGIN
    BEGIN
      dbms_parallel_execute.stop_task(p_task_name);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;
    BEGIN
      dbms_parallel_execute.drop_task(p_task_name);
    EXCEPTION
      WHEN OTHERS THEN
        NULL;
    END;

    gen_parallel_chunks(p_task_name, p_chunks_sql);

    dbms_parallel_execute.create_task(task_name => p_task_name);

    l_real_chunks_sql := 'select start_id, end_id from dw_etl_chunks where job_name = ''' ||
                         p_task_name || '''';
    dbms_parallel_execute.create_chunks_by_sql(task_name => p_task_name,
                                               sql_stmt  => l_real_chunks_sql,
                                               by_rowid  => FALSE);

    l_real_execute_sql := 'declare
    l_start_value dw_etl_chunks.start_value%type;
    l_end_value dw_etl_chunks.end_value%type;
    begin
    dw_util_pkg.get_parallel_chunks(''' || p_task_name || ''', :start_id, :end_id, l_start_value, l_end_value);
    ' || REPLACE(REPLACE(p_execute_sql, ':start_id', 'l_start_value'),
                                        ':end_id',
                                        'l_end_value') || '
    end;';
    dbms_parallel_execute.run_task(task_name      => p_task_name,
                                   sql_stmt       => l_real_execute_sql,
                                   language_flag  => dbms_sql.native,
                                   parallel_level => p_parallel_level);

    IF dbms_parallel_execute.task_status(task_name => p_task_name) <>
       dbms_parallel_execute.finished THEN
      RAISE dbms_parallel_execute.invalid_status;
    END IF;

  END parallel_execute;

  PROCEDURE load_table_cache(p_owner VARCHAR2, p_table_name VARCHAR2) IS
  BEGIN
    -- clear cache
    EXECUTE IMMEDIATE 'ALTER TABLE ' || p_owner || '.' || p_table_name || ' NOCACHE';

    -- load cache
    gather_stats(p_owner, p_table_name);
  END load_table_cache;

  PROCEDURE load_index_cache(p_table_owner VARCHAR2,
                             p_table_name  VARCHAR2,
                             p_index_owner VARCHAR2,
                             p_index_name  VARCHAR2) IS
  BEGIN
    -- clear cache
    EXECUTE IMMEDIATE 'ALTER INDEX ' || p_index_owner || '.' || p_index_name ||
                      ' STORAGE (BUFFER_POOL DEFAULT)';
    EXECUTE IMMEDIATE 'ALTER INDEX ' || p_index_owner || '.' || p_index_name ||
                      ' STORAGE (BUFFER_POOL KEEP)';
    -- load cache
    EXECUTE IMMEDIATE 'SELECT /*+INDEX(' || p_table_owner || '.' || p_table_name || ',' ||
                      p_index_owner || '.' || p_index_name || ')*/ COUNT(*) FROM ' || p_table_owner || '.' ||
                      p_table_name;
  END load_index_cache;

  PROCEDURE cache_tables(p_owner           VARCHAR2,
                         p_table_name      VARCHAR2,
                         p_enable          BOOLEAN DEFAULT TRUE,
                         p_include_indexes BOOLEAN DEFAULT TRUE) IS

  BEGIN
    FOR r_tab IN (SELECT *
                    FROM all_tables
                   WHERE owner = p_owner
                     AND table_name LIKE p_table_name) LOOP
      IF p_enable THEN
        -- set keep buffer pool
        EXECUTE IMMEDIATE 'ALTER TABLE ' || r_tab.owner || '.' || r_tab.table_name ||
                          ' STORAGE (BUFFER_POOL KEEP)';
        -- load cache
        load_table_cache(r_tab.owner, r_tab.table_name);

        -- enable index buffer
        IF p_include_indexes THEN
          FOR r_idx IN (SELECT *
                          FROM all_indexes t
                         WHERE t.table_owner = r_tab.owner
                           AND t.table_name = r_tab.table_name) LOOP
            -- set keep buffer pool
            EXECUTE IMMEDIATE 'ALTER INDEX ' || r_idx.owner || '.' || r_idx.index_name ||
                              ' STORAGE (BUFFER_POOL KEEP)';
            -- load cache
            load_index_cache(r_tab.owner, r_tab.table_name, r_idx.owner, r_idx.index_name);
          END LOOP;
        END IF;

      ELSE
        FOR r_idx IN (SELECT *
                        FROM all_indexes t
                       WHERE t.table_owner = r_tab.owner
                         AND t.table_name = r_tab.table_name
                         AND t.buffer_pool = 'KEEP') LOOP
          -- set default buffer pool
          EXECUTE IMMEDIATE 'ALTER INDEX ' || r_idx.owner || '.' || r_idx.index_name ||
                            ' STORAGE (BUFFER_POOL DEFAULT)';
        END LOOP;

        -- set default buffer pool
        EXECUTE IMMEDIATE 'ALTER TABLE ' || r_tab.owner || '.' || r_tab.table_name ||
                          ' STORAGE (BUFFER_POOL DEFAULT)';

      END IF;

    END LOOP;

  END cache_tables;

  PROCEDURE log_calc(p_log_message VARCHAR2,
                     p_index_id    NUMBER DEFAULT NULL,
                     p_line_number NUMBER DEFAULT NULL) IS
    l_message_type VARCHAR2(300) := 'Index Calculate';
  BEGIN
    IF p_index_id IS NOT NULL THEN
      log(l_message_type || ' - ' || p_index_id || ' - ' || p_line_number, p_log_message);
    ELSE
      log(l_message_type, p_log_message);
    END IF;
  END log_calc;

  --获取英文月份对应数字月份MM格式
  FUNCTION get_month_from_en(p_month_name_en IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN
    RETURN CASE WHEN p_month_name_en = 'Jan' OR p_month_name_en = 'January' THEN '01' WHEN p_month_name_en = 'Feb' OR p_month_name_en = 'February' THEN '02' WHEN p_month_name_en = 'Mar' OR p_month_name_en = 'March' THEN '03' WHEN p_month_name_en = 'Apr' OR p_month_name_en = 'April' THEN '04' WHEN p_month_name_en = 'May' OR p_month_name_en = 'May' THEN '05' WHEN p_month_name_en = 'Jun' OR p_month_name_en = 'June' THEN '06' WHEN p_month_name_en = 'Jul' OR p_month_name_en = 'July' THEN '07' WHEN p_month_name_en = 'Aug' OR p_month_name_en = 'August' THEN '08' WHEN p_month_name_en = 'Sep' OR p_month_name_en = 'September' THEN '09' WHEN p_month_name_en = 'Oct' OR p_month_name_en = 'October' THEN '10' WHEN p_month_name_en = 'Nov' OR p_month_name_en = 'November' THEN '11' WHEN p_month_name_en = 'Dec' OR p_month_name_en = 'December' THEN '12' ELSE 'err' END;
  END get_month_from_en;

END dw_util_pkg;
/

