create package p_view_param  is
   function set_param(paramVal VARCHAR2) return VARCHAR2;
   function get_param(paramVal VARCHAR2) return VARCHAR2;
end p_view_param;
/

