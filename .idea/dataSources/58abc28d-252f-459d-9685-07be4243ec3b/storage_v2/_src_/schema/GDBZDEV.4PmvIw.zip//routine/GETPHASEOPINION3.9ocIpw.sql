create function getPhaseOpinion3(objectnoArg in varchar2)
-- 统一电话预约/面谈面签备注信息取值
return varchar2
is remark varchar2(400);
begin
	 SELECT  phaseopinion3 INTO remark from(
  SELECT  fo.phaseopinion3
   FROM flow_opinion fo
   WHERE fo.phaseno in ('0012','0030','0035','0040','0045','0050','0047')
   AND fo.ApproveFlag ='1'
   and fo.objectno = objectnoArg
   ORDER BY updatetime DESC) where rownum=1;
  return remark;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getPhaseOpinion3;


/

