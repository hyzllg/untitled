create function GetOverdueMoney(ACTUALPAYDATEArg in varchar2)
--逾期金额
return  number
is
  overduemoney number(24,7);
begin
  select sum(nvl(al.overduebalance, 0) + nvl(al.interestbalance, 0) +
                   nvl(al.fineintebalance, 0) + nvl(al.compintebalance, 0)) into overduemoney
                   from acct_loan_back al where al.putoutdate=ACTUALPAYDATEArg and al.backinputdate=(to_char(trunc(sysdate-1),'yyyy/mm/dd'));
  return overduemoney;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetOverdueMoney;
/

