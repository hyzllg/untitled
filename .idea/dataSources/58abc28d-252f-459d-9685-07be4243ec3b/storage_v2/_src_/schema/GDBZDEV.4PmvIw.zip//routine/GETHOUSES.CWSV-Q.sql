create function getHouses(customeridArg in varchar2)
--获取一个或多个房产信息
return varchar2
is
 cursor c_cur
is
  select getitemname('AssHouseType',realtyattribute) as house from customer_realty where customerid=customeridArg;
  hjhj varchar2(400);
begin
  for r_cur in c_cur
     loop
  hjhj:=r_cur.house||';'||hjhj;
   end loop;
return hjhj;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getHouses;
/

