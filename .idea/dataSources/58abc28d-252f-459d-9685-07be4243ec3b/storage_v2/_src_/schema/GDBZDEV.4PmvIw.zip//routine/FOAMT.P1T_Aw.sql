create function FOAMT( pObjectno in varchar )
return
is
BEGIN
  OPEN p_emplist
    FOR
   select autocount ,COUNTBUSINESSSUM ,businesssum  from flow_opinion where serialno =
(select max(serialno) from flow_opinion where phaseno in('0040','0035','0030','0045','0047') and objectno = pObjectno);


end FOAMT;


/

