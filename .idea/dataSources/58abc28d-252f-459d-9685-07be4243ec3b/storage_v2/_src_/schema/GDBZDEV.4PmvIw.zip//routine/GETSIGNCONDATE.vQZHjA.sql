create function GETSIGNCONDATE(serialnoArg in varchar2)
--获取U签约时间
return varchar2
is ApproveDate varchar2(20);
begin
  select ft.EndTime into ApproveDate
    from (select nvl(substr(EndTime,1,10),'') EndTime from flow_task
      where objectno=serialnoArg
       and PhaseNo='0070' and phaseaction!='客户要求终止申请（网点）'
       order by EndTime desc) ft
       where rownum='1';
  return ApproveDate;
end GETSIGNCONDATE;

/

