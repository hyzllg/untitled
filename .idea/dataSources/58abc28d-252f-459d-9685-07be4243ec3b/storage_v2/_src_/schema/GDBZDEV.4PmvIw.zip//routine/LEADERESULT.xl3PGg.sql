create function leaderesult(serialnoArg in varchar2)
--获取组长审批结论
 return varchar2
is
trialresult varchar2(200) ;
begin
  select phaseaction into trialresult
    from flow_task
   where  objectno = serialnoArg and flowno='CreditFlow'
     and serialno = (select max(serialno)
                       from flow_task
                      where objectno = serialnoArg
                        and phaseno='0047' and flowno='CreditFlow' );
  return trialresult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end leaderesult;

/

