create function getassistantmanager(serialnoArg in varchar2)
 --得到案件门店副理
 return varchar2
 is
  nameid varchar2(40);
begin
  select userid　into nameid
    from user_info where belongorg in (
       select inputorgid from business_apply where serialno=serialnoArg)
    and userid in (select userid from user_role
       where roleid ='410')
    and status = '1';

  return(nameid);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getassistantmanager;
/

