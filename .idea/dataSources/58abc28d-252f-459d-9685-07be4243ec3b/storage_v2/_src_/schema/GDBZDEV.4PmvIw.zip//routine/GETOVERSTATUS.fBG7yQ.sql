create function GETOVERSTATUS(serialnoArg in varchar2)
return varchar2
is overduestatus varchar2(20);
begin
    select case when al.overduedays>= 1 and al.overduedays <= 29 then  'M1'
    when al.overduedays>=30 and al.overduedays<=59 then  'M2'
    when al.overduedays>=60 and al.overduedays<=89 then  'M3'
      when al.overduedays>=90 then  'M3+'
        else 'C' end into overduestatus from acct_loan al where al.baserialno=serialnoArg;
  return overduestatus;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     --DBMS_OUTPUT.put_line(SQLERRM);
  return '';
  WHEN OTHERS THEN
    --DBMS_OUTPUT.put_line(SQLERRM);
  return '';

end GETOVERSTATUS;
/

