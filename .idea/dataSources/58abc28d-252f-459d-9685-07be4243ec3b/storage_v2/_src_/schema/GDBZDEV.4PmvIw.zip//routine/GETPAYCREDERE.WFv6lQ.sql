create function getpaycredere (serialnoArg in varchar2)
--获取理赔金额
return varchar2
is
  paycredere number(24,6);
begin
  select paycredere into paycredere from acct_recovery_loss where serialno=serialnoArg;
  return(paycredere);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getpaycredere ;
/

