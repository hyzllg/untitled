create function         claimCurrentSeqId(pi_ba_serial_no in varchar2)
  return varchar2 is
  Result varchar2(30);
  result2 number;
--理赔案件当前期次
begin
  begin
    select to_char(trunc(months_between(sysdate,to_date(al.putoutdate,'yyyy/MM/dd'))),'9999') into Result
    from acct_loan al where al.baserialno=pi_ba_serial_no;
    select trunc(add_months(to_date(al.putoutdate,'yyyy/MM/dd'),Result),'MM')-trunc(sysdate,'MM') into result2
    from acct_loan al where al.baserialno=pi_ba_serial_no;
    if result2<0 then
      Result:=Result+1;
    else
      Result:=Result+0;
    end if;
  exception
    when no_data_found then
      Result := '';
    when others then
      Result := '';
  end;

  return(Result);
end claimCurrentSeqId;

/

