create FUNCTION GETHOMETOWN2(pCUSTOMERID varchar)
return varchar2
is hometown2 varchar(80);
   temp1 varchar(80);
   temp2 varchar(80);
begin

select GETITEMNAME('AreaCode',NATIVEPROVINCE) ,GETITEMNAME('AreaCode',NATIVECITY) into temp1 ,temp2  from ind_info where CUSTOMERID=pCUSTOMERID;

hometown2:=substr(temp2,length(temp1)+1,length(temp2)-length(temp1));

return hometown2 ;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

