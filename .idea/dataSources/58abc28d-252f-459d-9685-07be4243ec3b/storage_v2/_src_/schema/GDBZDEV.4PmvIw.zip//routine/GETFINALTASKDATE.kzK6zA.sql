create function getfinaltaskdate(objectnoArg varchar2)
--获单时间（终审）
return varchar2
is
  finaltaskdate varchar2(20);
begin
  select decode(nvl(STANDARDTIME1, 0),'0',flow_task.begintime,STANDARDTIME1) into finaltaskdate
    from flow_task
   where serialno = (select serialno from (select serialno
                       from flow_task
                      where objectno = objectnoArg
                        and phaseno = '0040' and flowno='CreditFlow' order by begintime asc)where rownum=1);

  return(finaltaskdate);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfinaltaskdate;

/

