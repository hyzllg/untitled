create FUNCTION gethighloanproportion(pOrgid varchar)
return varchar2
is pLoanproportion varchar(10);
begin
select loanproportion into pLoanproportion from LOANPROPORTION where orgid=(select belongorgid from org_info where orgid=pOrgid);
return pLoanproportion;
end;
/

