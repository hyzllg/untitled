create FUNCTION getlfCode(pItemNo varchar)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  select nvl(getBankCode('0472','landCode',pItemNo),pItemNo) into pItemName  from dual;
  if pItemName is null then
            return pItemName;
  else
            return pItemName;
  end if;
end;
/

