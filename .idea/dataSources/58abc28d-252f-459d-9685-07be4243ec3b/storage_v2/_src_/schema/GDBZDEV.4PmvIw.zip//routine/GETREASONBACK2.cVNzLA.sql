create function getreasonback2(serialnoArg in varchar2)
--终审回退初审原因
return varchar2
is reasonback2 varchar2(100);
   num integer;
begin
select GetFinalBackTrial(serialnoArg) into num from dual;
if num >0 then
select phaseopinion1||'-'||phaseopinion2 into reasonback2
 from flow_opinion where serialno=(select serialno from (
   select serialno
   from flow_opinion
   where reasoncode1 is not null
   and phasechoice = '终审回退初审'
   and objectno = serialnoArg order by updatetime desc) where rownum=1);
else
   select '' into reasonback2 from dual;

  end if;
  return(reasonback2);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getreasonback2;

/

