create procedure updatePolicyUnderwriter(oldApplyNo in varchar2, newApplyNo in varchar2) as
       begin
              Update business_apply set (SIGNSUM,SIGNTERM,PREMIUM)=(select SIGNSUM,SIGNTERM,PREMIUM from business_apply where serialno=oldApplyNo) where serialno=newApplyNo;
              insert into flow_task (serialno,objectno,objecttype,relativeserialno,flowno,flowname,phaseno,phasename,phasetype,applytype,userid,username,orgid,orgname,begintime,endtime,phaseaction) select sys_guid(),newApplyNo,objecttype,relativeserialno,flowno,flowname,phaseno,phasename,phasetype,applytype,userid,username,orgid,orgname,to_char(sysdate,'yyyy/MM/dd HH24:mi:ss'),to_char(sysdate,'yyyy/MM/dd HH24:mi:ss'),phaseaction from (select * from flow_task where objectno=oldApplyNo and phaseno='0040' order by begintime desc)  where rownum=1;
              commit;
       end updatePolicyUnderwriter;
/

