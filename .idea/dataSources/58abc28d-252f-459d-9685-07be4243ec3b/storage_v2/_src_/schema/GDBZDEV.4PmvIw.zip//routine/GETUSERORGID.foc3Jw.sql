create FUNCTION getuserorgid(pUserid varchar)
return varchar
is a number(20);
begin
select count(*) into a 
  from collection_info ci
 where ci.firstorgid in
       (select uo.orgid from user_org uo where uo.userid = pUserid)
    or ci.lastorgid in
       (select uo.orgid from user_org uo where uo.userid = pUserid); 
  return a;
end;
/

