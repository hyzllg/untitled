create FUNCTION           "GETITEMATTRIBUTE7"(pItemNo varchar)
return varchar
is  pATTRIBUTE7  varchar(20);
begin
	select ATTRIBUTE7 into pATTRIBUTE7
	from Code_Library
	where CodeNo in('AreaCodeP','AreaCodeC','AreaCodeD') and ItemNo=pItemNo;
  if pATTRIBUTE7 is null then
            return '';
	else
            return pATTRIBUTE7;
	end if;
end;
/

