create FUNCTION demo_fun(Name VARCHAR2,Age INTEGER,Sex VARCHAR2)
RETURN VARCHAR2
is V_var VARCHAR2(32);
BEGIN
  V_var := name||'：'||TO_CHAR(age)||'岁.'||sex;
  RETURN v_var;
EXCEPTION
WHEN NO_DATA_FOUND THEN
return Name;
WHEN OTHERS THEN
return Name;
END;
/

