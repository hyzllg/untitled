create FUNCTION getPartenerName(sCustomerID varchar)
return varchar
is sStatusName varchar(20);
begin
   SELECT DECODE(RELATION,
                 '0301',
                 FULLNAME,
                 (DECODE(RELATION1,
                         '0301',
                         FULLNAME1,
                         (DECODE(RELATION2,
                                 '0301',
                                 FULLNAME2,
                                 DECODE(RELATION3,
                                        '0301',
                                        FULLNAME3,
                                        DECODE(RELATION4,
                                               '0301',
                                               FULLNAME4,
                                               DECODE(RELATION5,
                                                      '0301',
                                                      FULLNAME5,
                                                      DECODE(RELATION6,
                                                             '0301',
                                                             FULLNAME6,
                                                             DECODE(RELATION7,
                                                                    '0301',
                                                                    FULLNAME7,
                                                                    DECODE(RELATION8,
                                                                           '0301',
                                                                           FULLNAME8,
                                                                           DECODE(RELATION9,
                                                                                  '0301',
                                                                                  FULLNAME9,
                                                                                  ''))))))))))))
     INTO SSTATUSNAME
     FROM CUSTOMER_RELATIVE
   where CustomerID=sCustomerID  ;
   if sStatusName is not null then
      return sStatusName;
   ELSE
       return sStatusName;
   end if;
end;

/

