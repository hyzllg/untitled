create function getApproveRefuse(pSerialno in VARCHAR2)
--获得最终的审批状态
return VARCHAR2
IS sSerialno VARCHAR2(50);
   sPhaseno  VARCHAR2(50);
begin
   SELECT MAX(serialno) INTO sSerialno FROM flow_task WHERE objecttype = 'CreditApply' AND objectno = pSerialno;
	 SELECT ft.phaseno INTO sPhaseno FROM flow_task ft WHERE ft.objecttype = 'CreditApply' AND ft.serialno = sSerialno;
  return sPhaseno;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getApproveRefuse;
/

