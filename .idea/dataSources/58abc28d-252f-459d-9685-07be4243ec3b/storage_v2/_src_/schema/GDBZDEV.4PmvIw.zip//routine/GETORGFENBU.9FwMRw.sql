create function GetOrgFenBu(orgArg in varchar2)
--获取门店所在市分部
 return varchar2 is
  vOrgId varchar(32);
begin
  select t.orgid
    into vOrgId
    from org_info t
   where t.orgname like '%市分部%'
     and rownum = 1
   start with t.orgid = orgArg
  connect by t.orgid = prior t.belongorgid;
  return vOrgId;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end GetOrgFenBu;

/

