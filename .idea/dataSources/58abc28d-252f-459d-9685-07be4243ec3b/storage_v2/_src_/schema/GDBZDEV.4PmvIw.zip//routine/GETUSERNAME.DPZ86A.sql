create FUNCTION getusername(pUserID varchar)
return varchar
is pUserName  varchar(80);
begin
select UserName into pUserName from User_Info where userid = pUserID;
return pUserName;
end;
/

