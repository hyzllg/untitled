create function getApproveStatus(pSerialno in VARCHAR2)
--获得是否审批通过
return NUMBER
IS flag NUMBER(10);
begin
   SELECT COUNT(1) INTO flag FROM flow_task WHERE objecttype = 'CreditApply' AND phaseno IN ('0050','0070','1000') AND objectno = pSerialno;
  if flag = 0 then
  	select COUNT(1) into flag from business_apply ba,creditaudittable ct where ba.serialno=ct.serialno and ba.serialno=pSerialno and ct.newapprovebaserialno is not null;
end if;
  return flag;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end;
/

