create function getTaskNo0020(serialnoArg in varchar2)
--复核回退时间
return varchar2
is sreviewmaxno varchar2(20);
begin
  select serialno into sreviewmaxno
     from  (select serialno from flow_task
      where objectno=serialnoArg and phaseno='0020' order by begintime desc) where rownum=1 ;
  return sreviewmaxno;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getTaskNo0020;
/

