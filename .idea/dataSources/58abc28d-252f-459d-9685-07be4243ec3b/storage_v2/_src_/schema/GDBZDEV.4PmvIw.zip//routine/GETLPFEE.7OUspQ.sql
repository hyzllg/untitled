create FUNCTION getLPFee( payserialno IN VARCHAR2)
return number is
  amt2 number;
begin
   select nvl(sum(nvl(actualpayfeeamt1,0)),0) into amt2
    from acct_back_detail
   where psserialno = payserialno
     and paytype <> '6';
  return(amt2);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end getLPFee;
/

