create function getaaa(pSerialno varchar)
return Varchar2
IS
    overdays              Number(8);
    blance            Number(16);
BEGIN
    select al.overduedays into overdays  from acct_loan al where serialno = pSerialno;
    IF overdays = 0 THEN
      blance:= 0;
    ELSE
     select (nvl(overduebalance,0)+nvl(interestbalance,0)+nvl(fineintebalance,0)+nvl(feeamtbalance,0)+nvl(overduefinebalance,0))  as overSum into pBalance
  from acct_loan al;
    END IF;
    RETURN blance;
EXCEPTION
    WHEN OTHERS THEN
    RETURN NULL;
END;
/

