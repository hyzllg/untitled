create FUNCTION getAgentBaseRate(pchanneltype varchar,pAgentTypeNo varchar)
return Number
is  pBaseRate Number(16,8);
begin
  pBaseRate:=1;
  select nvl((select bc.number_value1/100
             FROM cust_business_config bc
            where bc.CATALOG_CODE = 'BASE_AGENTFEE_RATE'
              and bc.PRODUCT_CODE = pchanneltype and CONFIG_KEY= pAgentTypeNo and bc.isinuse='1' and rownum=1 ),
           (select bc.number_value1/100
              FROM cust_business_config bc
             where bc.CATALOG_CODE = 'BASE_AGENTFEE_RATE'
               and bc.PRODUCT_CODE = '其他'  and CONFIG_KEY= pAgentTypeNo and bc.isinuse='1' and rownum=1 ))
  into pBaseRate
  from dual;
  return pBaseRate;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return pBaseRate;
  WHEN OTHERS THEN
  return pBaseRate;
end;
/

