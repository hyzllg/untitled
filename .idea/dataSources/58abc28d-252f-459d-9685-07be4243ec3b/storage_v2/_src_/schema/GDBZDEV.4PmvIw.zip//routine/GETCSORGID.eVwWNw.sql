create FUNCTION getcsorgid(pSerialno varchar)
return varchar
is pOrgID varchar2(80);
begin
  select csmanageorgid into pOrgID
    from business_apply where serialno = pSerialno;
 return pOrgID;
end;
/

