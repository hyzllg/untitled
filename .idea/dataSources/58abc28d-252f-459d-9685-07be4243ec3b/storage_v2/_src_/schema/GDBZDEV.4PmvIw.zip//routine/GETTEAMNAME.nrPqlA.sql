create function getteamname(teamidArg in varchar2)
----获取催收团队名称
return varchar2

is
  teamname varchar2(32);
begin
  select teamname into teamname
    from urge_team_info where teamid = teamidArg;
  return(teamname);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getteamname;
/

