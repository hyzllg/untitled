create function GETLASTAPPLYSTATUS(serialnoArg in varchar2)
return varchar2
is lastapplystatus varchar2(20) ;
begin
  select case when exists(select 1 from acct_loan al where al.customerid=ba.customerid and al.finishdate is not null) then '结清'
  when ba.phaseno in ('2000','2010','2020','2030','2031','2032','2050','2060','2070','2085','2087','2090','2095','3030','3052','3054','2089') then '取消'
  when ba.phaseno in ('2040','2080','3000','3020','3021','3033','3040','3050','3051','3053','3060','3070','3080','3090','3091','3092','3093','3094','3095') then '拒绝'
  else '结清'
  end INTO lastapplystatus
  from business_apply ba where ba.serialno=(select max(ba1.serialno) from business_apply ba1 where ba1.serialno<serialnoArg
  and ba1.customerid= (select ba2.customerid from business_apply ba2 where ba2.serialno=serialnoArg));
  return lastapplystatus;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
     --DBMS_OUTPUT.put_line(SQLERRM);
  return '';
  WHEN OTHERS THEN
    --DBMS_OUTPUT.put_line(SQLERRM);
  return '';

end GETLASTAPPLYSTATUS;
/

