create function getbeginendtime(serialnoArg in varchar2)
--获得立案/结案时间
return varchar2
is
  paydate varchar2(20);
begin
  select created_date
    into paydate
    from acct_recovery_loss
   where baserialno = serialnoArg;
  return(paydate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getbeginendtime;
/

