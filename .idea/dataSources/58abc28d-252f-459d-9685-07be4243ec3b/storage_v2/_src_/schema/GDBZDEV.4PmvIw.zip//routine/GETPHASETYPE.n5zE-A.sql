create FUNCTION getphasetype(sFlowNo varchar,sPhaseNo varchar)
return varchar
is sPhaseType varchar(80);
begin
select PhaseType into sPhaseType from FLOW_MODEL where
                FlowNo = sFlowNo and PhaseNo = sPhaseNo;
return sPhaseType;
end;

/

