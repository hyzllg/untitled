create PACKAGE BODY dw_data_handler_pck IS

  c_package_name CONSTANT VARCHAR2(300) := 'dw_data_handler_pkg';
  c_sysdate DATE := SYSDATE;
  c_owner                 VARCHAR2(50)  := 'GDBZDEV';
  --dw_trailbalance_fs的预处理,主要求期初余额（科目不同，计算方式不同），再者使用预处理表只保存一个月数据，提高计算效率
  PROCEDURE gen_fst_trailbalance(p_period_name VARCHAR2) IS
    BEGIN
     -- 开启并发
     dw_util_pkg.enable_session_parallel(2);


     -- 清除数据
     dw_util_pkg.truncate_table(c_owner, 'DW_TRAILBALANCE_FST');

       INSERT INTO dw_trailbalance_fst
         (period_name         ,
          ledger_id           ,
          currency_code       ,
          company_code        ,
          costcenter_code     ,
          account_code        ,
          bugdetaccount_code  ,
          department_code     ,
          subaccount_code     ,
          product_code        ,
          channel_code        ,
          intcom_code         ,
          spare1_code         ,
          spare2_code         ,
          period_begin_dr     ,
          period_begin_cr     ,
          period_begin_amount ,
          period_net_dr       ,
          period_net_cr       ,
          period_net_amount   ,
          created_on_dt       ,
          changed_on_dt       ,
          w_insert_dt         ,
          w_update_dt         ,
          delete_flag         ,
          datasource_num_id   ,
          integration_id)
         SELECT glb.period_name        AS period_name,
                glb.set_of_books_id    AS ledger_id,
                glb.currency_code      AS currency_code,
                glc.segment1           AS company_code,
                ''                     AS costcenter_code,
                glc.segment2           AS account_code,
                ''                     AS budgetaccount_code,
                glc.segment3           AS department_code,
                glc.segment4           AS subaccount_code,
                glc.segment5           AS product_code,
                glc.segment6           AS channel_code,
                glc.segment7           AS intcom_code,
                glc.segment8           AS spare1_code,
                ''                     AS spare2_code,
                glb.begin_balance_dr   AS period_begin_dr,
                glb.begin_balance_cr   AS period_begin_cr,
                CASE WHEN glc.account_type IN ('A', 'E') THEN
                         1
                     WHEN glc.account_type IN ('L', 'O', 'R') THEN
                         -1
                 END * (glb.begin_balance_dr - glb.begin_balance_cr)  AS period_begin_amount,
                glb.period_net_dr      AS period_net_dr,
                glb.period_net_cr      AS period_net_cr,
                CASE WHEN glc.account_type IN ('A', 'E') THEN
                         1
                     WHEN glc.account_type IN ('L', 'O', 'R') THEN
                         -1
                 END * (glb.period_net_dr - glb.period_net_cr)        AS ptd_amount,

                glb.last_update_date   AS created_on_dt,
                glb.last_update_date   AS changed_on_dt,
                c_sysdate              AS w_insert_dt,
                ''                     AS w_update_dt,
                'N'                    AS delete_flag,
                'EBS'                  AS datasource_num_id,
                ''                     AS integration_id
           FROM gl_balances glb, gl_code_combinations glc
          WHERE glb.code_combination_id = glc.code_combination_id
            AND glb.set_of_books_id='1002'
            AND glb.template_id IS NULL
            AND (nvl(glb.begin_balance_dr, 0) <> 0 OR
                 nvl(glb.begin_balance_cr, 0) <> 0 OR
                 nvl(glb.period_net_dr, 0) <> 0 OR
                 nvl(glb.period_net_cr, 0) <> 0)
            AND glc.segment1 LIKE '143117%'
            AND glb.period_name = p_period_name;
         COMMIT;

       -- 关闭并发
       dw_util_pkg.disable_session_parallel;
    END gen_fst_trailbalance;

    --dw_trailbalance_fs的处理, 主要计算上期，去年等不同期间下的度量数据，保存历史数据
   PROCEDURE gen_fs_trailbalance(x_return_status        OUT VARCHAR2,
                                 p_plan_node_control_id NUMBER,
                                 p_period_name          VARCHAR2,
                                 p_ledger_id            NUMBER) IS
     l_procedure_name        VARCHAR2(300) := 'gen_fs_trailbalance(' ||
                                              'x_return_status => ''' ||
                                              x_return_status || ''',' ||
                                              'p_plan_node_control_id => ''' ||
                                              p_plan_node_control_id ||
                                              ''',' || 'p_period_name => ''' ||
                                              p_period_name || ''',p_ledger_id =>''' ||
                                              p_ledger_id ||''''|| ');';
     l_stage                 VARCHAR2(300);
     l_execute_begining_date DATE := SYSDATE;
     l_period_name           VARCHAR2(300) := REPLACE(p_period_name, '-', '');
     BEGIN
        dw_util_pkg.log_infor('开始生成dw_trailbalance_fs数据',
                          p_plan_node_control_id,
                          c_package_name || '.' || l_procedure_name);

        -- 生成Fact Stage Temp表的数据
        l_stage := '生成临时表数据';
        dw_util_pkg.log_infor(l_stage,
                              p_plan_node_control_id,
                              c_package_name || '.' || l_procedure_name);
        gen_fst_trailbalance(p_period_name);

        -- 开启并发
        dw_util_pkg.enable_session_parallel(2);

        -- 增加分区
        l_stage := '增加分区';
        dw_util_pkg.log_infor(l_stage,
                              p_plan_node_control_id,
                              c_package_name || '.' || l_procedure_name);
        FOR r_sob IN (SELECT * FROM dw_gd_ledger_d) LOOP
          dw_util_pkg.add_partition(c_owner,
                                    'DW_TRAILBALANCE_FS',
                                    l_period_name,
                                    p_period_name,
                                    r_sob.ledger_id,
                                    r_sob.ledger_id);
        END LOOP;
        BEGIN
          dw_util_pkg.disable_index(p_owner     => c_owner,
                                    p_table     => 'DW_TRAILBALANCE_FS',
                                    p_partition => l_period_name);
        END;
        -- 清除数据
        l_stage := '清除已生成数据';
        dw_util_pkg.log_infor(l_stage,
                              p_plan_node_control_id,
                              c_package_name || '.' || l_procedure_name);
        dw_util_pkg.truncate_table(c_owner, 'DW_TRAILBALANCE_FS', l_period_name, p_ledger_id);

        -- 生成数据
        l_stage := '生成数据';
        dw_util_pkg.log_infor(l_stage,
                              p_plan_node_control_id,
                              c_package_name || '.' || l_procedure_name);
            INSERT INTO dw_trailbalance_fs
               (period_name         ,
                ledger_id           ,
                currency_code       ,
                company_code        ,
                costcenter_code     ,
                account_code        ,
                bugdetaccount_code  ,
                department_code     ,
                subaccount_code     ,
                product_code        ,
                channel_code        ,
                intcom_code         ,
                spare1_code         ,
                spare2_code         ,
                period_begin_dr     ,
                period_begin_cr     ,
                period_begin_amount ,
                period_net_dr       ,
                period_net_cr       ,
                ptd_amount          ,
                period_end_dr       ,
                period_end_cr       ,
                period_end_amount   ,
                year_net_dr         ,
                year_net_cr         ,
                ytd_amount          ,
                std_amount          ,
                last_month_ptd      ,
                last_month_ytd      ,
                last_year_ptd       ,
                last_year_ytd       ,
                last_year_end_ytd   ,
                created_on_dt       ,
                changed_on_dt       ,
                w_insert_dt         ,
                w_update_dt         ,
                delete_flag         ,
                datasource_num_id   ,
                integration_id      ,
                year_begin_amount)
      SELECT p_period_name          AS period_name,
             ledger_id              AS ledger_id,
             currency_code          AS currency_code,
             company_code           AS company_code,
             costcenter_code        AS costcenter_code,
             account_code           AS account_code,
             bugdetaccount_code     AS bugdetaccount_code,
             department_code        AS department_code,
             subaccount_code        AS subaccount_code,
             product_code           AS product_code,
             channel_code           AS channel_code,
             intcom_code            AS intcom_code,
             spare1_code            AS spare1_code,
             spare2_code            AS spare2_code,
             SUM(period_begin_dr)   AS period_begin_dr,
             SUM(period_begin_cr)   AS period_begin_cr,
             SUM(period_begin_amount) AS period_begin_amount,
             SUM(period_net_dr)       AS period_net_dr,
             SUM(period_net_cr)       AS period_net_cr,
             SUM(ptd_amount)          AS ptd_amount,
             SUM(period_end_dr)       AS period_end_dr,
             SUM(period_end_cr)       AS period_end_cr,
             SUM(period_end_amount)   AS period_end_amount,
             SUM(year_net_dr)         AS year_net_dr,
             SUM(year_net_cr)         AS year_net_cr,
             SUM(ytd_amount)          AS ytd_amount,
             SUM(std_amount)          AS std_amount,
             SUM(last_month_ptd)      AS last_month_ptd,
             SUM(last_month_ytd)      AS last_month_ytd,
             SUM(last_year_ptd)       AS last_year_ptd,
             SUM(last_year_ytd)       AS last_year_ytd,
             SUM(last_year_end_ytd)   AS last_year_end_ytd,
             MAX(created_on_dt)       AS created_on_dt,
             MAX(changed_on_dt)       AS changed_on_dt,
             c_sysdate                AS w_insert_dt,
             ''                       AS w_update_dt,
             'N'                      AS delete_flag,
             'EBS'                    AS datasource_num_id,
             ''                       AS integration_id,
             SUM(year_begin_amount)   AS year_begin_amount
        FROM (
              -- 当期数据
              SELECT  ledger_id,
                      currency_code,
                      company_code,
                      costcenter_code,
                      account_code,
                      bugdetaccount_code,
                      department_code,
                      subaccount_code,
                      product_code,
                      channel_code,
                      intcom_code,
                      spare1_code,
                      spare2_code,
                      period_begin_dr,
                      period_begin_cr,
                      period_begin_amount,
                      period_net_dr,
                      period_net_cr,
                      period_net_amount                           AS ptd_amount,
                      period_begin_dr + period_net_dr             AS period_end_dr,
                      period_begin_cr + period_net_cr             AS period_end_cr,
                      period_begin_amount + period_net_amount     AS period_end_amount,
                      period_net_dr                               AS year_net_dr,
                      period_net_cr                               AS year_net_cr,
                      period_net_amount                           AS ytd_amount,
                      period_net_amount                           AS std_amount,
                      0                                           AS last_month_ptd,
                      0                                           AS last_month_ytd,
                      0                                           AS last_year_ptd,
                      0                                           AS last_year_ytd,
                      0                                           AS last_year_end_ytd,
                      created_on_dt,
                      changed_on_dt,
                      0                                           AS year_begin_amount
                FROM gdbzdev.dw_trailbalance_fst t
               WHERE t.period_name = p_period_name

              UNION ALL
              -- 上期数据，用于计算YTD，注意一月不用算
              SELECT  ledger_id,
                      currency_code,
                      company_code,
                      costcenter_code,
                      account_code,
                      bugdetaccount_code,
                      department_code,
                      subaccount_code,
                      product_code,
                      channel_code,
                      intcom_code,
                      spare1_code,
                      spare2_code,
                      0                  period_begin_dr,
                      0                  period_begin_cr,
                      0                  period_begin_amount,
                      0                  period_net_dr,
                      0                  period_net_cr,
                      0                  ptd_amount,
                      0                  period_end_dr,
                      0                  period_end_cr,
                      0                  period_end_amount,
                      year_net_dr        year_net_dr,
                      year_net_cr        year_net_cr,
                      ytd_amount         ytd_amount,
                      0                  std_amount,
                      0                  last_month_ptd,
                      0                  last_month_ytd,
                      0                  last_year_ptd,
                      0                  last_year_ytd,
                      0                  last_year_end_ytd,
                      created_on_dt,
                      changed_on_dt,
                      0                  year_begin_amount
                FROM gdbzdev.dw_trailbalance_fs t
               WHERE t.period_name =
                     dw_getdimwid_pkg.get_last_period_name(p_period_name)
                 AND p_period_name NOT LIKE '%01'
                 AND t.ledger_id = p_ledger_id

              UNION ALL
              -- 上期数据 - 算开业至今及上期PTD/YTD用
              SELECT  ledger_id,
                      currency_code,
                      company_code,
                      costcenter_code,
                      account_code,
                      bugdetaccount_code,
                      department_code,
                      subaccount_code,
                      product_code,
                      channel_code,
                      intcom_code,
                      spare1_code,
                      spare2_code,
                      0                  period_begin_dr,
                      0                  period_begin_cr,
                      0                  period_begin_amount,
                      0                  period_net_dr,
                      0                  period_net_cr,
                      0                  ptd_amount,
                      0                  period_end_dr,
                      0                  period_end_cr,
                      0                  period_end_amount,
                      0                  year_net_dr,
                      0                  year_net_cr,
                      0                  ytd_amount,
                      std_amount         std_amount,
                      ptd_amount         last_month_ptd,
                      ytd_amount         last_month_ytd,
                      0                  last_year_ptd,
                      0                  last_year_ytd,
                      0                  last_year_end_ytd,
                      created_on_dt,
                      changed_on_dt,
                      0                  year_begin_amount
                FROM gdbzdev.dw_trailbalance_fs t
               WHERE t.period_name =
                     dw_getdimwid_pkg.get_last_period_name(p_period_name)
                 AND t.ledger_id = p_ledger_id

              UNION ALL
              -- 去年同期数据
              SELECT  ledger_id,
                      currency_code,
                      company_code,
                      costcenter_code,
                      account_code,
                      bugdetaccount_code,
                      department_code,
                      subaccount_code,
                      product_code,
                      channel_code,
                      intcom_code,
                      spare1_code,
                      spare2_code,
                      0                  period_begin_dr,
                      0                  period_begin_cr,
                      0                  period_begin_amount,
                      0                  period_net_dr,
                      0                  period_net_cr,
                      0                  ptd_amount,
                      0                  period_end_dr,
                      0                  period_end_cr,
                      0                  period_end_amount,
                      0                  year_net_dr,
                      0                  year_net_cr,
                      0                  ytd_amount,
                      0                  std_amount,
                      0                  last_month_ptd,
                      0                  last_month_ytd,
                      ptd_amount         last_year_ptd,
                      ytd_amount         last_year_ytd,
                      0                  last_year_end_ytd,
                      created_on_dt,
                      changed_on_dt,
                      0                  year_begin_amount
                FROM gdbzdev.dw_trailbalance_fs t
               WHERE t.period_name =
                     dw_getdimwid_pkg.get_last_year_period_name(p_period_name)
                 AND t.ledger_id = p_ledger_id

              UNION ALL
              -- 去年年末数据
              SELECT  ledger_id,
                      currency_code,
                      company_code,
                      costcenter_code,
                      account_code,
                      bugdetaccount_code,
                      department_code,
                      subaccount_code,
                      product_code,
                      channel_code,
                      intcom_code,
                      spare1_code,
                      spare2_code,
                      0                  period_begin_dr,
                      0                  period_begin_cr,
                      0                  period_begin_amount,
                      0                  period_net_dr,
                      0                  period_net_cr,
                      0                  ptd_amount,
                      0                  period_end_dr,
                      0                  period_end_cr,
                      0                  period_end_amount,
                      0                  year_net_dr,
                      0                  year_net_cr,
                      0                  ytd_amount,
                      0                  std_amount,
                      0                  last_month_ptd,
                      0                  last_month_ytd,
                      0                  last_year_ptd,
                      0                  last_year_ytd,
                      ytd_amount         last_year_end_ytd,
                      created_on_dt,
                      changed_on_dt,
                      period_end_amount  year_begin_amount
                FROM gdbzdev.dw_trailbalance_fs t
               WHERE t.period_name =
                     dw_getdimwid_pkg.get_last_year_end_period_name(p_period_name)
                 AND t.ledger_id = p_ledger_id)
       GROUP BY  ledger_id,
                 currency_code,
                 company_code,
                 costcenter_code,
                 account_code,
                 bugdetaccount_code,
                 department_code,
                 subaccount_code,
                 product_code,
                 channel_code,
                 intcom_code,
                 spare1_code,
                 spare2_code;
       COMMIT;
        BEGIN
          dw_util_pkg.rebuild_index(p_owner     => c_owner,
                                    p_table     => 'DW_TRAILBALANCE_FS',
                                    p_partition => l_period_name);
        END;
        BEGIN
          dbms_stats.unlock_table_stats(ownname => c_owner,
                                        tabname => 'DW_TRAILBALANCE_FS');

          dbms_stats.gather_table_stats(ownname          => c_owner,
                                        tabname          => 'DW_TRAILBALANCE_FS',
                                        partname         => '"' || l_period_name || '"',
                                        estimate_percent => 80,
                                        degree           => 32,
                                        cascade          => TRUE);

        END;
        -- 关闭并发
        dw_util_pkg.disable_session_parallel;

        dw_util_pkg.log_infor('生成数据完成！共执行时间（分钟）：' ||
                              dw_util_pkg.executing_time(l_execute_begining_date),
                              p_plan_node_control_id,
                              c_package_name || '.' || l_procedure_name);

        x_return_status := 'Y';

      EXCEPTION
        WHEN OTHERS THEN
          x_return_status := 'N';
          dw_util_pkg.log_error(l_stage || '错误:' || SQLERRM,
                                p_plan_node_control_id,
                                c_package_name || '.' || l_procedure_name);


     END gen_fs_trailbalance;
END dw_data_handler_pck;
/

