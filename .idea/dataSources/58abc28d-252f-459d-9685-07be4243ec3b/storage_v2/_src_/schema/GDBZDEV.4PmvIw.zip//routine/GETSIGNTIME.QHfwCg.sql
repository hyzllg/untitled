create function GETSIGNTIME(serialnoArg in varchar2)
return varchar2
is signtime varchar2(20) ;
begin
select min(ft.inputdate) into signtime
  from applypolicyno ft
 WHERE ft.status <> '1'
   and ft.applyno = serialnoArg;
   if signtime is not null then
     signtime := substr(signtime,1,10);
   else signtime:='' ;
     end if;
  return signtime;
end GETSIGNTIME;

/

