create FUNCTION getloanproportion(pOrgid varchar2,pPutoutorg varchar2)
return varchar2
is pLoanproportion varchar2(10);
begin
SELECT round(li.putoutsum/(select sum(li.putoutsum) FROM  LOANPROPORTION_INFO li where li.inputorgid=pOrgid),4)*100 INTO pLoanproportion FROM  LOANPROPORTION_INFO li where li.inputorgid=pOrgid and li.putoutorg=pPutoutorg;
return pLoanproportion;
end;
/

