create FUNCTION getrolename(pRoleID varchar)
return varchar
is pRoleName varchar(80);
begin
select RoleName into pRoleName
from Role_info
 where Roleid = pRoleID;
 return pRoleName;
end;

/

