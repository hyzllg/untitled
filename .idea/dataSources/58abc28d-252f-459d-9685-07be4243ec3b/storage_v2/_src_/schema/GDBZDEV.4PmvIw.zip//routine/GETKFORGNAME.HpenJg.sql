create FUNCTION getkforgname(pSerialno varchar)
return varchar
is pOrgName varchar(80);
begin
select orgname
  into pOrgName
  from org_info
 where orgid =
       (select inputorgid from business_apply where serialno = pSerialno);
 return pOrgName;
end;
/

