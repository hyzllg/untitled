create FUNCTION getAcctAgenc(oOrgid varchar)
return varchar
is
sMforgid varchar(20);
sOrgid  varchar(20);
sAcctAgenc varchar(2);
isExist integer;
begin
  sOrgid :=oOrgid;
  loop
    select count(*) into isExist  from (select orgid from org_info where orgid=sOrgid);
    if isExist=0 then
      exit;
    end if;
    select nvl(mfogrid,''),belongorgid,nvl(isacctagenc,'2') into sMforgid,sOrgid,sAcctAgenc from ORG_INFO where orgid=sOrgid;
    if sAcctAgenc='1' then
      exit;
    end if;
  end loop;
  return sMforgid;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getAcctAgenc;

/

