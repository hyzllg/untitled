create FUNCTION getCarcertid(pCarownercertid varchar)
return varchar
is pCarcertid varchar2(80);
begin
  select substr(pCarownercertid,0,4)||'****'||substr(pCarownercertid,length(pCarownercertid)) into pCarcertid from dual;
 return pCarcertid;
end;
/

