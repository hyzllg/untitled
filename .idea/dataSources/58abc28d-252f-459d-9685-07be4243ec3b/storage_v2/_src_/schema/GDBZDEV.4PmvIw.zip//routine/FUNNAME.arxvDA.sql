create Function funname
(
p_1 in int,
p_2 in int,
p_3 out int,
p_4 out int
)
as
begin
    p_3:=p_1;
    p_4:=p_2;
end;

/

