create function GETRELBUSINESSTYPE(pJBusinessType varchar)
--如果该产品的基础产品时6011且目前该基础产品有效，则该产品是有抵押产品
--如果基础产品进行变更或者增加，此function需修改
return varchar2
is pRelBusinessType  varchar2(20);
   pPIFLAG  varchar2(10);
   pStatus  varchar(10);
begin

  select relbusinesstype into pRelBusinessType from business_type where typeno=pJBusinessType;
  select isinuse into pStatus from business_type where typeno=pRelBusinessType;
  select case   when pRelBusinessType ='6011' and pStatus='1' then '1' else '0' end  into pPIFLAG from dual;

  return pPIFLAG;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

