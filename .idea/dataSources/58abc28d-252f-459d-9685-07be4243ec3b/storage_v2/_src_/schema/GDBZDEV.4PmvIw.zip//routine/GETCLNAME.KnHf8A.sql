create FUNCTION getCLName(pSerialNo varchar2)
return varchar2
is pChannel  varchar2(80);
begin
select case when Count(1) >0 then '电销' else '直销' end into pChannel
  from retail_sales_apply
where baSerialNo = pSerialNo;
return pChannel;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

