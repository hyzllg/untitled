create FUNCTION getRuleFlag(sSerialno varchar)
--获取案件最新状态
return varchar2
is
sFlag       varchar2(20);
iCount      varchar2(10);
begin

   select count(1) into iCount from MENTIONFRAUD_INFO mi where mi.objectno = sSerialno and mi.ismentionedfraud = 'N' and  mi.isinuse = '1';

   select case
               when nvl(ba.phaseno,'0010') = '0010' then '1'
               when nvl(ba.phaseno,'0010') in ('0020' ,'0012') then '2'
               when nvl(ba.phaseno,'0010') in ('0030','0035','0040','0045','0047')then '3'
               when nvl(ba.phaseno,'0010') = '0070' then '4'
               else ''
          end
          into sFlag from business_apply ba where ba.serialno = sSerialno;
   if iCount=1  then
      return '5';
   else
      return sFlag;
   end if;

end;
/

