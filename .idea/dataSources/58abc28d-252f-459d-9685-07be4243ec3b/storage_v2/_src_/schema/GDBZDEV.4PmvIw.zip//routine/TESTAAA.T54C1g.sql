create function testAAA(certid varchar2(40),custid varchar2(40))
return varchar
is
    Type Custinfocursor IS  REF CURSOR RETURN azhi_customer_info%RowType;
    vCustomerCur  Custinfocursor;
    vTempC  vCustomerCur%RowType;
    str varchar2(40);
begin
     open  vCustomerCur for select * from azhi_customer_info ci where ci.certid=custid;
     loop
       exit when vCustomerCur%notfound;
       fetch vCustomerCur into vTempC;

        str:='update INSURE_APPLY set customerid='||chr(39)||vTempC.customerid||chr(39)||' where customerid='||chr(39)||custid||chr(39);
        execute immediate str;
        commit;
     end loop;
     close vCustomerCur;
  return '1'
EXCEPTION
WHEN NO_DATA_FOUND THEN
return '2';
WHEN OTHERS THEN
return '2';
end;
/

