create function getCreditCardMaxNum(serialnoArg in varchar2)
--人行单张信用卡最大额度
return varchar2
is creditCardMaxNum  varchar2(200) ;
 irt22f6 varchar2(30);
 irt23f6 varchar2(30);
begin
  select nvl(irt22.f6,'0'),nvl(irt23.f6,'0') into irt22f6,irt23f6
    from ICR_RPT_T22 irt22,ICR_RPT_T23 irt23, icr_cda ic
   where ic.reportno = irt22.rptno
     and ic.reportno = irt23.rptno
     and ic.objectno = serialnoArg;
  if irt22f6>=irt23f6 then
    creditCardMaxNum:=irt22f6 ;
  else
    creditCardMaxNum:=irt23f6 ;
  end if;
  return creditCardMaxNum;

 EXCEPTION
   WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end getCreditCardMaxNum;

/

