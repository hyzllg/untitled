create FUNCTION getcustomername(pCustomerID varchar)
return varchar
is pCustomerName  varchar(80);
begin
select CustomerName into pCustomerName
  from customer_info
where customerid = pCustomerID;
  return pCustomerName;
end;

/

