create function GetOutName(OutID in varchar2)
--获取委外厂商
return varchar2
is
  OutName varchar2(200);
begin
  select manuname
    into OutName
    from out_manufacturer om
   where om.manuid = OutID;
  return OutName ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetOutName;
/

