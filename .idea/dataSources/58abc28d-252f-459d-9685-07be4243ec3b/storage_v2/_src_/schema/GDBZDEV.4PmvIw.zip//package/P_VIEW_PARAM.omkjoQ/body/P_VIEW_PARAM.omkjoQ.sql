create package body p_view_param is

       -- Param
       function set_param(paramVal VARCHAR2) return VARCHAR2 is
        paramValue VARCHAR2(200);
       begin
         paramValue:=paramVal;
         return paramValue;
        end;

       function get_param(paramVal VARCHAR2)  return VARCHAR2 is
       begin
           return paramVal;
       end;
END  p_view_param;
/

