create function getyesnoapply(serialnoArg in varchar2)
--人行是否有申请表单位
return varchar2
is CreditResultDate  varchar2(200) ;
 countnum number(3);
begin
   select count(1) into countnum
     from ICR_RPT_T12 irt12, icr_cda ic
    where ic.reportno = irt12.rptno
      and ic.objectno = serialnoArg;
  if countnum>0 then
    CreditResultDate:='是';
  else
    CreditResultDate:='否';
  end if;
  return CreditResultDate;
 EXCEPTION
   WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end getyesnoapply;

/

