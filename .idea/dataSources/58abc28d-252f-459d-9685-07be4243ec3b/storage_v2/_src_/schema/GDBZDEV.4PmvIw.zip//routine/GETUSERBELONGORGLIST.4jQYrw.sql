create FUNCTION getUserBelongOrgList(sUserID varchar)
--获取某一用户所属机构下的所有机构
return varchar2
is
sOrgList     varchar2(20);
sOrgID       varchar2(20);
sOrglevel      varchar2(10);
begin

   select oi.orglevel into sOrglevel from org_info oi where oi.orgid=(select ui.belongorg from user_info ui where userid=sUserID);
   select oi.orgid into sOrgID from org_info oi where oi.orgid=(select ui.belongorg from user_info ui where userid=sUserID);

   if sOrglevel = 12 then 
   select orgid into sOrgList from org_info where belongorgid in (select orgid from org_info where belongorgid=sOrgID);
   elsif sOrglevel = 13 then 
   select orgid into sOrgList from org_info where belongorgid=sOrgID;
   else 
   select '' into sOrgList from dual;
   end if;     
  return sOrgList;
end;
/

