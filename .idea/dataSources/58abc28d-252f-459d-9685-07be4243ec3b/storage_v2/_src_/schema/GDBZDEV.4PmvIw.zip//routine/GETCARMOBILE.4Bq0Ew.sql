create FUNCTION getCarmobile(pCarownermobile varchar)
return varchar
is pCarmobile varchar2(80);
begin
  select substr(pCarownermobile,0,3)||'****'||substr(pCarownermobile,length(pCarownermobile)-3) into pCarmobile from dual;
 return pCarmobile;
end;
/

