create FUNCTION getMonthBalance(pSerialno varchar)
return varchar
is pBalance  Number(14,2);
begin
select (nvl(al.pmtamount, 0) + nvl(al.PMTGUEFEE, 0)) into pBalance
  from acct_loan al
where serialno = pSerialno;
  return pBalance;
end;
/

