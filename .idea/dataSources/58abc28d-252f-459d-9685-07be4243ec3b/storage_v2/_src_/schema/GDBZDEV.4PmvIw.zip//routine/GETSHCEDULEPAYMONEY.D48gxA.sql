create function GetShcedulePayMoney(seqidArg in number,loanserialnoArg in varchar2)
--获取还款金额
return number
is
  paymoney number(24,7);
begin
  select nvl(aps.ACTUALPAYCORPUSAMT, 0) +
           nvl(aps.ACTUALPAYINTEAMT, 0) + nvl(aps.ACTUALFINEAMT, 0) +
           nvl(aps.ACTUALCOMPDINTEAMT, 0) +
           nvl(aps.ACTUALPAYFEEAMT1,0)+
           nvl(aps.ACTUALPAYFEEAMT2, 0) +
           nvl(aps.ACTUALPAYFEEAMT3, 0) +
           nvl(aps.ACTUALPAYFEEAMT4, 0) +
           nvl(aps.ACTUALPAYFEEAMT5, 0) +
           nvl(aps.ACTUALPAYFEEAMT6, 0) into paymoney
   from acct_payment_schedule_back aps where aps.backinputdate=(to_char(trunc(sysdate-1),'yyyy/mm/dd')) and aps.seqid=seqidArg and aps.objectno=loanserialnoArg ;
  return paymoney;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetShcedulePayMoney;
/

