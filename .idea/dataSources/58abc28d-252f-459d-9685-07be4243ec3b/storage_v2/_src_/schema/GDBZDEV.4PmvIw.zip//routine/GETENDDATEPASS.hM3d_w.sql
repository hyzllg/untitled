create function GetEndDatePass(serialnoArg in varchar2)
--获取审批通过结束日期
return varchar2
is Passendtime varchar2(200) ;
  flag int :=0;
  vPhaseno varchar2(10) :='0050';
begin

  select count(1) into flag  from business_apply ba where instr(ba.businesstypename,'车险预授信',1)>0 and ba.serialno=serialnoArg;
  if (flag=1) then
    vPhaseno:='0020';
  end if;
  select
    case when vPhaseno='0020' then
      substr(endtime,1,10)
    when vPhaseno='0050' then
      substr(begintime,1,10) end into Passendtime
    from flow_task ft
   where serialno = (select serialno from (select serialno
                       from flow_task
                       where exists (select 1
                               from flow_task
                              where phaseno = vPhaseno
                                and objectno = serialnoArg)
                        and phaseno not in ('0070', '1000','2060','2050','2070','2010','2000','2090','2095','3030','3040','3050','3060','3070','3080')
                        and objectno = serialnoArg order by begintime desc) where  rownum=1) and objectno=serialnoArg;
  return Passendtime;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetEndDatePass;
/

