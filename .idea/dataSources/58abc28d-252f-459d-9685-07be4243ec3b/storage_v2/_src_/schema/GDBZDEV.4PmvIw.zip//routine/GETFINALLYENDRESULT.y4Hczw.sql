create function getFinallyEndresult(serialnoArg in varchar2) return varchar2 is
--得到最终结论
  Results varchar2(100);
  a varchar2(5);
  b varchar2(5);
begin
  select status into a from business_apply where serialno=serialnoArg;
  select PutoutFlag into b from business_apply where serialno=serialnoArg;
  if a='1100' and b='5' then
     select '放款取消' into Results from dual;
  else
        select case
               when endtime is not null and (ft.phaseno = '0040' or ft.phaseno = '0030' ) then ft.phasename || '通过'
                             else
                ft.phasename
             end as phasename into Results
        from flow_task ft,business_apply ba
       where (ft.serialno = (select serialno from (select serialno
                           from flow_task
                          where exists (select 1
                                   from flow_task
                                  where phaseno = '0030'
                                    and objectno = serialnoArg
                                    and flowno = 'CreditFlow')

                            and objectno = serialnoArg
                            and flowno = 'CreditFlow' order by begintime desc) where rownum=1)
                             or ft.serialno =(select serialno from (select serialno
                           from flow_task where objectno = serialnoArg
                            and flowno = 'CreditFlow' and phaseno in ('3090','3091','3092') order by begintime desc)where rownum=1))

         and ft.objectno = serialnoArg
         and ft.flowno = 'CreditFlow'
         and ba.serialno=ft.objectno
         and ba.PutoutFlag<>'5';
   end if;
  return(Results);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getFinallyEndresult;
/

