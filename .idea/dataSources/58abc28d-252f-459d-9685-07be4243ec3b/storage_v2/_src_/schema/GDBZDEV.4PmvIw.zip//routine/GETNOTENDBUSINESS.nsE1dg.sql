create function getnotendbusiness(pCustomerID varchar)
return varchar
is
pExistFlag  varchar2(20);
pCount  int;
pCount1  int;
pCount2  int;
begin
select count(SerialNo) into pCount1
  from BUSINESS_CONTRACT
  where CustomerID = pCustomerID
  and FinishDate is null;
select count(SerialNo) into pCount2
  from BUSINESS_APPLY
  where CustomerID = pCustomerID
  and SerialNo in (select ObjectNo
  from FLOW_OBJECT where ObjectType = 'CreditApply'
  and PhaseNo <> '1000' and PhaseNo <> '8000');
pCount := pCount1 + pCount2;
if pCount > 0 then
 pExistFlag := '1';
else
pExistFlag := '2';
end if;
return pExistFlag;
end;

/

