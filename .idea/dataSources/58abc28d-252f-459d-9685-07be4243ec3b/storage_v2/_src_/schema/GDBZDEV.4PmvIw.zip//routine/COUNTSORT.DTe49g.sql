create FUNCTION         countsort(sReportNo IN VARCHAR2)
RETURN INTEGER IS Counts INTEGER;
BEGIN
  Counts :=0;
  IF Counts = 0 THEN
      SELECT COUNT(1) INTO Counts FROM icr_rpt_t10 WHERE rptno = sReportNo;
      END IF;
      IF Counts = 0 THEN
        SELECT COUNT(1) INTO Counts FROM icr_rpt_t11 WHERE rptno = sReportNo;
        END IF;
        IF Counts = 0 THEN
         SELECT COUNT(1) INTO Counts FROM icr_rpt_t12 WHERE rptno= sReportNo;
         END IF;
           RETURN Counts;
           END;

/

