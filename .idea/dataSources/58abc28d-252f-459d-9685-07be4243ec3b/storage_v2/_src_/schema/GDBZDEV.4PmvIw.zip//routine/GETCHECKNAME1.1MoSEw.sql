create FUNCTION "GETCHECKNAME1"(pSerialno varchar,pPhaseno varchar)
--获取资金渠道切换流程操作人名称
return varchar
is userName varchar2(200);
   newTaskNum number(1);
begin
	 select count(1) into newTaskNum from switchchannel_info where serialno=pSerialno;
	 if newTaskNum=0 then
	 		select username into userName
			from flow_task
			where serialno=(select serialno from (select serialno from flow_task
      where  objectno=pSerialno and phaseno=pPhaseno
      order by begintime desc
      ) where rownum=1 );
	 else
	     if pPhaseno='0020' then
           userName :='';
       else
           select username into userName
          from flow_task
          where serialno=(select serialno from (select serialno from flow_task
          where objectno=pSerialno and phaseno='1000'
          order by begintime desc
          ) where rownum=1 );
       end if;
   end if;
   return userName;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

