create function GETPUTOUTTIME(pSerialno in VARCHAR2)
return VARCHAR2
IS sPutoutTime VARCHAR2(30);
BEGIN
   SELECT max(putouttime) INTO sPutoutTime FROM putout_record WHERE objectno = pSerialno;
  return sPutoutTime;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

