create FUNCTION GetOrgStatementAreaName(orgArg in varchar2)
--获取门店所在区域
return varchar
is
       Porgid  varchar2(50) ;
       Porgname varchar2(50);
begin
  select belongorgid into Porgid from org_statement_info where orgid = (select belongorgid from org_statement_info where orgid=orgArg);
	select orgname into Porgname from org_statement_info where orgid = Porgid AND orgid LIKE 'Z%';
  return Porgname;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
END GetOrgStatementAreaName;
/

