create FUNCTION getBelongTeam(pSerialno varchar2)
--获取催收员的所属团队
return varchar2
is
    pAccounttype varchar2(200);
    pCollectionuserid varchar2(200);
    pTeamid  varchar2(200);
    pBelongTeam  varchar2(200);
begin
         select accounttype,collectionuserid into pAccounttype,pCollectionuserid from collection_info where serialno = pSerialno;
         if pAccounttype = '03' then
               select teamid into pTeamid from out_manufacturer where manuid = pCollectionuserid;
         elsif pAccounttype = '04' then
               select teamid into pTeamid from law_manufacturer where manuid = pCollectionuserid;
         else
               select teamid into pTeamid from user_info where userid = pCollectionuserid;
         end if;
         select getItemname('belongteam',uti.belongteam) into pBelongTeam from urge_team_info uti where uti.teamid=pTeamid;
         return pBelongTeam;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

