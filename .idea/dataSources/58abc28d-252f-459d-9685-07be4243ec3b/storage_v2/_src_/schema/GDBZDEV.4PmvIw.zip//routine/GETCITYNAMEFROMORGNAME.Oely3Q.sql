create FUNCTION GetCityNameFromOrgName(pOrgID varchar)
  return varchar is
  pOrgName  varchar(80);
  pCityName varchar(80);
begin
  select OrgName into pOrgName from Org_info where Orgid = pOrgID;
  select case (select 1
             from Org_info
            where OrgType!='4'
              and Orgid = pOrgID)
           when 1 then
            (select substr(pOrgName, 1, instr(pOrgName, '第') - 1) from dual)
           else
            (select nvl(substr(pOrgName,
                               1,
                               (instr(pOrgName,
                                      substr(REGEXP_REPLACE(pOrgName, '[^0-9]'),
                                             1,
                                             1)) - 1)),
                        pOrgName)
               from dual)
         end
    into pCityName
    from dual;

  return pCityName;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end GetCityNameFromOrgName;
/

