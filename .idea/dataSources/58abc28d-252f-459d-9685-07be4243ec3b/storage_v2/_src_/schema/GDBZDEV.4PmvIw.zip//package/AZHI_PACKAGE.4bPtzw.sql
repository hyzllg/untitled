create package azhi_package is
       function azhic();
end azhi_package;

create or replace body azhi_package is
     function azhic()
    is
    begin
        DBMS_OUTPUT.PUT_LINE('开始处理数据：');
    end;
end azhi_package;

declare
begin
   azhi_package.azhic();
end;

/

