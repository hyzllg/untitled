create Function         checkTelsSalesDateLimit ( pCertID IN varchar2 ) RETURN varchar2
IS
     ret varchar2(10);
     ICount number(6);
     IMonthBtw number(10);
     DXSerialNo varchar2(20);
     sMAXPhaseno varchar2(20);
     sOrderDate varchar2(20);
     sEndtime varchar2(20);
BEGIN
     select count(1) into ICount from  flow_task where objectno in (select serialno from RETAIL_SALES_APPLY where creditid =pCertID and instr(serialNo,'DDGD')>0);

     IF ICount=0 THEN
        ret := 'LOVE';
     ELSE
        select months_between(trunc(sysdate),to_date(substr(rs.orderingdate,1,10),'yyyy/MM/dd')) into IMonthBtw
        from RETAIL_SALES_APPLY rs
        where serialno = (
              select serialno
              from (select serialno from RETAIL_SALES_APPLY where creditid=pCertID and instr(serialNo,'DDGD')>0 order by inputtime desc)
              where rownum=1
        );
        IF IMonthBtw<=1 THEN
           select serialno into DXSerialNo from (select serialno from (select serialno from RETAIL_SALES_APPLY where creditid=pCertID and instr(serialNo,'DDGD')>0 order by inputtime desc)  where rownum=1);
           select phaseno into sMAXPhaseno from flow_task where serialno = (select serialno from (select serialno from flow_task where  flowno='TeleSaleFlow' and objectno=DXSerialNo order by begintime desc) where rownum=1);
           IF sMAXPhaseno='6005' THEN
             --预约日期
             select orderdate into sOrderDate from RETAIL_SALES_APPLY where serialno = DXSerialNo ;
             --取消日期
             select substr(endtime,1,10) into sEndtime from flow_task where serialno = (select serialno from (select serialno from flow_task where  flowno='TeleSaleFlow' and objectno=DXSerialNo order by begintime desc) where rownum=1);
             IF sOrderDate>sEndtime THEN
                ret:='LOVE';
             ELSE
                ret:='Betray';
             END IF;
           ELSE
               ret:='Betray';
           END IF;
        ELSE
           ret:='LOVE';
        END IF;
     END IF;
     RETURN ret;
END;

/

