create FUNCTION getappsum(pSerialNO varchar)
return varchar
is pAppSum varchar(80);
begin
select PREAPPROVESUM into pAppSum
from Creditaudittable
 where serialno = pSerialNO;
 return pAppSum;
end;
/

