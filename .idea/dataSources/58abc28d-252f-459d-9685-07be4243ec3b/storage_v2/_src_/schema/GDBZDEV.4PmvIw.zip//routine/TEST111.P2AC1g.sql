create function test111(itemNumber in varchar2) return SYS_REFCURSOR
 is
  return_cursor SYS_REFCURSOR;
begin
   OPEN return_cursor FOR SELECT 'a' FROM dual WHERE 1 = itemNumber;
  RETURN return_cursor;

end test111;

/

