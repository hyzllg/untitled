create FUNCTION GETPAYDATEOFTHISMONTH(pAlserialno in varchar2,pParams in varchar2)
return varchar2 is
sPayDate varchar2(30);
num number;
begin
if pParams='beforetermmonth' then
        select aps.paydate into sPayDate from acct_payment_schedule aps where aps.paydate >= to_char(trunc(sysdate-1, 'mm'), 'yyyy/MM/dd')
        and aps.paydate < to_char(trunc(add_months(sysdate-1, 1), 'mm'), 'yyyy/MM/dd') and aps.paytype='1' and aps.objectno=pAlserialno;

elsif pParams='aftertermmonth' then
        select to_char(months_between(trunc(sysdate,'mm'),
                        trunc(
                                to_date(
                                        to_char(
                                                ADD_MONTHS(TO_DATE((SELECT PAYDATE FROM ACCT_PAYMENT_SCHEDULE WHERE OBJECTNO = al.serialno AND SEQID='1'),'yyyy-mm-dd'), -1)
                                        ,'yyyy/mm/dd')
                                ,'yyyy/mm/dd')
                        ,'mm'))
                ,'9999') into num
        from acct_loan al
        where al.serialno = pAlserialno;
        select
                to_char(
                        to_date(
                                to_char(
                                        ADD_MONTHS(TO_DATE((SELECT PAYDATE FROM ACCT_PAYMENT_SCHEDULE WHERE OBJECTNO = al.serialno AND SEQID='1'),'yyyy-mm-dd'), num-1)
                                ,'yyyy/mm/dd')
                        ,'yyyy/mm/dd')
                ,'yyyy/mm/dd') into sPayDate
        from acct_loan al
        where al.serialno = pAlserialno;

end if;
return sPayDate;
end GETPAYDATEOFTHISMONTH;
/

