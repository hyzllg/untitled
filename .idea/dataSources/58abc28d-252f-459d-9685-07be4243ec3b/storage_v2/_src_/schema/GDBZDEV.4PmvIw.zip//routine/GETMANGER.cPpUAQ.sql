create FUNCTION getmanger(pSerialno varchar2)
return varchar2 is
pSerialno2 varchar2(80);
pUserName  varchar2(80);
begin
select max(serialno) into pSerialno2 from flow_task  where objectno=pSerialno and phaseno = '0010';
select username into pUserName from flow_task where serialno = pSerialno2;
return pUserName;
end;
/

