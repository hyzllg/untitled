create function getyesterdaydealdate(flag in varchar2)
--获得某催收员下昨天下了code命令的案件数目
return varchar2
is data varchar2(10);
begin
  if flag='10' then
   select to_char(trunc(sysdate-1),'yyyy/MM/dd') as aa into data from dual;
  elsif flag='20'then 
     select to_char(trunc(sysdate-1),'yyyy/MM/dd') as aa into data from dual;
  end if;
    return(data);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getyesterdaydealdate;
/

