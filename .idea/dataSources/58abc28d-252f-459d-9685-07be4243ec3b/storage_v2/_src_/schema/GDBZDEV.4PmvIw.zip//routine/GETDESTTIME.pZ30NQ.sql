create function getdesttime(serialnoArg in varchar2)
--获得出险时间
return varchar2
is
  paydate varchar2(20);
begin
  select case when loanstatus in('90','91','92') then 'true' else 'false' end  into paydate from acct_loan where baserialno=serialnoArg ;
  if paydate='true' then
  select min(paydate)
    into paydate
    from acct_payment_schedule
   where baserialno = serialnoArg
     and finishdate=(select finishdate from acct_payment_schedule where baserialno = serialnoArg and paytype='6');
 else
   select ''
    into paydate
    from dual;
 end if;
  return(paydate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getdesttime;
/

