create FUNCTION getSql(i_tableName VARCHAR2) RETURN VARCHAR2 IS
  v_sqlStr VARCHAR2(2000);
BEGIN
  FOR c IN (SELECT *
              FROM user_col_comments t
             WHERE t.table_name = upper(i_tableName)) LOOP

    v_sqlStr := v_sqlStr || c.column_name || ' ' ||
                c.comments || ',';
  END LOOP;
  v_sqlStr := 'select ' || rtrim(v_sqlStr, ',') || ' from ' || i_tableName;
  RETURN v_sqlStr;
END;
/

