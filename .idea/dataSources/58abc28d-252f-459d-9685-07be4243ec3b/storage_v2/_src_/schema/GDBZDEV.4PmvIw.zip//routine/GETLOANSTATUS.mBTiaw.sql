create function GETLOANSTATUS(serialnoArg in varchar2)
return varchar2
is t_loanstatusResult varchar2(200) ;
begin
  select case

           when ba.STATUS = '3033' then
             '审批拒绝'
           when (nvl(ba.STATUS,'0010') <= '1000' or ba.phasetype in ('2000','3000'))  then
            getPhaseName('CreditFlow',nvl(ba.STATUS,'0010'))
           when ba.STATUS = '1100' and ba.putoutflag='1' then
             '保单打印'
           when ba.STATUS = '1100' and ba.putoutflag='4' then
             '已发送至银行,待放款'

           when ba.STATUS = '1100' and ba.putoutflag='5' then
             '放款取消'
           when ba.STATUS = '1100' and ba.putoutflag='6' then
             '保单取消'
        WHEN  ba.putoutflag='10' then
             '银行审批通过'
             WHEN  ba.putoutflag='30' then
             '银行审批拒绝'
             when ba.putoutflag='7' then
             '补传影像'
             when ba.putoutflag='8' then
             '银行放款失败，请联系银行人员'
           else
            getItemName('LoanStatus',al.loanstatus)
         end into t_loanstatusResult
    from business_apply ba, acct_loan al
   where ba.serialno = al.baserialno(+) and ba.serialno=serialnoArg ;
  return t_loanstatusResult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GETLOANSTATUS;
/

