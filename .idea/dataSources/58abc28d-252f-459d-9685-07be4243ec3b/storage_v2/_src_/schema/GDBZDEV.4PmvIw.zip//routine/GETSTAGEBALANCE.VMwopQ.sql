create FUNCTION getstageBalance(pSerialno varchar)
return varchar
is pBalance  number(14,4);
begin
select (nvl(al.normalbalance, 0) + nvl(al.overduebalance, 0)) into pBalance
  from acct_loan al
where serialno = pSerialno;
  return pBalance;
end;
/

