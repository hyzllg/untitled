create function GETLASTFINISHDATE(serialnoArg in varchar2)
--上笔结清日期
return varchar2
is LastFinishDate varchar2(20);
begin
  select max(al.finishdate) into LastFinishDate
    from acct_loan al, business_apply ba
   where ba.customerid = al.customerid
     and al.baserialno !=serialnoArg
     and al.customerid= (select ba1.customerid from business_apply ba1 where ba1.serialno=serialnoArg);
  return LastFinishDate;
end GETLASTFINISHDATE;

/

