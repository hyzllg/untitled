create function GetProvinceFenBu(orgArg in varchar2)
--获取门店所在省分部
 return varchar2 is
  vOrgID varchar2(32);
  vProvinceFenBu varchar2(32);
begin
  select orgid into vOrgID from org_info where orgid=(select belongorgid from org_info where orgid=
  (select belongorgid from org_info where orgid=orgArg));
  select orgname into vProvinceFenBu from org_info where orgid = vOrgID;
  return vProvinceFenBu;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end GetProvinceFenBu;
/

