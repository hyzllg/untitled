create function GetOrgStatementArea(orgArg in varchar2)
--获取门店所在区域
return varchar2
is orgnamevalue  varchar2(200) ;
 orgindex number(10);
 orgArg1 varchar2(200);
begin
  orgArg1:=orgArg;
   <<fst_loop>>
FOR orgindex IN  1..6
LOOP
   select orgid into orgArg1 from org_statement_info where orgid = (select belongorgid from org_statement_info where orgid=orgArg1);
   select orgname into orgnamevalue from org_statement_info where orgid=orgArg1;
   exit fst_loop when orgnamevalue in ('第一战区','第二战区','第三战区','第四战区','第五战区') ;
END LOOP;
  return orgnamevalue;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetOrgStatementArea;
/

