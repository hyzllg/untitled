create function getminutes(serialnoArg in varchar2)
--获得调度室案件天、时、分
return varchar2

is
  count1 number(5);
  time1 varchar2(30);
  dayhourmin varchar2(30);
begin
  select  a.Approvesubmittime1 into time1 from APPROVETASKTIME a where a.serialno=serialnoArg;
  select count(aw.Curdate) into count1 from Acct_Work_Register aw where aw.Workflag in ('2','3') and aw.Areatype='Land' and aw.Curdate<to_char(sysdate,'yyyy/MM/dd') and aw.Curdate>substr(time1,1,10);
  SELECT
   LPAD(trunc(EXTRACT(DAY FROM (sysdate-count1-to_date(time1,'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )),2,'0')
   ||'天'
   || LPAD(trunc(EXTRACT(HOUR FROM (sysdate-count1-to_date(time1,'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )),2,'0')
   ||'时'
   ||  LPAD(trunc(EXTRACT(MINUTE FROM (sysdate-count1-to_date(time1,'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )),2,'0')
   ||'分' into dayhourmin
FROM DUAL;

  return(dayhourmin);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getminutes;
/

