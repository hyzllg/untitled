create FUNCTION ISNOTNULL(pObject VARCHAR2)
return integer
is
------------------------------------------------------
-- 判断传入的对象值object是否为非空，是返回 1 ，否返回 0
-- @author zllin@amarsoft.com
-- @version 3.0 Apr 22,2005
------------------------------------------------------
 v_Result integer;
begin

 if(pObject IS NOT NULL) then
   v_Result := 1;
 else
   v_Result := 0;
 end if;
     return v_Result;
end;


CASE WHEN BD.ActualMaturity >'$CurrentDate' THEN TO_DATE(BD.ActualMaturity,'YYYYY/MM/DD')-TO_DATE('$CurrentDate','YYYYY/MM/DD') ELSE 0 END

CASE WHEN TFL.BusinessStatus IN ('2','3','4') THEN TO_DATE('$CurrentDate','YYYYY/MM/DD')-TO_DATE(BD.ActualMaturity,'YYYYY/MM/DD'))ELSE 0 END

CASE WHEN TFL.TermDays > 0 THEN TFL.TermDays ELSE TO_DATE(BD.ActualMaturity,'YYYYY/MM/DD')-TO_DATE(BD.ActualPutoutDate,'YYYYY/MM/DD') END

/

