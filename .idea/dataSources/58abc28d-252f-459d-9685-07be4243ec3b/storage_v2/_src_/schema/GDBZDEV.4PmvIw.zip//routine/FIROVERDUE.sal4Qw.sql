create function firoverdue(serialnoArg in varchar2)
--获得首次逾期日期
return varchar2
is
  paydate varchar2(20);
begin
  select case when loanstatus in('90','91','92') then 'true' else 'false' end  into paydate from acct_loan where baserialno=serialnoArg ;
  if paydate='true' then
  select min(paydate)
    into paydate
    from acct_payment_schedule
   where
    to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate)
    and nvl(finishdate,'2999/12/31')>paydate
    and baserialno = serialnoArg;
 else
   select min(paydate)
    into paydate
    from acct_payment_schedule
   where
     to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate)
     and (finishdate is null or finishdate >paydate)
     and baserialno = serialnoArg;
 end if;
  return(paydate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end firoverdue;

/

