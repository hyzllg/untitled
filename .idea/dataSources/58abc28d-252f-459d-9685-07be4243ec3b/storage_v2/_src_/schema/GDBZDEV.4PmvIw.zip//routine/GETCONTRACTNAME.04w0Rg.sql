create FUNCTION getcontractname(pSerialNo varchar)
return varchar
is pContractName  varchar(40);
begin
select ArtificialNo into pContractName
from BUSINESS_CONTRACT
where SerialNo=pSerialNo;
return pContractName;
end;

/

