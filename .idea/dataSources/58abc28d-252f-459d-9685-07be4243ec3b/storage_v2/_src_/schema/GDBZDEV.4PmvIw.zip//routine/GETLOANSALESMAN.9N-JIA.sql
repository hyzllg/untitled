create FUNCTION getLoanSalesMan(sSerialno varchar)
--获取放款业务人员
return varchar
IS
loansale varchar(50);
status varchar(10);
WorkStatus varchar(10);
loansalesman varchar(100);
channelname varchar(50);
BEGIN
     SELECT ba.channelname INTO channelname FROM business_apply ba WHERE ba.serialno = sSerialno;
     SELECT ba.SalesUserID||'  '||ba.SalesUserName INTO loansale FROM business_apply ba WHERE ba.serialno = sSerialno ;
     IF channelname = '电销' then
        SELECT loansale||'  '||'电销' INTO loansalesman FROM dual;
     ELSE
        SELECT ui.status INTO status FROM business_apply ba,User_Info ui WHERE ba.salesuserid = ui.userid AND ba.serialno = sSerialno ;
        SELECT itemname INTO WorkStatus FROM Code_Library WHERE codeno = 'WorkStatus' AND itemno = status;
        SELECT loansale||'  '||WorkStatus INTO loansalesman FROM dual;
    END IF;
     return loansalesman;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getLoanSalesMan;
/

