create Function         checkLoanPlusRule1 ( pCertID IN varchar2 ) RETURN varchar2
IS
     ret varchar2(10);
     ICount number(6);
     IMonthBtw number(10);
     DXSerialNo varchar2(20);
     sMAXPhaseno varchar2(20);
     sOrderDate varchar2(20);
     sEndtime varchar2(20);
BEGIN
     select count(1) into ICount
     from acct_loan al,customer_info ci,business_type bt,acct_payment_schedule aps,business_apply ba
     where al.CUSTOMERID=ci.customerid
       and al.businesstype=bt.typeno
       and aps.objectno=al.serialno
       and al.baserialno=ba.serialno

     --1.当前在我司有且仅有一笔正在还款状态的无抵押贷款且为16年10月21日以后申请
     and  (
          select count(1)
          from acct_loan ali
          WHERE al.customerid=ali.customerid AND al.finishdate IS NULL
     ) = 1
     and instr(bt.TYPENAME,'房时贷')<>1
     and al.Putoutdate> '2016/10/21'
     and ci.certid=pCertID;

     IF ICount=0 THEN
        ret := 'Betray';
     ELSE
        ret := 'LOVE';
     END IF;
     RETURN ret;
END;

/

