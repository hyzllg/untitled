create FUNCTION getmobleno(pCodeNo VARCHAR)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  SELECT ci.mobiletelephone  into pItemName
  from ind_info ci, acct_loan al
  WHERE ci.customerid=al.customerid AND al.serialno=pCodeNo;
  if pItemName is null then
            return pItemName;
  else
            return pItemName;
  end if;
end;
/

