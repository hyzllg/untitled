create FUNCTION gethighorgid(pOrgid varchar2)
return varchar2
is pBelongorgid varchar2(10);
begin
select belongorgid into pBelongorgid from org_info where orgid=pOrgid;
return pBelongorgid;
end;
/

