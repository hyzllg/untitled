create function GetRecognizeeName(recognizeeArg in varchar2)
return varchar2
is recognizeeNameValue varchar2(200) ;
begin
 select recognizeename
   into recognizeeNameValue
   from recognizee_person
  where recognizeeid = recognizeeArg;
  return recognizeeNameValue;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetRecognizeeName;

/

