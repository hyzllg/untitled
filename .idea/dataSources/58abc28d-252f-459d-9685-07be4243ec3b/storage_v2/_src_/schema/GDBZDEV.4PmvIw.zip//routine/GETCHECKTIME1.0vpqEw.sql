create function getchecktime1(serialnoArg in varchar2)
--录单结束时间 提交复核时间
 return varchar2
is tiemback varchar2(100);
begin
select substr(begintime,1,10) into tiemback --2018/03/26 09:40:53
 from flow_task where serialno=serialnoArg;
  return tiemback;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getchecktime1;
/

