create FUNCTION f_testx(a IN VARCHAR2, b OUT VARCHAR2, c OUT VARCHAR2 ) RETURN VARCHAR2
IS
BEGIN
  b := a||'b';
  c := a||'c';
  RETURN 'd';
END;

/

