create view VW_RENEWLOAN_FALLOFFRULES_LIST as
select
serialno     ,
flag         ,
baserialno   ,
alserialno   ,
customerid   ,
businesstype ,
loanterm     ,
businesssum  ,
finishdate   ,
putoutdate   ,
reason       ,
customerbflag,
inputtime    ,
batchno
from GDBZDEV.renewloan_falloffrules_list
/

