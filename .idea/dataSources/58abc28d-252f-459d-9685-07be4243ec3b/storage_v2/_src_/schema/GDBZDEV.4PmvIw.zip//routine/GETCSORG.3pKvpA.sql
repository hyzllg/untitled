create FUNCTION getcsorg(pSerialno varchar)
return varchar
is pOrgName varchar2(80);
begin
  select getorgname(csmanageorgid) into pOrgName
    from business_apply where serialno = pSerialno;
 return pOrgName;
end;
/

