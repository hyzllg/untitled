create function getExchangeRate(sCurrencyFrom varchar2,
                                           sCurrencyTo   varchar2)
  return number
-------------------------------
  --????
  --modefied by zllin at 2004-12-24
  -------------------------------
 is
  nValueFrom number(24, 6);
  nValueTo   number(24, 6);
begin
  if sCurrencyFrom = sCurrencyTo then
    return 1;
  end if;
  begin
    select ExchangeValue
      into nValueFrom
      from ERATE_INFO
     where CurrencyType = sCurrencyFrom;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      nValueFrom := 1;
  END;
  begin
    select ExchangeValue
      into nValueTo
      from ERATE_INFO
     where CurrencyType = sCurrencyTo;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      nValueTo := 1;
  END;
  return nValueFrom / nValueTo;
end;

/

