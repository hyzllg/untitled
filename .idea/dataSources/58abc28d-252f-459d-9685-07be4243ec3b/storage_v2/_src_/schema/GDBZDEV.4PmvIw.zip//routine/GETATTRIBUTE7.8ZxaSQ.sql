create FUNCTION getattribute7(pCodeNo varchar,pItemNo varchar)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  select case when attribute7 is not null then attribute7 else itemno end into pItemName
  from Code_Library
  where CodeNo=pCodeNo and ItemNo=pItemNo;
  if pItemName is null then
            return pItemName;
  else
            return pItemName;
  end if;
end;
/

