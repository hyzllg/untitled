create FUNCTION geterate(pCurrency1 varchar,pCurrency2 varchar,pDate varchar)
return Number
is iRate1 Number;
iRate2 Number;
iRate3 Number;
begin
if pCurrency1='01' OR pCurrency1=pCurrency2 then
    return 1.000000;
    else
    if pDate is not null and pDate <> '' then
    select nvl(price,1) into iRate1
    from erate_info
    where currency = pCurrency1
    and  Efficientdate = pDate;

    select nvl(price,1) into iRate2
    from erate_info
    where currency = pCurrency2
    and  Efficientdate = pDate;
    else
select nvl(price,1) into iRate1
    from erate_info
    where currency = pCurrency1
    and  Efficientdate =(select max(Efficientdate ) from ERATE_INFO );

    select nvl(price,1) into iRate2
    from erate_info
    where currency = pCurrency2
    and  Efficientdate =(select max(Efficientdate ) from ERATE_INFO );
end if;
iRate3 := iRate1/iRate2;

    return iRate3;
end if;
end;

/

