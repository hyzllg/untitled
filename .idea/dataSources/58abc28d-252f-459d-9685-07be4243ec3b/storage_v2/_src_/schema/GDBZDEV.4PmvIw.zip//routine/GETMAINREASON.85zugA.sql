create function getMainReason(pSerialno in VARCHAR2)
--获得拒绝主原因
return VARCHAR2
IS sSerialno VARCHAR2(50);
   sPhaseno  VARCHAR2(50);
   sMainReasonCode  VARCHAR2(50);
   sSubreasoncode  VARCHAR2(50);
   MainReason  VARCHAR2(100);
BEGIN
  SELECT serialno INTO sSerialno FROM (SELECT serialno  FROM flow_task WHERE objecttype = 'CreditApply' AND objectno = pSerialno order by begintime desc) where rownum ='1';
  SELECT ft.phaseno INTO sPhaseno FROM flow_task ft WHERE ft.objecttype = 'CreditApply' AND ft.serialno = sSerialno;
  IF sPhaseno IN ('2040','3020','3021','3091','3092','3090','3098') THEN
		 SELECT ba.APPROVEREFUSEREASON INTO MainReason FROM business_apply ba WHERE ba.serialno = pSerialno;
	elsif sPhaseno = '3093' THEN
	   SELECT DISTINCT primarycause,secondarycause INTO sMainReasonCode,sSubreasoncode FROM STRATEGYRESULT WHERE objecttype = 'CreditApply' AND objectno = pSerialno AND  strategyresult = '3';
	   SELECT mainreason INTO MainReason FROM reason_param WHERE mainreasoncode = sMainReasonCode AND phaseno = '0030' AND subreasoncode = sSubreasoncode;
	ELSE
			SELECT '' INTO MainReason FROM dual;
	END IF;
	return MainReason;
	EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getMainReason;
/

