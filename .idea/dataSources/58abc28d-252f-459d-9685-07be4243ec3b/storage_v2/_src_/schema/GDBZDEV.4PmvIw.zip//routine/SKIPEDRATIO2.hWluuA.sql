create function SkipedRatio2(serialnoArg in varchar2)
  --终审审跳转组长比率
return varchar2

is

  a varchar2(10);
  b varchar2(30);
  sRatio varchar2(30);
  num number(2);
begin
  select ba.flag5 into a from business_apply ba where ba.serialno=serialnoArg;
  select phasechoice into b from flow_opinion where serialno = (select max(serialno)
                       from flow_opinion
                      where objectno = serialnoArg
                        and phaseno in ('0040','0045') and phasechoice is not null and objecttype='CreditApply');
  if a='QZSQ' then select '' into sRatio from dual;
  else
    select count(1) into num from ratio_special where userid=(select userid from flow_task where serialno =(select max(serialno) from flow_task where phaseno in ('0040','0045') and objectno = serialnoArg and flowno='CreditFlow' and userid<>'OPS'));
    --特殊
    if num>0 then

        if b='终审通过' then
            --通过跳转比率
            select userpassratio||'%' into sRatio from ratio_special where userid=(select userid from flow_task where serialno =(select max(serialno) from flow_task where phaseno in ('0040','0045') and objectno = serialnoArg and flowno='CreditFlow' and userid<>'OPS'));
        elsif b='终审未通过' then
            --未通过跳转比率
            select userrefuseratio||'%' into sRatio from ratio_special where userid=(select userid from flow_task where serialno =(select max(serialno) from flow_task where phaseno in ('0040','0045') and objectno = serialnoArg and flowno='CreditFlow' and userid<>'OPS'));
        else
            select '' into sRatio from dual;
        end if;
    --常规
    else
       if b='终审通过' then
            --通过跳转比率
            select ratio3||'%' into sRatio from ratio_common;
        elsif b='终审未通过' then
            --未通过跳转比率
            select ratio4||'%' into sRatio from ratio_common;
        else
            select '' into sRatio from dual;
        end if;
    end if;
   end if;
 return(sRatio);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end SkipedRatio2;

/

