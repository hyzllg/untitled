create FUNCTION GETGREENCHANNELDCOUNT(pOrgID in varchar2)
return number
is sCount1 number(10);
begin
select count(1) into sCount1 from approvetasktime att where att.serialno in (select ba.serialno  from business_apply ba where ba.inputorgid = pOrgID and ba.isgreen='1' and ba.channelcode<>'partner001') and att.approvesubmittime1>=(to_char(sysdate,'yyyy/mm/dd')||' 00'||':'||'00'||':'||'00')
 and att.approvesubmittime1<=(to_char(sysdate,'yyyy/mm/dd')||' 23'||':'||'59'||':'||'59') ;
return sCount1;
end getgreenchanneldcount;
/

