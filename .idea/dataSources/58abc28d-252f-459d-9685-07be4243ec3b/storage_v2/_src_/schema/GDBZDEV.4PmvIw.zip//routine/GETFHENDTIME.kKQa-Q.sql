create function getFHendtime(objectArg varchar2)
---获取复核结束时间
return varchar2
is
   ApprovalTime varchar2(20);
begin
  select endtime into ApprovalTime
    from flow_task where serialno=(
    select serialno from (select serialno from flow_task
   where objectno = objectArg
     and phaseno = '0020' and flowno='CreditFlow' order by begintime desc) where rownum=1);

  return(ApprovalTime);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getFHendtime;
/

