create function leaderid(serialnoArg in varchar2)
--组长姓名ID
return varchar2
is
  userid varchar2(20);
begin
  select distinct belonguserid into userid
    from approve_users
   where userid = (select userid
                     from flow_task
                    where serialno = (select max(serialno)
                                        from flow_task
                                       where phaseno in ('0040', '0045')
                                         and objectno = serialnoArg
                                         and flowno = 'CreditFlow'
                                         and userid <> 'OPS'));

  return(userid);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end leaderid;

/

