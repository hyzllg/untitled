create FUNCTION GETBASERIALNO(pnewapprovebaserialno varchar)
return varchar
is  pserialno  varchar(200);
begin
  pserialno:='';
  select serialno  into pserialno
  from business_apply
  where newapprovebaserialno =pnewapprovebaserialno;
  return pserialno;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return pnewapprovebaserialno;
  WHEN OTHERS THEN
  return pnewapprovebaserialno;
end;
/

