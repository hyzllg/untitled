create FUNCTION "GETSERIALNO" (pTable VARCHAR2,pField VARCHAR2,pPreSerialNo VARCHAR2,pBit INTEGER)
RETURN VARCHAR2
--功能描述：返回新生成的顺序号
--入口参数：pTable        顺序号所在表
--         pField        顺序号所在字段
--         pPreSerialNo  顺序号前缀
--         pBit          顺序号后缀流水位数
IS
    vSerialNo VARCHAR(40);
    vSql             VARCHAR(2000);
    vMaxNo         INTEGER;
    iPostNo     INTEGER;
    TYPE cur_type IS REF CURSOR;
    curMax cur_type;
    BEGIN
        vSql := 'SELECT NVL(MAX(TO_NUMBER(SUBSTR(' || pField || ',LENGTH(' ||pPreSerialNo || ')+1))),0) FROM ' || pTable || ' WHERE ' || pField || ' LIKE '''  || pPreSerialNo || '%''';
        OPEN curMax FOR vSql;
        FETCH curMax INTO vMaxNo;
        CLOSE curMax;
        IF vMaxNo = 0 THEN
            vSerialNo := pPreSerialNo || LPAD('1',pBit,'0');
        ELSE
            iPostNo := vMaxNo + 1;
            vSerialNo := pPreSerialNo || LPAD(TO_CHAR(iPostNo),pBit,'0');
        END IF;
    RETURN vSerialNo;
END;

/

