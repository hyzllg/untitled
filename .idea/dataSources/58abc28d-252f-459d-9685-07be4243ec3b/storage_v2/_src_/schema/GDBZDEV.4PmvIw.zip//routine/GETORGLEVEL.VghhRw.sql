create FUNCTION getOrglevel(sUserID varchar)
--获取某一用户所属机构的等级
return varchar2
is
sOrglevel      varchar2(10);
begin
  select oi.orglevel into sOrglevel from org_info oi where oi.orgid=(select ui.belongorg from user_info ui where userid=sUserID);
  return sOrglevel;
end;
/

