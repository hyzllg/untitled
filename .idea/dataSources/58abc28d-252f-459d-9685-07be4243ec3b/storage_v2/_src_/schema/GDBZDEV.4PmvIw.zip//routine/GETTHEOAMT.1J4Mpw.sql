create FUNCTION GETTHEOAMT(pObjectno varchar)
return varchar2
is pIncome varchar(30);
begin
select distinct LAST_VALUE(COUNTBUSINESSSUM) OVER(PARTITION BY objectno ORDER BY serialno rows between unbounded preceding and unbounded following )
into pIncome  from flow_opinion
where phaseno in('0030','0035','0045','0040','0047') and objectno= pObjectno ;
return pIncome;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

