create FUNCTION getModelame(pModelNo varchar)
return varchar
is pModelName varchar(200);
begin
select ModelName into pModelName
 from EVALUATE_CATALOG
 where ModelNo=pModelNo;
if pModelName is null then
  pModelName := pModelNo;
end if;
return pModelName;
end;

/

