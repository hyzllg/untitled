create package relative_auto_reject is
  /*
  * 申请阶段自动审批处理
  */
  procedure relative_apply_auto_reject(pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2);
end relative_auto_reject;
/

