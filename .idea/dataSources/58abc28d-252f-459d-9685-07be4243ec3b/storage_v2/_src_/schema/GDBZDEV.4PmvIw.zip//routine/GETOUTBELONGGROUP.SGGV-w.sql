create FUNCTION getOutBelongGroup(pCustomeruserid varchar2)
--获取委外组别
return varchar2
is
pTeamid  varchar2(200);
pBelongGroup  varchar2(200);
begin
  select teamid into pTeamid from out_manufacturer where manuid = pCustomeruserid;
  select TEAMNAME into pBelongGroup from urge_team_info where teamid=pTeamid;
  return pBelongGroup;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

