create PACKAGE         dw_util_pkg IS

  c_log_infor   CONSTANT VARCHAR2(30) := '消息';
  c_log_warning CONSTANT VARCHAR2(30) := '警告';
  c_log_error   CONSTANT VARCHAR2(30) := '错误';

  PROCEDURE log(p_message_type         VARCHAR2,
                p_message              VARCHAR2,
                p_plan_node_control_id NUMBER DEFAULT -1,
                p_procedure_name       VARCHAR2 DEFAULT '');
  PROCEDURE log_infor(p_message              VARCHAR2,
                      p_plan_node_control_id NUMBER DEFAULT -1,
                      p_procedure_name       VARCHAR2 DEFAULT '');
  PROCEDURE log_warning(p_message              VARCHAR2,
                        p_plan_node_control_id NUMBER DEFAULT -1,
                        p_procedure_name       VARCHAR2 DEFAULT '');
  PROCEDURE log_error(p_message              VARCHAR2,
                      p_plan_node_control_id NUMBER DEFAULT -1,
                      p_procedure_name       VARCHAR2 DEFAULT '');

  FUNCTION executing_time(p_execute_begining_date DATE) RETURN NUMBER;

  PROCEDURE enable_session_parallel(p_level NUMBER DEFAULT 64);
  PROCEDURE disable_session_parallel;

  PROCEDURE gather_stats(p_owner     VARCHAR2,
                         p_table     VARCHAR2 DEFAULT NULL,
                         p_partition VARCHAR2 DEFAULT NULL);

  PROCEDURE add_partition(p_owner                 VARCHAR2,
                          p_table                 VARCHAR2,
                          p_partition_name        VARCHAR2,
                          p_partition_value       VARCHAR2,
                          p_subpartition_name     VARCHAR2 DEFAULT NULL,
                          p_subpartition_value    VARCHAR2 DEFAULT NULL,
                          p_gen_subpartition_name BOOLEAN DEFAULT TRUE);
  PROCEDURE drop_partition(p_owner             VARCHAR2,
                           p_table             VARCHAR2,
                           p_partition_name    VARCHAR2,
                           p_subpartition_name VARCHAR2 DEFAULT NULL);
  PROCEDURE exchange_partition(p_owner           VARCHAR2,
                               p_table           VARCHAR2,
                               p_partition_name  VARCHAR2,
                               p_partition_value VARCHAR2,
                               p_target_owner    VARCHAR2,
                               p_target_table    VARCHAR2);

  PROCEDURE truncate_table(p_owner             VARCHAR2,
                           p_table             VARCHAR2,
                           p_partition_name    VARCHAR2 DEFAULT NULL,
                           p_subpartition_name VARCHAR2 DEFAULT NULL);

  PROCEDURE disable_index(p_owner VARCHAR2, p_table VARCHAR2, p_partition VARCHAR2 DEFAULT NULL);

  PROCEDURE rebuild_unusable_index(p_owner VARCHAR2, p_table VARCHAR2, p_partition VARCHAR2);
  PROCEDURE rebuild_index(p_owner VARCHAR2, p_table VARCHAR2, p_partition VARCHAR2 DEFAULT NULL);

  -- submit_job
  PROCEDURE submit_job(p_job_name VARCHAR2, p_statement VARCHAR2, p_date DATE DEFAULT SYSDATE);

  PROCEDURE get_parallel_chunks(p_task_name   VARCHAR2,
                                p_start_id    NUMBER,
                                p_end_id      NUMBER,
                                x_start_value OUT VARCHAR2,
                                x_end_value   OUT VARCHAR2);
  -- parallel_execute
  PROCEDURE parallel_execute(p_task_name      VARCHAR2,
                             p_chunks_sql     VARCHAR2,
                             p_execute_sql    VARCHAR2,
                             p_parallel_level NUMBER DEFAULT 32);

  PROCEDURE cache_tables(p_owner           VARCHAR2,
                         p_table_name      VARCHAR2,
                         p_enable          BOOLEAN DEFAULT TRUE,
                         p_include_indexes BOOLEAN DEFAULT TRUE);

  PROCEDURE log_calc(p_log_message VARCHAR2,
                     p_index_id    NUMBER DEFAULT NULL,
                     p_line_number NUMBER DEFAULT NULL);


  --获取英文月份对应数字月份MM格式
  FUNCTION get_month_from_en(p_month_name_en IN VARCHAR2) RETURN VARCHAR2;


END dw_util_pkg;

/

