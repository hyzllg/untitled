create FUNCTION GETISENDSP(pSerialno varchar2)
--是否审批结束
    return varchar2
    is pIsEndSP  varchar2(10);
    begin
    select count(1) into pIsEndSP
      from flow_task
   where objectno = pSerialno and phaseno='0070';
  return pIsEndSP;
end;
/

