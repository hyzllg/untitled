create view VW_RENEWLOAN_LIST as
select
serialno        ,
baserialno      ,
alserialno      ,
customerid      ,
mediasource     ,
customername    ,
certid          ,
branchname      ,
mobilephone     ,
businesstype    ,
businesstypename,
loanterm        ,
sterm           ,
businesssum     ,
signtime        ,
signorgid       ,
policyrate      ,
finishdate      ,
putoutdate      ,
customertype    ,
presum          ,
prepolicyrate   ,
inputtime       ,
batchno
from GDBZDEV.renewloan_list
/

