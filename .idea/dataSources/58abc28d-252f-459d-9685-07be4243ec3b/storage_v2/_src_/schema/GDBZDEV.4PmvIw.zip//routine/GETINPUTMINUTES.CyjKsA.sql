create function getinputminutes(inputtime in varchar2)
return number
is
  dayhourmin varchar2(100);
begin
  select round((sysdate-to_date(inputtime,'yyyy/MM/dd HH24:mi:ss'))*24*60) into dayhourmin
FROM DUAL;

  return dayhourmin;
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end getinputminutes;
/

