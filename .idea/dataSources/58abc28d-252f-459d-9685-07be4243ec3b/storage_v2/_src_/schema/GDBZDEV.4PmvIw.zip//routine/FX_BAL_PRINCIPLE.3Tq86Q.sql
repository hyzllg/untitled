create procedure FX_bal_principle as
   begin
   Insert into bal_prin(APPLYNO ,CONTRACTSERIALNO,POLICYNO,CUSTOMERNAME ,BUSINESSTYPE,normalbalance,overduebalance,BALANCE,PUTOUTDATE,overduedays,ADVSETTLEDATE,SETTLEAMT_ACT,SETTLEDATE,RECOVERYAMT,UPDATED_DATE)
   select t1.*,t2.ADVSETTLEDATE,t3.SETTLEAMT_ACT,t3.SETTLEDATE,t4.RECOVERYAMT,
 to_char(sysdate,'yyyy/mm/dd') as UPDATED_DATE  from
 (select a.SERIALNO as  APPLYNO  ,a.CONTRACTSERIALNO ,a.policyno,a.customername,substr(GetBusinessName(a.BusinessType),1,3) as BUSINESSTYPE,
 b.normalbalance ,b.overduebalance ,b.normalbalance+b.overduebalance as BALANCE ,b.PUTOUTDATE ,
 b.overduedays from business_apply a,acct_loan b where a.serialno=b.BASERIALNO(+) and a.CONTRACTSERIALNO is not null) t1
 left join  (select policyno,plandate as ADVSETTLEDATE  from  prpjp where certitype='E') t2 on t1.policyno=t2.policyno
 left join (select policyno,sum(planfee) as SETTLEAMT_ACT ,min(plandate) as SETTLEDATE  from  prpjp where certitype='C'
 group by policyno ) t3  on t1.policyno=t3.policyno
 left join (select  CONTRACTSERIALNO , actualcredere   as	RECOVERYAMT   from  ACCT_RECOVERY_LOSS) t4
 on t1.CONTRACTSERIALNO=t4.CONTRACTSERIALNO;
   end;


/

