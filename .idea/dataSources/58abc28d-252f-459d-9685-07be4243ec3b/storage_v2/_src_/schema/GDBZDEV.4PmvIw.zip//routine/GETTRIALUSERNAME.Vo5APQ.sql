create function GetTrialUserName(serialnoArg in varchar2)
--获取初审姓名
return varchar2
is TrialUserName  varchar2(200) ;
  sPhaseNo varchar2(20);
begin
   select phaseno,username into sPhaseNo,TrialUserName from flow_object where flowno='CreditFlow' and objectno = serialnoArg ;
   if sPhaseNo='0030' then 
     return TrialUserName;
   else 
   select username into TrialUserName
     from flow_task
    where phaseno in ('0030','0035') and flowno='CreditFlow'
      and serialno =
          (select max(serialno)
             from flow_task where phaseno in ('0030','0035') and objectno = serialnoArg and flowno='CreditFlow' and userid<>'OPS');
    end if;
  return TrialUserName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetTrialUserName;
/

