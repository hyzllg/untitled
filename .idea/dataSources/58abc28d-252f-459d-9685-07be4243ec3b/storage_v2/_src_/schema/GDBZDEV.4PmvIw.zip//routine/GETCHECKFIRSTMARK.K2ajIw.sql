create function getCheckFirstMark(serialnoArg in varchar2)
--审批备注
return varchar2
is backremark varchar2(300);
begin
select phaseopinion3 into backremark
 from flow_opinion where OPINIONNO=(
 select OPINIONNO from (
     select OPINIONNO
     from flow_opinion
     where objectno = serialnoArg 
   and phasechoice in( '初审未通过','初审通过','组长通过','终审通过') order by updatetime desc)
   where rownum=1 );
  return backremark;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getCheckFirstMark;
/

