create FUNCTION getOrgBelongTeam(pCustomeruserid varchar2)
--获取委外催收员的所属团队
return varchar2
is  pTeamid  varchar2(200);
    pBelongTeam  varchar2(200);
begin
         select teamid into pTeamid from user_info where userid = pCustomeruserid;
         select getItemname('belongteam',uti.belongteam) into pBelongTeam from urge_team_info uti where uti.teamid=pTeamid;
  return pBelongTeam;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

