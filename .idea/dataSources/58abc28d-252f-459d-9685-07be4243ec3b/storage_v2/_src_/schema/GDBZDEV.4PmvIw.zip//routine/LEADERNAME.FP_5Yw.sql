create function leadername(serialnoArg in varchar2)
--组长姓名
return varchar2
is
  username varchar2(20);
begin
  select distinct getusername(belonguserid) into username
    from approve_users
   where userid = (select userid
                     from flow_task
                    where serialno = (select max(serialno)
                                        from flow_task
                                       where phaseno in ('0040', '0045')
                                         and objectno = serialnoArg
                                         and flowno = 'CreditFlow'
                                         and userid <> 'OPS'));

  return(username);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end leadername;

/

