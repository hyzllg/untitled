create FUNCTION getattribute1(pCodeNo varchar,pItemNo varchar)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  select attribute1 into pItemName
  from Code_Library
  where CodeNo=pCodeNo and ItemNo=pItemNo;
  if pItemName is null then
            return pItemName;
  else
            return pItemName;
  end if;
end;

/

