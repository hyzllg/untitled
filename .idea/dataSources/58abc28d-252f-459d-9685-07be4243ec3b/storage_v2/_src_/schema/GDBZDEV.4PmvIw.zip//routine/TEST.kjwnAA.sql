create function Test(pCertId IN varchar2)
return varchar2 is
  reasonparm varchar2(500) ;
begin
  relative_auto_reject.relative_apply_auto_reject(pCertId,reasonparm);
  return reasonparm;
end Test;
/

