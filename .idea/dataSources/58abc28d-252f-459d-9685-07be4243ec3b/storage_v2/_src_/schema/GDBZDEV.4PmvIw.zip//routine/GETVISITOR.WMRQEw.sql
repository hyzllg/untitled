create function getvisitor(pi_object_no    in varchar2,
                                      pi_visitor_type in varchar2, -- 回访人员类型 junior-初席 senior-高席
                                      pi_return_type  in varchar2) -- 返回类型 id-回访人员编号 name-回访人员姓名
 return varchar2 is
  Result varchar2(32);
  v_user_id   flow_task.userid%type;
  v_user_name flow_task.username%type;
begin
  begin
    if pi_visitor_type = 'junior' then
      select *
        into v_user_id, v_user_name
        from (select t.userid, t.username
                from flow_task t
               where t.flowno = 'VisitFlow'
                 and t.phaseno in ('0001',
                                   '0002',
                                   '0003',
                                   '0004',
                                   '0005',
                                   '0006',
                                   '0007',
                                   '0008')
                 and t.userid <> 'OPS'
                 and t.objectno = pi_object_no
               order by t.phaseno desc)
       where rownum = 1;
    else
      select *
        into v_user_id, v_user_name
        from (select t.userid, t.username
                from flow_task t
               where t.flowno = 'VisitFlow'
                 and t.phaseno in ('0009',
                                   '0010',
                                   '0011',
                                   '0012',
                                   '0013',
                                   '0014',
                                   '0015',
                                   '0002')
                 and t.objectno = pi_object_no
               order by t.phaseno desc)
       where rownum = 1;
    end if;

    if pi_return_type = 'id' then
      Result := v_user_id;
    else
      Result := v_user_name;
    end if;
  exception
    when no_data_found then
      v_user_id   := null;
      v_user_name := null;
  end;

  return(Result);
end getvisitor;

/

