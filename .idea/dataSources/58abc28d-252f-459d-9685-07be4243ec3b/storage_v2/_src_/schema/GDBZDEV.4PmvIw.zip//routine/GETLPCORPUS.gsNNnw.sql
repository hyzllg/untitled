create FUNCTION getLPCorpus( payserialno IN VARCHAR2)
return number is
  amt2 number;
begin
   select nvl(sum(nvl(actualpaycorpusamt,0)),0) into amt2
    from acct_back_detail
   where psserialno = payserialno
     and paytype = '6';
  return(amt2);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end getLPCorpus;

/

