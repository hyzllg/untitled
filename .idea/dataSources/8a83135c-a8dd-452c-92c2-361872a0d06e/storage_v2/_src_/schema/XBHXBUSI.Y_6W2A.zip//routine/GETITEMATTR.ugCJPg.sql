create FUNCTION getItemAttr(pCodeNo in varchar,pItemNo in varchar2)
RETURN varchar2
as sReturn varchar2(80);
begin
select coalesce(rtrim(ltrim(itemattribute)),'') into sReturn from code_library Where CodeNo = pCodeNo and ItemNo = pItemNo;
return  sReturn;
end;

/

