create FUNCTION GETPHASENAME
(
  PFLOWNO IN VARCHAR2
, PPHASENO IN VARCHAR2
, PVERSION IN VARCHAR2
) RETURN VARCHAR2 AS
sReturn varchar2(100);
begin
select PhaseName into sReturn from flow_model where FlowNo = pFlowNo and PhaseNo = pPhaseNo  and Version=pVersion;
return sReturn;
end GETPHASENAME;

/

