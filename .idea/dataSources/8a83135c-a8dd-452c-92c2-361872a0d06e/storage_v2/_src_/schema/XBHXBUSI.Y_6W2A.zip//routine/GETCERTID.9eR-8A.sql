create FUNCTION getCertID
(
  pDefault in VARCHAR2
) RETURN VARCHAR2
AS
sReturn  varchar2(40);
begin
return substr(pDefault,0,5)||'****'||substr(pDefault,15,18);
end getCertID;

/

