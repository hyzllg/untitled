create FUNCTION GETCUSTOMERNAME
(
  PCUSTOMERID IN VARCHAR2
) RETURN VARCHAR2 AS
sCustomerName varchar2(100);
BEGIN
  select CustomerName into sCustomerName from customer_info where customerid = pCustomerID;
  RETURN sCustomerName;
END GETCUSTOMERNAME;

/

