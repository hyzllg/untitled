create view COMMISSION_SETTLEMENT_REPORT as
select
    O.OBJECTNO,
    bc.CONTRACTARTIFICIALNO,
    O.OBJECTTYPE,
    bc.POLICYNO,
    O.CHANNELREPAYSNO,
    O.SERIALNO,
    O.TRANSENDTIME,
    bc.DDPRODUCTID as DDPRODUCTID1,
    pci.productName,
    O.PAYASSUREFEE,
    O.COMMISSIONTATE,
    nvl(COMMISSIONTATE,0)/100*nvl(PAYASSUREFEE,0) as COMMISSION,
    O.APPLYSERIALNO,
    bc.DDPRODUCTID as DDPRODUCTID2,
    bc.DDPRODUCTID as DDPRODUCTID3,
    O.BATCHNO,
    O.BATCHTYPE,
    DECODE(O.BATCHNO,'05','已理赔','99','已理赔','未理赔') as BATCHNOS,
    pa.ORGID as ORGID
from LOAN_BATCH_INFO O, BUSINESS_CONTRACT bc, PRODUCT_CONFIG_INFO pci,putout_approve pa
where O.objecttype = 'jbo.acct.ACCT_LOAN'
   and o.objectNo = bc.serialno
   and (O.TRANSSTATUS like '9%' or O.TRANSSTATUS like '50')
   and bc.ddproductid = pci.productid
   and bc.ddproductid in (select cl.itemattribute from CODE_LIBRARY cl where CODENO='AgentSubCommission')
   and bc.policyno = pa.policyno
   and bc.create_time > decode(bc.ddproductid, '7014',to_date('2021/05/28 20:00:00','yyyy/mm/dd hh24:mi:ss'),to_date('2018/02/22','yyyy/mm/dd'))
/

