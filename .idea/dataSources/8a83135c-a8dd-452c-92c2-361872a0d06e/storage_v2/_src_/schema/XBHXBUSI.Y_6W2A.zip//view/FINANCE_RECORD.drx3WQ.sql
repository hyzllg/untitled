create view FINANCE_RECORD as
SELECT
    cf . reportperiod as REPORTPERIOD,
    cf . auditopinion as ATTRIBUTE1,
    cf . auditflag as ATTRIBUTE2,
    cf . customerid as CUSTOMERID,
    cf . inputdate as INPUTDATE,
    cf . updatedate as LASTUPDATEDATE,
    rr . inputtime as INPUTTIME,
    rr . objectno as OBJECTNO,
    rr . objecttype as OBJECTTYPE,
    cf . orgid as ORGID,
    cf . recordno as RECORDNO,
    cf . remark as REMARK,
    cf . auditoffice as REMARK1,
    cf . reportcurrency as REPORTCURRENCY,
    substr(
        rr . reportdate,
        1,
        7
    ) as ACCOUNTMONTH,
    cf . reportdate as REPORTDATE,
    cf . reportflag as REPORTFLAG,
    rr . reportname as REPORTNAME,
    rr . modelno as REPORTNO,
    rr . reportno as REPORT_REPORTNO,
    rr . orgid as REPORT_ORGID,
    rr . userid as REPORT_USERID,
    cf . reportopinion as REPORTOPINION,
    cf . reportscope as REPORTSCOPE,
    cf . reportstatus as REPORTSTATUS,
    cf . reportunit as REPORTUNIT,
    rr . updatetime as UPDATETIME,
    cf . userid as USERID
FROM
    customer_fsrecord cf join  report_record rr
ON  rr . objecttype = 'CustomerFS' and  rr . objectno = cf . customerid
/

