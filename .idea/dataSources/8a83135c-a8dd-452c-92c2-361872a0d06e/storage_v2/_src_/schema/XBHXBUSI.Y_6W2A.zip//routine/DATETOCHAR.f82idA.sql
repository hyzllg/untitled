create function dateToChar(sDate date) return varchar is

begin

return to_char(sDate,'yyyy/MM/dd hh24:MI:ss');
end;
/

