create function fun_date_YorN(i_dt varchar2) return number is
  v_dt date;
begin
  v_dt := to_date(i_dt, 'yyyy-mm-dd');
  return 1;
exception
  when others then
    return 0;
end fun_date_YorN;
/

