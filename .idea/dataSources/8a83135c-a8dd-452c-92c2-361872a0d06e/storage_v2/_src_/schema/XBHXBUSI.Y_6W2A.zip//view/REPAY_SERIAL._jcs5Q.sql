create view REPAY_SERIAL as
select lbi.serialno,
       to_char(lbn.create_date, 'yyyy/MM/dd hh24:mi:ss') repayapplytime,
       lbi.BATCHDATE,
       al.ddproductid as productid,
       al.serialno as billno,
       al.customername,
       al.customerid,
       al.policyno,
       lbn.payamt as noticeamt,
       lbi.payamt as payamt,
       lbi.periodno,
       lbi.PAYBALANCE,
       lbi.PAYINTEREST,
       lbi.PAYASSUREFEE,
       lbi.PAYFINE,
       lbi.PAYCOMPOUND,
       nvl(LBI.ACTUALOVERDUEFINE,0) as ACTUALOVERDUEFINE,
       lbi.DADICLEARINGAMOUNT,
       lbi.BANKCLEARINGAMOUNT,
       lbi.CHANNELCLEARINGAMOUNT,
       DECODE(LBI.BATCHNO,'05','已理赔','99','已理赔','未理赔') as claimStatus,
       lbn.REPAYSTATUS,
       lbn.REPAYTYPE,
       lbn.OPERATETYPE,
       lbn.PAYCHANNEL,
       BA.RECEIVECHANNEL as PARENTCHANNELID,
       al.CAPITALCODE,
       al.TRUSTPLANNO,
       lbn.transtime,
       lbn.repaytime,
       lbn.COUPON as COUPON,
       lbn.REDREDUCEAMOUNT as REDREDUCEAMOUNT,
       lbn.AD_REPAY_AMT
from loan_batch_info lbi left join acct_loan al on al.SERIALNO=LBI.OBJECTNO
left join BUSINESS_APPLY BA  on al.APPLYSERIALNO = BA.SERIALNO
left join LOAN_BATCH_NOTICE lbn on lbi.repaymentserialno = lbn.serialno
/

