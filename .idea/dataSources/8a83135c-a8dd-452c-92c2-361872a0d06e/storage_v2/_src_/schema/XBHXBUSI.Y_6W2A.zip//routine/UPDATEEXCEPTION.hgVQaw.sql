create PROCEDURE updateException(name VARCHAR2,
                                            nub  out number,
                                            cnt  out number) as
BEGIN
  update exception_log_count
  
     set EXCEPTIONNUM        = EXCEPTIONNUM + 1,
         HISTORYEXCEPTIONNUM = HISTORYEXCEPTIONNUM + 1,
         COUNTTIME           = to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')
   where servicename = name
  returning exceptionnum into nub;
  cnt := sql%rowcount;
end;
/

