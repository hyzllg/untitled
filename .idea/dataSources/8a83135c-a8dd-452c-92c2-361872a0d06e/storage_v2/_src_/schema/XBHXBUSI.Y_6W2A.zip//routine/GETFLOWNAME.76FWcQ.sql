create FUNCTION GETFLOWNAME(pFlowNo in VARCHAR2)
RETURN VARCHAR2 AS
sFlowName varchar2(80);
begin
select FlowName into sFlowName from flow_catalog where FlowNo = pFlowNo;
return sFlowName;
end;

/

