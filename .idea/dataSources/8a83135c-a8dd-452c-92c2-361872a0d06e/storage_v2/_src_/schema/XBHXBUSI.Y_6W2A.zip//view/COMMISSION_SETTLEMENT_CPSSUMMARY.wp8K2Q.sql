create view COMMISSION_SETTLEMENT_CPSSUMMARY as
select putoutdate,
      DDPRODUCTID as DDPRODUCTID1,
      DDPRODUCTID as DDPRODUCTID2,
      count(bp.putoutdate) as putoutdate1,
      sum(nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)*nvl(bp.businesstermmonth,0)*nvl(COMMISSIONRATE,0)/120000.0) as COMMISSIONRATE1
from  BUSINESS_INSURANCEPOLICYINFO O, BUSINESS_PUTOUT bp
where O.POLICYNO=BP.POLICYNO and BP.PRODUCTID in(select cl.itemattribute from CODE_LIBRARY cl where CODENO='AgentOrgParamList')
group by bp.putoutdate,bp.ddproductid
/

