create view ROLE_RIGHT as
SELECT
    roleid as roleid,
    rightid as rightid,
    remark as remark,
    inputorg as inputorg,
    inputuser as inputuser,
    inputtime as inputtime,
    updateuser as updateuser,
    updatetime as updatetime
FROM
    awe_role_right
/

