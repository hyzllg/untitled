create function getPoundAge(billNo varchar,schedueSerialno varchar,curenPeriodno number)
  return varchar is
  returnValue number(24, 2);
  maxPeriodno number;
begin

  select max(ps.periodno) into maxPeriodno
    from ACCT_PAYMENT_SCHEDULE PS
   where PS.ObjectNo = billNo;

  if (curenPeriodno = maxPeriodno) then
    select TP.ACTUALPREPAYPENALTYAMT
      into returnValue
      from ACCT_TRANS_PAYMENT    TP,
           ACCT_TRANSACTION      AT,
           ACCT_PAYMENT_LOG      L
     where AT.documentno = TP.SERIALNO
       and AT.SERIALNO = L.transserialno
       AND L.ObjectType = 'jbo.acct.ACCT_PAYMENT_SCHEDULE'
       and L.ObjectNo = schedueSerialno;
    return returnValue;
  end if;
  return null;

end;

/

