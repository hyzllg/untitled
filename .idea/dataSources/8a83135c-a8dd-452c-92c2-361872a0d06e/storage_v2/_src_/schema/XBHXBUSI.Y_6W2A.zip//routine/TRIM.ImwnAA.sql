create FUNCTION trim( pValue in VARCHAR2) RETURN varchar2 AS sReturn varchar2(200);
begin
return ltrim(rtrim(pValue));
end trim;

/

