create FUNCTION getAttachmentSum(pDocNo in VARCHAR2)
RETURN number
IS
sCountNo number ;
BEGIN
 select count(DocNo) into sCountNo from doc_attachment where DocNo = pDocNo;
 return sCountNo;
END getAttachmentSum;

/

