create view CONFIG_CODE as
select CODENO,ITEMNO,SORTNO,ITEMNAME, ATTRIBUTE1 as VALUE,ISINUSE,ATTRIBUTE5,ATTRIBUTE6,CREATE_DATE,UPDATE_DATE
 from code_library
 where codeno in ('RelationShip','BankNo','LOAN_USE','Occupation','OtherBasics','LimitBasics','NewOccupation') and itemno <> 'folder'
  union all
 select 'OtherBasics' as CODENO,
        'FaceNumber' as ITEMNO,
        SORTNO,
        '人脸识别次数' as ITEMNAME,
        ITEMATTRIBUTE as VALUE,ISINUSE,ATTRIBUTE5,ATTRIBUTE6,CREATE_DATE,UPDATE_DATE
 from code_library
 where codeno in ('PersonValue')
 union all
 select 'OtherBasics' as CODENO,
        'BankNumber' as ITEMNO,
        SORTNO,
        '银行卡鉴权次数' as ITEMNAME,
        ITEMATTRIBUTE as VALUE,ISINUSE,ATTRIBUTE5,ATTRIBUTE6,CREATE_DATE,UPDATE_DATE
 from code_library
 where codeno in ('CardAuthTime')
 union all
 select 'ChannelPoolConfig' as codeno,
        p.poolcode as itemno,
        '' as sortno,
        p.poolname as itemname,
        to_char(DAILYREGISTRATION) as VALUE,
        ISINUSE as ISINUSE,
        '' as ATTRIBUTE5,
        '' as ATTRIBUTE6,
        CREATE_DATE as CREATE_DATE,
        UPDATE_DATE as UPDATE_DATE
   from CHANNEL_POOL p
 union all
   select 'ChannelPoolRelative' as codeno,
        c.receivechannelcode as itemno,
        '' as sortno,
        c.receivechannelname as itemname,
        c.poolcode as VALUE,
        ISINUSE as ISINUSE,
        '' as ATTRIBUTE5,
        '' as ATTRIBUTE6,
        CREATE_DATE as CREATE_DATE,
        UPDATE_DATE as UPDATE_DATE
   from CHANNEL_POOL_RECEIVE C
/

