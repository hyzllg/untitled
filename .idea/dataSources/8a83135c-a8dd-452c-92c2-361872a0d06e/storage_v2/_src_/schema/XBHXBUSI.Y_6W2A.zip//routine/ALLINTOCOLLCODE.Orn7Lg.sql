create function allinToCollCode(allincode varchar)
  return varchar is
  --通知扣款状态转成催收状态码值
  rts varchar2(20);

begin
  /**
  *  00 扣款中
  *  01 扣款成功
  *  02 扣款失败
  *  03 扣款异常
  */
  if (allincode = '01') then
    rts := '4';  --成功
  elsif (allincode = '02') then
    rts := '3';  --失败
  elsif (allincode = '03') then
    rts := '5';  --异常
  elsif (allincode = '00') then
    rts := '0';  --扣款中
  else
    rts := '0';  --扣款中
  end if;

  return rts;

end;


/

