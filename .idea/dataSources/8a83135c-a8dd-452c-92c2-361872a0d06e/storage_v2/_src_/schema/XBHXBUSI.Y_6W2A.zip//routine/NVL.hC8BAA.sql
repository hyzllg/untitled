create FUNCTION nvl(pValue in NUMber, pDefault in NUMBER)
RETURN NUMBER
AS
sReturn number;
begin
return coalesce(pValue,pDefault);
end nvl;

/

