create view V_COM_SEARCH_MD5
            (INSIDE_APP_NO, APPLY_NO, APPLY_STATUS, APPLY_STAGE, BUSINESS_SUM, APPROVAL_AMOUNT, LOAN_AMOUNT,
             APPROVAL_USER_NO, APPROVAL_USER_NAME, APPROVAL_VIEW, APPROVAL_REASON, INTERVIEW_UESR_NO,
             INTERVIEW_UESR_NAME, INTERVIEW_VIEW, INTERVIEW_REASON, CRT_DATE, CRT_TIME, CRT_USER, LST_UPD_USER,
             LST_UPD_DATE, LST_UPD_TIME, BATCH_DATE, REC_STATUS, SCR_LEVEL, ILOG_ADVICE_AMOUNT, LOAN_STATUS, ILOG_RATE,
             ID_CARD, ACCOUNT_TYPE, NAME, PRE_APPLY_NO, ILOG_AMOUNT)
as
SELECT
        inside_app_no,
        apply_no,
        apply_status,
        apply_stage,
        business_sum,
        approval_amount,
        loan_amount,
        approval_user_no,
        approval_user_name,
        approval_view,
        approval_reason,
        interview_uesr_no,
        interview_uesr_name,
        interview_view,
        interview_reason,
        crt_date,
        crt_time,
        crt_user,
        lst_upd_user,
        lst_upd_date,
        lst_upd_time,
        batch_date,
        rec_status,
        scr_level,
        ilog_advice_amount,
        loan_status,
        ilog_rate,
        md5utils(nvl(id_card,'000000000000000000')),
        account_type,
        name,
        pre_apply_no,
        ilog_amount
    FROM
        llas_biz_apply_com_search
/

