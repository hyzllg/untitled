create view VW_BIZ_BUSINESS_APPLY_INFO as
( SELECT
        ba.apply_no,
        ba.input_user_id,
        ba.sales_user_id,
        ba.business_type,
        ba.repay_type,
        ba.input_org_id,
        rta.operation_org,
        itw.signterm,
        itw.sign_amount,
        ba.apply_date,
        ins.policyid,
        ba.sales_director,
        ba.sale_org_id,
        ba.operatorid,
        ba.customer_id,
        ba.interactive_man,
        ba.channel_name,
        acs.ilog_rate,
        ba.term_month,
        ba.id_number,
        ba.account_type,
    case
      when cl.PROPERTY_TYPE='1' then ba.channel_type
      else  cc.channeltype
    end     channeltype,
        ba.channel_type,
        ba.LST_UPD_DATE,
        ba.LST_UPD_TIME
    FROM
        llas_biz_business_apply ba,
        llas_biz_retail_sales_apply rta,
        llas_biz_interview itw,
        llas_biz_insurancepolicy ins,
        llas_biz_apply_com_search acs,
    LLAS_CUSTOMER_LOCK  cl,
    llas_channel_company cc

    WHERE
            ba.inside_app_no = rta.inside_app_no (+)
        AND
            ba.inside_app_no = itw.inside_app_no (+)
        AND
            ba.inside_app_no = ins.inside_app_no (+)
        AND
            ba.inside_app_no = acs.inside_app_no (+)
    and
      ba.inside_app_no = cl.inside_app_no
    and
      ba.CHANNEL_COMPANY_CODE=cc.COMPANYCODE(+)

    )
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.APPLY_NO is '业务申请编号'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.INPUT_USER_ID is '基本信息-登记人'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.SALES_USER_ID is '客户申请受理信息-销售人员ID'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.BUSINESS_TYPE is '客户申请受理信息-产品编号'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.REPAY_TYPE is '客户申请信息-还款方式'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.INPUT_ORG_ID is '基本信息-登记机构'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.OPERATION_ORG is '操作机构'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.SIGNTERM is '签约期限'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.SIGN_AMOUNT is '面签额度'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.APPLY_DATE is '客户申请信息-申请日期'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.POLICYID is '保单号'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.SALES_DIRECTOR is '客户申请受理信息-业务主任ID'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.SALE_ORG_ID is '销售机构'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.OPERATORID is '经办人ID'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.CUSTOMER_ID is '基本信息-客户编号'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.INTERACTIVE_MAN is '客户申请受理信息-互动专员'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.CHANNEL_NAME is '客户申请受理信息-渠道名称'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.ILOG_RATE is 'ilog保费率'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.TERM_MONTH is '客户申请信息-期限'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.ID_NUMBER is '基本信息-身份证号'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.ACCOUNT_TYPE is '账户类型'
/

comment on column VW_BIZ_BUSINESS_APPLY_INFO.CHANNEL_TYPE is '客户申请受理信息-渠道名称'
/

