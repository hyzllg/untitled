create procedure test3(age in int)
as
begin
  age := 10/0;
  dbms_output.put_line(age);
exception when others then
  dbms_output.put_line('error');
end;

/

