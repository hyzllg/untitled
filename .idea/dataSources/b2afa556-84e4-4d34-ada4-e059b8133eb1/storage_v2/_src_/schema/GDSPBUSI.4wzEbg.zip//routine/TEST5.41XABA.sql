create procedure test5(age out int)
as
begin
  age := 10/0;
  dbms_output.put_line(age);
exception when others then
  dbms_output.put_line('error');
end;

/

