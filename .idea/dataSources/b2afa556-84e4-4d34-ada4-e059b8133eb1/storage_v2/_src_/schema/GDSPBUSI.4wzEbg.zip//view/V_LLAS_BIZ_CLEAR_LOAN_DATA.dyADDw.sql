create view V_LLAS_BIZ_CLEAR_LOAN_DATA as
SELECT
  serial_no,
  customer_name,
  NVL2(cert_id,SUBSTR(cert_id, 1, 2) || '****' || SUBSTR(cert_id, 7, 8) || '**'||SUBSTR(cert_id,17),'' ) cert_id,
  branch_name,
  NVL2(mobile_phone,SUBSTR(mobile_phone,1,3)||'********','') mobile_phone,
  business_type_name,
  term_month,
  business_sum,
  sign_time,
  input_org_name,
  fee1_rate,
  finish_date,
  loan_source,
  customer_type,
  presum,
  pre_policy_rate,
  crt_date,
  crt_time,
  crt_user,
  lst_upd_user,
  lst_upd_date,
  lst_upd_time,
  lst_org_id,
  batch_date,
  rec_status,
  scr_level,
  lastnewapprovalno
FROM GDSPBUSI.LLAS_BIZ_CLEAR_LOAN_DATA
/

