create view V_ICR_RPT_H01 as
SELECT
RPTNO, F0, F1,
 NVL2(F2,SUBSTR(F2,1,4)||'************'||SUBSTR(F2,17),'' ) F2,
F3, F4, F5, F6, F7, F8, F9, F10, F11
FROM ICR_RPT_H01
/

