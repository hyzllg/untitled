create PROCEDURE TEST1
AS
    CUSTOMER_NAME VARCHAR(20);
BEGIN
    CUSTOMER_NAME := 'ZZZZ';
    DBMS_OUTPUT.put_line(customer_name);
end;
/

