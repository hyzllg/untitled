create procedure test2(customer in varchar2)
as
begin
  dbms_output.put_line(customer);
end;

/

