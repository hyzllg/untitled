create view V_PHONE_AUTH_REQ as
SELECT
	a.id,
  a.serial_no,
  a.apply_no,
  a.source,
  a.product_id,
  a.cust_name,
  NVL2(a.mobile,SUBSTR(a.mobile,1,3)||'********','') mobile,
  NVL2(a.id_card,SUBSTR(a.id_card, 1, 2) || '****' || SUBSTR(a.id_card, 7, 8) || '**'||SUBSTR(a.id_card,17),'' ) id_card,
  a.mobile_type,
  a.req_id,
  a.res_status,
  a.is_valid,
  a.is_del,
  a.create_time,
  a.update_time,
  a.create_year_month
FROM GDSPBUSI.gdtp_zcx_phone_auth_req a
/

