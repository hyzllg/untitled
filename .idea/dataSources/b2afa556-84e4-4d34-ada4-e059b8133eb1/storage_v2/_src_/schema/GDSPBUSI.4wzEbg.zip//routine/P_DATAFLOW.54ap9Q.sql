create PROCEDURE p_DataFlow (yearStr IN VARCHAR2,startTime IN VARCHAR2, endTime IN VARCHAR2) Authid Current_User
AS
v_createSql VARCHAR2(32000);
v_tableCount int(4);
v_insertSql VARCHAR2(32000);
v_deleteSql VARCHAR2(32000);
BEGIN
  /*创建年表*/
  v_createSql := 'CREATE TABLE ' || 'llas_biz_data_flow_' || yearStr
         ||'( data_id        VARCHAR2(40) primary key,
              inside_app_no  VARCHAR2(32),
            node_ins_no    VARCHAR2(32),
            interface_code VARCHAR2(50),
            file_type      VARCHAR2(10),
            req_file_path  VARCHAR2(500),
            res_file_path  VARCHAR2(500),
            expire_time    VARCHAR2(50),
            attribute1     VARCHAR2(200),
            attribute2     VARCHAR2(200),
            attribute3     VARCHAR2(200),
            crt_date       DATE default SYSDATE,
            crt_time       TIMESTAMP(6) default SYSDATE,
            crt_user       VARCHAR2(20) default '||'''SYSTEM'','||
            'lst_upd_user   VARCHAR2(20) default '||'''SYSTEM'','||
            'lst_upd_date   DATE default SYSDATE,
            lst_upd_time   TIMESTAMP(6) default SYSDATE,
            batch_date     DATE,
            rec_status     VARCHAR2(1) default '||'''1'','||
            'scr_level      VARCHAR2(2) default '||'''00'','||
            'cast_time      NUMBER
            )';


  /*判断年表是否存在,不存在则创建该表*/
  SELECT COUNT(1) INTO v_tableCount FROM user_tables WHERE table_name = UPPER(CONCAT('llas_biz_data_flow_', yearStr));
  IF v_tableCount = 0 THEN
    DBMS_OUTPUT.PUT_LINE(v_createSql);
    EXECUTE IMMEDIATE v_createSql;
    --添加注释
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.data_id IS ''数据id''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.inside_app_no IS ''内审编号''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.node_ins_no IS ''节点实例编号''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.interface_code IS ''接口编码''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.file_type IS ''文件类型''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.req_file_path IS ''请求文件地址''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.res_file_path IS ''响应文件地址''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.expire_time IS ''过期时间''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.attribute1 IS ''扩展字段1''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.attribute2 IS ''扩展字段2''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.attribute3 IS ''扩展字段3''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.crt_date IS ''创建时间''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.crt_time IS ''创建时间戳''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.crt_user IS ''创建人''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.lst_upd_user IS ''最后修改人''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.lst_upd_date IS ''最后修改时间''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.lst_upd_time IS ''最后修改时间戳''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.batch_date IS ''批量提交时间''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.rec_status IS ''是否有效 1有效 2无效''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.scr_level IS ''保密级别''';
    EXECUTE IMMEDIATE 'COMMENT ON COLUMN ' || 'llas_biz_data_flow_' || yearStr || '.cast_time IS ''本地调用接口耗时 单位（ms）毫秒''';
    --添加授权
    --EXECUTE IMMEDIATE 'grant select on ' || 'llas_biz_data_flow_' || yearStr || ' to GDFQZQRY';
    --EXECUTE IMMEDIATE 'grant select on ' || 'llas_biz_data_flow_' || yearStr || ' to GDSPSJFXQRY1';
    --EXECUTE IMMEDIATE 'grant select on ' || 'llas_biz_data_flow_' || yearStr || ' to GDSPSJFXQRY2';
    --EXECUTE IMMEDIATE 'grant select on ' || 'llas_biz_data_flow_' || yearStr || ' to GDSPYWFXQRY1';
    --EXECUTE IMMEDIATE 'grant select on ' || 'llas_biz_data_flow_' || yearStr || ' to GDSPYWFXQRY2';

    COMMIT;
  END IF;

  /*插入日期是startTime到endTime的数据至年表*/
  v_insertSql :='insert into llas_biz_data_flow_' || yearStr
        ||' select *
        from llas_biz_data_flow_tst where data_id >='''
        ||startTime
        ||''' and data_id <'''
        ||endTime ||'''';
  DBMS_OUTPUT.PUT_LINE(v_insertSql);
  EXECUTE IMMEDIATE v_insertSql;
  COMMIT;

  /*删除日期是startTime到endTime的数据至年表*/
  v_deleteSql :='delete from llas_biz_data_flow_tst where data_id >='''
        ||startTime
        ||''' and data_id <'''
        ||endTime ||'''';
  DBMS_OUTPUT.PUT_LINE(v_deleteSql);
  EXECUTE IMMEDIATE v_deleteSql;
  COMMIT;

END;
/

