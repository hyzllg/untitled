create PROCEDURE MYDEMO02
AS
        name VARCHAR(10);
        age NUMBER(10);
BEGIN
        name := 'xiaoming';
        age := 18;
        dbms_output.put_line ( 'name=' || name || ', age=' || age );
END;

/

