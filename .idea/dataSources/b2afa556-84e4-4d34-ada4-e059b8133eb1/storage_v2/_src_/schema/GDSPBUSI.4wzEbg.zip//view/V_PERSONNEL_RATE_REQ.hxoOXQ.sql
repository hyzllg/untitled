create view V_PERSONNEL_RATE_REQ as
SELECT
  a.id,
  a.serial_no,
  a.cust_name,
  NVL2(a.id_card,SUBSTR(a.id_card, 1, 2) || '****' || SUBSTR(a.id_card, 7, 8) || '**'||SUBSTR(a.id_card,17),'' ) id_card,
  a.enc_type,
  a.client_no,
  a.a_code,
  a.account,
  a.res_status,
  a.is_valid,
  a.is_del,
  a.create_time,
  a.update_time,
  a.create_year_month
FROM GDSPBUSI.gdtp_bm_key_personnel_rate_req a
/

