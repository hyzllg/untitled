create FUNCTION getObjectTypeName(pObjectType in VARCHAR2)
RETURN varchar2
AS
sReturn varchar2(100);
begin
select coalesce(ObjectName,pObjectType) into sReturn from objecttype_catalog where ObjectType=pObjectType;
return sReturn;
end getObjectTypeName;
/

