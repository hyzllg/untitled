create procedure pro_test(v_pram1 in varchar,pram2 out number)
Authid Current_user;
is
   v_step varchar;

begin

       v_step:='select * from trust_plan where trustplanno=v_pram1';
       
exception
end;

/

