create FUNCTION getCityName(sAreaCode in VARCHAR2)
RETURN varchar
IS
sCityName varchar(80) ;
BEGIN
 SELECT substr( O.ITEMNAME,instr(O.ITEMNAME,'省',-1)+1) into sCityName FROM CODE_LIBRARY O WHERE O.isinuse = '1'
   AND O.codeno = 'AreaCode' and itemno = sAreaCode
 ORDER BY O.sortno;
 return sCityName;
END getCityName;
/

