create FUNCTION getRepayDay(capitalCode varchar, putoutdate  varchar)
   return varchar is
--根据资方获取还款日
begin
  if (capitalCode in ('HNTRUST','787')) then
    if (substr(putoutdate, -2) > 28) then
      return '28';
    else
      return substr(putoutdate, -2);
    end if;
  end if;
  return substr(putoutdate, -2);
end;
/

