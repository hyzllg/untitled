create function getSexFromCertid(certid varchar2) return varchar2
begin
       return mod(to_number( substr(certid,17, 1)),2)--0:女  1：男
end;
/

