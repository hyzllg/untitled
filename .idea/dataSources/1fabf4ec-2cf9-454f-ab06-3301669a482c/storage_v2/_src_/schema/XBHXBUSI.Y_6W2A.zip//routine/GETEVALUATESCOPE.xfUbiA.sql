create FUNCTION GETEVALUATESCOPE
(
   pObjectNo in varchar2,pReportDate in varchar2
)
RETURN varchar2
as
iCount number;
pReturnValue varchar2(40);
begin
	   select count(ReportScope) into iCount  From report_record where ObjectType='CustomerFS'  and ObjectNo=pObjectNo and ReportDate=pReportDate and ModelNo like '%9' and ReportScope='01';
	if iCount > 0
    then pReturnValue := '01';
	else
	  select count(ReportScope) into iCount From report_record where ObjectType='CustomerFS' and ObjectNo=pObjectNo and ReportDate=pReportDate and ModelNo like '%9' and ReportScope='02';
    if iCount > 0 then pReturnValue := '02';
    else pReturnValue := '03';
    end if;
  end if;
  return pReturnValue;
end getEvaluateScope;
/

