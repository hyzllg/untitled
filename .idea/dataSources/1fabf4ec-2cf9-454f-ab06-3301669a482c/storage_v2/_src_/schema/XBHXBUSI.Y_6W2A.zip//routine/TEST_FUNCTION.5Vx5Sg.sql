create function test_function(v_pam1 varchar,v_pam2 varchar)
return varchar
is
v_sum number;
begin
select count(*) into v_sum from TRUST_PLAN where trustplanno in(v_pam1,v_pam2);
dbms_output.put_line(v_sum);
return v_sum;
end;
/

