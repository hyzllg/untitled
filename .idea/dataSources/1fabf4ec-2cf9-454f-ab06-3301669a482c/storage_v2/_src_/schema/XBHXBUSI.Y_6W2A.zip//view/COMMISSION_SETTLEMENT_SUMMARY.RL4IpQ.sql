create view COMMISSION_SETTLEMENT_SUMMARY as
select substr(o.TRANSENDTIME,0,10) as TRANSENDTIME,
    DDPRODUCTID as DDPRODUCTID1,
    PRODUCTNAME,
    count(BatchDate) as BDATE,
    sum(nvl(COMMISSIONTATE,0)*nvl(PAYASSUREFEE,0))/100 as PAYASSUREFEE1,
    DDPRODUCTID as DDPRODUCTID2,
    DDPRODUCTID as DDPRODUCTID3
from LOAN_BATCH_INFO O, BUSINESS_CONTRACT bc, PRODUCT_CONFIG_INFO pci
where O.objecttype = 'jbo.acct.ACCT_LOAN'
    and o.objectNo = bc.serialno
    and (O.TRANSSTATUS like '9%' or O.TRANSSTATUS = '50')
    and bc.DDProductID = pci.productid
    and pci.productid in (select cl.itemattribute from CODE_LIBRARY cl where cl.CODENO='AgentSubCommission')
    and bc.create_time > decode(bc.ddproductid, '7014',to_date('2021/05/20 17:00:00','yyyy/mm/dd hh24:mi:ss'),to_date('2018/02/22','yyyy/mm/dd'))
    group by substr(o.TRANSENDTIME,0,10),bc.DDPRODUCTID,pci.productName
/

