create FUNCTION getPhone
(
  mobile in VARCHAR2
) RETURN VARCHAR2
AS
sReturn  varchar2(40);
begin
return  substr(mobile,1,3)||'****'||substr(mobile,-4,4);
end getPhone;
/

