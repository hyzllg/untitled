create view CUSTOMER_CITY as
select p.provice,
       getItemName('AreaCode',p.provice) as provicename,
       p.city,getItemName('AreaCode',p.city) as cityname,
       isinuse,
       create_date,
       update_date
  from open_city p
 where p.channel='App'
/

