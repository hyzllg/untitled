create view RIGHT_INFO as
select
    rightid as rightid,
    rightname as rightname,
    rightdescribe as rightdescribe,
    rightstatus as rightstatus,
    inputorg as inputorg,
    inputuser as inputuser,
    inputtime as inputtime,
    updateuser as updateuser,
    updatetime as updatetime,
    remark as remark
from
    awe_right_info
/

