create FUNCTION getProductName(sProductId IN varchar2)
    RETURN VARCHAR2 IS
    sProductName VARCHAR2(80);
  BEGIN
    select ProductName
    into sProductName
    from PRODUCT_CONFIG_INFO
     where PRODUCTID = sProductId;
    return sProductName;
  END getProductName;
/

