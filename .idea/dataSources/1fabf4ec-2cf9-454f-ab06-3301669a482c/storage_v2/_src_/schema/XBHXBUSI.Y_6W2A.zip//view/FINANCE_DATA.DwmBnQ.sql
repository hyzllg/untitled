create view FINANCE_DATA as
select
    rr . objectno as CUSTOMERID,
    substr(
        cf . reportdate,
        1,
        7
    ) as ACCOUNTMONTH,
    rr . modelno as MODELNO,
    rd . reportno as REPORTNO,
    cf . reportscope as SCOPE,
    rd . rowsubject as FINANCEITEMNO,
    rd . col1value as ITEM1VALUE,
    rd . col2value as ITEM2VALUE,
    rd . col3value as ITEM1BASEVALUE,
    rd . col4value as ITEM2BASEVALUE,
    rd . standardvalue as STANDARDVALUE,
    rd . displayorder as DISPLAYORDER,
    rd . rowattribute as ITEMATTRIBUTE,
    rd . rowname as DISPLAYNAME,
    rd . rowno as DISPLAYNO
from(
 customer_fsrecord cf join  report_record rr on rr . objecttype = 'CustomerFS' and  rr . objectno = cf . customerid and rr . reportdate = cf . reportdate and cf . reportscope = rr . reportscope
) join  report_data rd on rd . reportno = rr . reportno
/

