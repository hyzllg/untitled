create view FLOWHANG as
SELECT CA.Name AS CUSTOMERNAME,
           CA.CUSTOMERID AS CUSTOMERID,
           CA.Idno AS CERTID,
           CA.Phone AS PHONENO,
           CA.PRODUCTID AS PRODUCTID,
           QT.SERIALNO AS MODELNO,
           '授信流程' AS CURRENTFLOW,
           getitemname('ChannelFlowNo',CA.APPROVESTAGE) AS APPROVESTAGE,
           CASE CA.APPROVESTATUS
           WHEN '0' THEN '拒绝'
           WHEN '1' THEN '成功'
           WHEN '2' THEN '处理中'
           WHEN '4' THEN '失败'
           WHEN '5' THEN '取消'
           WHEN '888' THEN '异常'
           WHEN 'G' THEN '挂起'
           ELSE '其他' END
            AS APPROVESTATUS,
           ca.capitalcode CAPITALNAME,
           QT.CREATETIME AS CREATETIME,
           CA.SERIALNO AS SERIALNO
      FROM QUEUE_TASK QT ,CHANNEL_APPLY_INFO CA
      WHERE QT.RUNSTATUS = 'G'
      AND QT.OBJECTTYPE = 'jbo.channel51.CHANNEL_APPLY_INFO'
      AND CA.SERIALNO = QT.OBJECTNO
UNION ALL
      SELECT CI.CUSTOMERNAME AS CUSTOMERNAME,
           CI.CUSTOMERID AS CUSTOMERID,
           CI.CERTID AS CERTID,
           CI.PHONENO AS PHONENO,
           PA.PRODUCTID AS PRODUCTID,
           QT.SERIALNO AS MODELNO,
           '提现流程' AS CURRENTFLOW,
           --getitemname('WithdrawalStage',PA.STAGE) AS APPROVESTAGE,
           QT.Itemname AS APPROVESTAGE,
           CASE getitemname('PutoutApproveStatus',PA.STATUS)
           WHEN '提现超时取消' THEN '取消'
           ELSE getitemname('PutoutApproveStatus',PA.STATUS) END
            AS APPROVESTATUS,
           PA.CAPITALCODE AS CAPITALNAME,
           QT.CREATETIME AS CREATETIME,
           PA.SERIALNO AS SERIALNO
      FROM QUEUE_TASK QT, CUSTOMER_INFO CI ,PUTOUT_APPROVE PA
      WHERE QT.CUSTOMERID = CI.CUSTOMERID
      AND QT.RUNSTATUS = 'G'
      AND QT.OBJECTTYPE = 'jbo.app.PUTOUT_APPROVE'
      AND PA.SERIALNO = QT.OBJECTNO
/

