create function function1(tabname in varchar2, tabcol in varchar2)
return varchar2 is
leh    number;
r      varchar2(80);
begin
select count(1) into leh from user_cons_columns cu, user_constraints au
where cu.constraint_name = au.constraint_name and au.constraint_type = 'P'
and au.table_name =  tabname and cu.column_name=tabcol;
if(leh > 0) then
    r := 'PK';
  else
    r:='';
      end if;
  return r;
end function1;
/

