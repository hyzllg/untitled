create view FINANCE_MODEL as
SELECT
    col1def as ITEM1DEF,
    col2def as ITEM1BASEDEF,
    col3def as ITEM2DEF,
    col4def as ITEM2BASEDEF,
    deleteflag as DELETEFLAG,
    displayorder as LISTNO,
    modelno as REPORTNO,
    rowattribute as ITEMATTRIBUTE,
    rowname as DISPLAYNAME,
    rowno as DISPLAYNO,
    rowsubject as FINANCEITEMNO,
    standardvalue as STANDARDVALUE
 FROM
    report_model
/

