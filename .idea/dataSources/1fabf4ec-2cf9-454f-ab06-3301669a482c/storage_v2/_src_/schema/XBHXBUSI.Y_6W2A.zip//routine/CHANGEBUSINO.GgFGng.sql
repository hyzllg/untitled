create function changeBusiNo(putoutdate varchar, productId  varchar) return varchar is
  /*获取光大银行子渠道映射*/
  bNo varchar2(20); --子渠道号

begin
  /**
  *  2014001 子渠道号
  *  2014002 子渠道号
  *
  *
  *  光大问题修正:dev 2019-08-16
  *  信用卡产品7012正常子渠道应该用 2014002    光大6/21-7/24调整过子渠道为 2014001
  *  公积金产品7013正常子渠道应该用 2014001    公积金7月27号第一笔放款,渠道调整之前与信用卡子渠道一样(上线调整时间为2019/09/X)
  *  甜橙借钱产品7014  正常子渠道用 2014001
  *
  */

  case productId
       when '7012' then
            -- 光大6/21-7/24调整过子渠道为 2014001,特殊处理
            if (putoutdate > '2019/06/21' and putoutdate < '2019/07/25') then
               bNo := '2014001'; --子渠道号
            else
               bNo := '2014002'; --子渠道号   信用卡产品7012
            end if;
       when '7013' then
               bNo := '2014001'; --子渠道号   公积金产品7013
     when '7014' then
               bNo := '2014001'; --子渠道号   甜橙借钱产品7014
  end case;

  return bNo;

end;
/

