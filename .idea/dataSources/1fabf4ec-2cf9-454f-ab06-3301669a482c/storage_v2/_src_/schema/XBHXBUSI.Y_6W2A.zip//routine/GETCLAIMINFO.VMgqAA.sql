create FUNCTION getClaimInfo
(
  claiminfo  in VARCHAR2,
  operator in VARCHAR2,
  checkdate in VARCHAR2

) RETURN VARCHAR2
AS
begin
return replace(replace(REPLACE(claiminfo,
                               '经办人员签名：',
                               '经办人员签名：' ||operator),
                       '复核：   年 月 日',
                       '复核：' || substr(checkdate, 0, 4) || '年' ||
                       substr(checkdate, 6, 2) || '月' ||
                       substr(checkdate, 9, 2) || '日'),
               '对该申请给予 □确认 □驳回',
               '对该申请给予 √确认 □驳回');
end getClaimInfo;
/

