create FUNCTION getRoleName(pRoleID in varchar2)
RETURN varchar2
AS
sReturn varchar2(100);
begin
select coalesce(RoleName,pRoleID) into sReturn from role_info Where RoleID = pRoleID;
return sReturn;
end getRoleName;
/

