create FUNCTION getOrgName(pOrgID in VARCHAR2)
RETURN varchar2
AS
sReturn varchar2(100);
begin
select OrgName into sReturn from org_info where Orgid= pOrgID;
return sReturn;
end getOrgName;
/

