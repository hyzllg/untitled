create view V_HOUSE_PROPERTY_OWNER_CM as
SELECT
  id,
  inside_app_no,
  owner_name,
  relation_ship,
  NVL2(id_card,SUBSTR(id_card, 1, 2) || '****' || SUBSTR(id_card, 7, 8) || '**'||SUBSTR(id_card,17),'' ) id_card,
  tel
FROM GDSPBUSI.LLAS_BIZ_HOUSE_PROPERTY_OWNER_CM
/

