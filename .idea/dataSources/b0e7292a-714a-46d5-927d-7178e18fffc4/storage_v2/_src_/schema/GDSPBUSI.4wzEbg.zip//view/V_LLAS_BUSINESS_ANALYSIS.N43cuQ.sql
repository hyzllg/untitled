create view V_LLAS_BUSINESS_ANALYSIS as
SELECT
    llas_biz_business_apply.apply_no,
    llas_biz_insurancepolicy.policyid,
    llas_biz_business_apply.input_org_id,
    llas_biz_business_apply.input_org_name,
    llas_biz_org_info.depart_code,
    llas_biz_org_info.sale_org,
    llas_biz_org_info.sale_org_name,
    llas_biz_apply_com_search.business_sum,
    llas_biz_approval.end_date,
    llas_biz_interview.approve_amount,
    llas_biz_loan_manage.bank_date,
    llas_biz_interview.int_final_amount,
    llas_biz_apply_com_search.apply_stage,
    llas_biz_apply_com_search.apply_status,
    llas_biz_apply_com_search.ilog_rate,
    llas_biz_business_apply.business_type_name,
    llas_biz_business_apply.term_month,
    llas_biz_business_apply.account_type,
    llas_biz_recognizee.loan_bank,
    llas_biz_quota.interest_rate,
    llas_biz_business_apply.channel_name,
    llas_biz_business_apply.sub_channel,
    llas_biz_business_apply.is_native,
    llas_biz_business_apply.self_is_private_owner,
    llas_biz_input_refuse.main_reason,
    llas_biz_cust_lifeinsurance.insurance_type,
    llas_biz_cust_lifeinsurance.policy_op_date,
    llas_biz_cust_lifeinsurance.need_pay_years,
    llas_biz_cust_lifeinsurance.premium_paid_month,
    llas_biz_cust_lifeinsurance.insurancecompany,
    llas_biz_cust_lifeinsurance.pay_way,
    llas_biz_customer_vehicle.car_type,
    llas_biz_customer_vehicle.vehicle_brand,
    llas_biz_customer_vehicle.vehicle_year,
    llas_biz_customer_vehicle.purchase_sum,
    llas_biz_customer_vehicle.car_insurance_company,
    llas_biz_customer_vehicle.is_used_car,
    llas_biz_customer_realty.realty_attribute,
    llas_biz_business_apply.use_of_land,
    llas_biz_business_apply.estimated_value,
    llas_biz_mortgage.end_firm_value,
    llas_biz_business_apply.holding_time,
    llas_biz_customer_realty.is_local,
    llas_biz_business_apply.IS_ONLY_HOUSE,
    llas_biz_business_apply.one_or_two_mortgage,
    llas_biz_business_apply.first_balance,
    llas_biz_business_apply.city_type,
    llas_biz_business_apply.final_ltv,
    llas_biz_business_apply.self_is_sociale_curity,
    llas_biz_business_apply.self_is_house_reserve_fund,
    llas_biz_business_apply.self_payment_base,
    llas_biz_business_apply.self_payment_base2,
    llas_biz_business_apply.self_deposit_status,
    llas_biz_business_apply.self_pay_year_month
FROM
    llas_biz_business_apply
    LEFT JOIN llas_biz_insurancepolicy ON llas_biz_business_apply.inside_app_no = llas_biz_insurancepolicy.inside_app_no and llas_biz_insurancepolicy.rec_status = '1'
    LEFT JOIN llas_biz_org_info ON llas_biz_business_apply.inside_app_no = llas_biz_org_info.inside_app_no and llas_biz_org_info.rec_status = '1'
    LEFT JOIN llas_biz_apply_com_search ON llas_biz_business_apply.inside_app_no = llas_biz_apply_com_search.inside_app_no and llas_biz_apply_com_search.rec_status = '1'
    LEFT JOIN llas_biz_approval ON llas_biz_business_apply.inside_app_no = llas_biz_approval.inside_app_no and llas_biz_approval.rec_status = '1'
    LEFT JOIN llas_biz_interview ON llas_biz_business_apply.inside_app_no = llas_biz_interview.inside_app_no and llas_biz_interview.rec_status = '1'
    LEFT JOIN llas_biz_loan_manage ON llas_biz_business_apply.inside_app_no = llas_biz_loan_manage.inside_app_no
    LEFT JOIN llas_biz_recognizee ON llas_biz_business_apply.inside_app_no = llas_biz_recognizee.inside_app_no and llas_biz_recognizee.rec_status = '1'
    LEFT JOIN llas_biz_quota ON llas_biz_business_apply.inside_app_no = llas_biz_quota.inside_app_no and llas_biz_quota.rec_status = '1'
    LEFT JOIN llas_biz_input_refuse ON llas_biz_business_apply.apply_no = llas_biz_input_refuse.apply_no and llas_biz_input_refuse.rec_status = '1'
    LEFT JOIN llas_biz_cust_lifeinsurance ON llas_biz_business_apply.inside_app_no = llas_biz_cust_lifeinsurance.inside_app_no and llas_biz_cust_lifeinsurance.rec_status = '1'
    LEFT JOIN llas_biz_customer_vehicle ON llas_biz_business_apply.inside_app_no = llas_biz_customer_vehicle.inside_app_no and llas_biz_customer_vehicle.rec_status = '1'
    LEFT JOIN llas_biz_customer_realty ON llas_biz_business_apply.inside_app_no = llas_biz_customer_realty.inside_app_no and llas_biz_customer_realty.rec_status = '1'
    LEFT JOIN llas_biz_mortgage ON llas_biz_business_apply.inside_app_no = llas_biz_mortgage.inside_app_no and llas_biz_mortgage.rec_status = '1'
/

