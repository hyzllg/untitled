create view V_LIMIT_CREDITINFO as
SELECT
  id,
  inside_app_no,
  apply_no,
  credit_type,
  credit_status,
  crt_date,
  crt_time,
  crt_user,
  lst_upd_user,
  lst_upd_date,
  lst_upd_time,
  rec_status,
  add_credit_status_advise

FROM GDSPBUSI.LLAS_BIZ_LIMIT_CREDITINFO
/

