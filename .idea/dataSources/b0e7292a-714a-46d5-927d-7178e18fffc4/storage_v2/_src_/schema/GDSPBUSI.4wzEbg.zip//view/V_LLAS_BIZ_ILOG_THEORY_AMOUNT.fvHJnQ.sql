create view V_LLAS_BIZ_ILOG_THEORY_AMOUNT as
select ID,INSIDE_APP_NO,CLASS_RESULT,LST_UPD_TIME,rec_status FROM gdspbusi.llas_biz_ilog_theory_amount
/

