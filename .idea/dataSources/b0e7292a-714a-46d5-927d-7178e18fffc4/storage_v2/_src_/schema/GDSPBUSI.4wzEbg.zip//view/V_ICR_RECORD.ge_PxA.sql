create view V_ICR_RECORD as
SELECT
  id,
  task_id,
  apply_no,
  cert_type,
  NVL2(cert_no,SUBSTR(cert_no, 1, 2) || '****' || SUBSTR(cert_no, 7, 8) || '**'||SUBSTR(cert_no,17),'' ) cert_no,
  customer_name,
  query_reason,
  user_id,
  report_validdays,
  system_code,
  query_accessstrategy,
  icr_req_time,
  icr_res_time,
  icr_res_status,
  icr_res_msg,
  icr_req_path,
  icr_res_path,
  icr_report_time,
  icr_report_no,
  is_valid,
  is_del,
  create_time,
  update_time,
  create_year_month,
  putoutapprove_no,
  phase







FROM GDSPBUSI.GDTP_ICR_RECORD
/

