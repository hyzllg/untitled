create view V_LLAS_BIZ_RETAIL_SALES_REPORT as
SELECT
    b.serial_no,
    a.policyid,
    a.customer_name,
    a.customer_source,
    c.appointment_branch_name,
    c.city_branch,
    b.appointment_date,
    b.order_date,
    b.order_time,
    b.order_status,
    c.appointment_memo,
    a.apply_date,
    a.business_sum,
    a.app_status,
    a.account_type,
    b.business_type,
    a.init_record_time,
    a.end_date,
    a.approve_amount,
    a.ilog_rate,
    a.main_reason,
    a.sign_date,
    case
        when a.business_type = '707001' and a.apply_stage in ('0101','0102','0202','0203') then null
        when a.business_type = '707001' and a.apply_stage in ('0201','0301','0302','0303','0304','0300') then to_char((to_number(a.approve_sum)),'fm999999999990.00')
        when a.review_view is null then to_char(a.sign_amount, 'fm9999999990.00')
        else to_char(a.review_amount, 'fm9999999990.00')
    end sign_amount,
    a.bank_date,
    a.int_final_amount,
    a.cooperation_bank,
    a.repay_type,
    a.term_month,
    a.first_user_name,
    a.sales_user_name,
    a.sales_user_id,
    a.sales_director_name,
    a.sales_director
FROM
    llas_biz_apply_integration_info a,
    llas_biz_retail_sales_apply b,
    llas_biz_org_info c
WHERE
        a.inside_app_no = b.inside_app_no
    AND
        b.inside_app_no = c.inside_app_no (+)
/

