create procedure updateComSearch(applyNo in varchar2,applyStage in varchar2)
as
begin
  update gdspbusi.llas_biz_apply_com_search set apply_stage=applyStage,lst_Upd_Date=sysdate,lst_Upd_time=sysdate where apply_no=applyNo;
  commit;
  Dbms_Output.put_line('更新成功');
end;

/

