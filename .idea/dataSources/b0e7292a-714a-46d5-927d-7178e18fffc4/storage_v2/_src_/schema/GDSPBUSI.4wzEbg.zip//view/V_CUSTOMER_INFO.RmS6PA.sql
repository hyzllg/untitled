create view V_CUSTOMER_INFO as
select
a.apply_no  申请编号,
a.input_org_name 签约机构,
a.CUSTOMER_SOURCE 客户来源,
a.sales_user_id 业务员工号,
a.sales_user_name 业务员姓名,
a.sales_director 业务主任工号,
a.sales_director_name 业务主任姓名,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_TermMonth' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.term_month ) 贷款期数,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_BAAccountType' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.account_type ) 账户类型,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_YesNo' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.is_native ) 是否本地户籍,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeP' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.NATIVE_PROVINCE ) 户口地址省,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeC' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.NATIVE_CITY )  户口地址市,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeD' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.NATIVE_DISTRICT ) 户口地址区,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeP' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.FAMILY_PROVINCE ) 住宅地址省,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeC' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.FAMILY_CITY ) 住宅地址市,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeD' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.FAMILY_DISTRICT ) 住宅地址区,
a.SELF_WORK_CORP 工作单位,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_Industry' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.SELF_INDUSTRY_CODE ) 行业代码,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeP' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.SELF_WORK_PROVINCE ) 单位具体地址省,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_AreaCodeC' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=a.SELF_WORK_CITY ) 单位具体地址市,
a.business_type 业务种类,
a.customer_id 客户号,
a.customer_name 客户姓名,
(to_char(sysdate, 'yyyy') - substr(a.id_number, 7, 4)) 年龄,
a.business_type_name 产品类型,
a.channel_name 渠道,
c.FIRST_APPROVER 初审,
c.SECOND_APPROVER 终审,
c.GROUP_APPROVER 组长,
h.INT_FINAL_AMOUNT 银行放贷金额,
h.SIGN_CUSTOMER 远程面签员,
h.REVIEWER 远程面签复核,
d.TEST_AMOUNT 系统建议金额,
d.PERIOD_AMOUNT 签约月供,
e.policyid 保单号,
f.CONTRACTNO 合同号,
to_char(f.bank_date,'yyyy/mm/dd') 放款日期,
(select d1.DICT_DETAIL_NAME from gdspbusi.llas_ap_dict_detail d1 ,gdspbusi.llas_ap_dict d2 where d1.dict_id=d2.dict_id and d2.dict_code='ZD_RemarkStage' and d1.REC_STATUS='1'and d1.ISINUSE='1' and d1.dict_detail_code=g.apply_stage ) 当前阶段,
b.sale_org_name 销售机构,
org.org_name 归属分部,
a.crt_time
from gdspbusi.llas_biz_business_apply a
left join gdspbusi.llas_biz_org_info b on a.inside_app_no=b.inside_app_no and b.rec_status='1'
left join gdspbusi.llas_biz_approval c on a.inside_app_no=c.inside_app_no and c.rec_status='1'
left join gdspbusi.llas_biz_quota d on a.inside_app_no=d.inside_app_no and d.rec_status='1'
left join gdspbusi.llas_biz_insurancepolicy e on a.inside_app_no = e.inside_app_no and e.rec_status='1'
left join gdspbusi.llas_biz_loan_manage f on a.inside_app_no = f.inside_app_no
left join gdspbusi.llas_biz_apply_com_search g on a.inside_app_no=g.inside_app_no and g.rec_status='1'
left join gdspbusi.llas_biz_interview h on a.inside_app_no=h.inside_app_no and h.rec_status='1'
left join gdspbusi.llas_sys_org o on a.input_org_id = o.org_code and o.rec_status='1'
left join gdspbusi.llas_sys_org org on o.parent_id = org.org_code and o.rec_status='1'
/

