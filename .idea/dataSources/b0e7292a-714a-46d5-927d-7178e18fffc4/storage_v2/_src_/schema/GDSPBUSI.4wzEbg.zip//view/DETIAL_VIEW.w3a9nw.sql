create view DETIAL_VIEW as
select ID,ILOG_ID,REASON_CODE,EFFECT_TIME FROM llas_biz_ilog_ta_undrt_detial
/

