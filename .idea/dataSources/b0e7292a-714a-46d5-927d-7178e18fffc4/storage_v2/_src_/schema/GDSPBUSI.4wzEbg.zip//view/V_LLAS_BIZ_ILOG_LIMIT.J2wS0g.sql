create view V_LLAS_BIZ_ILOG_LIMIT as
SELECT
    apply_no,
    custidentifica,
    custidentificb,
    crt_date
FROM
    llas_biz_ilog_limit
/

