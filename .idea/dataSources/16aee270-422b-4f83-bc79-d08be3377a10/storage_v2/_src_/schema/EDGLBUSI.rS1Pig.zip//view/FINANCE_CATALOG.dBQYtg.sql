create view FINANCE_CATALOG as
SELECT
    remark as REMARK,
    modeltype as REPORTTYPE,
    modelno as REPORTNO,
    modelname as REPORTNAME,
    modeldescribe as REPORTDESCRIBE,
    modelclass as BELONGINDUSTRY,
    modelabbr as REPORTABBR,
    headermethod as HEADERMETHOD,
    displaymethod as DISPLAYMETHOD,
    deleteflag as DELETEFLAG,
    attribute1 as ATTRIBUTE1,
    attribute2 as ATTRIBUTE2
FROM
    report_catalog
/

