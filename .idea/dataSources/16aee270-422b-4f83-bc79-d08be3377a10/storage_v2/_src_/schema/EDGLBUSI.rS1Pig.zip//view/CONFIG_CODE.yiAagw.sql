create view CONFIG_CODE as
select CODENO,ITEMNO,SORTNO,ITEMNAME, ATTRIBUTE1 as VALUE,ISINUSE,CREATE_DATE,UPDATE_DATE
 from code_library
 where codeno in ('RelationShip','BankNo','LOAN_USE','Occupation','OtherBasics')
 union all
 select 'OtherBasics' as CODENO,
        'FaceNumber' as ITEMNO,
        SORTNO,
        '人脸识别次数' as ITEMNAME,
        ITEMATTRIBUTE as VALUE,ISINUSE,CREATE_DATE,UPDATE_DATE
 from code_library
 where codeno in ('PersonValue')
 union all
 select 'OtherBasics' as CODENO,
        'BankNumber' as ITEMNO,
        SORTNO,
        '银行卡鉴权次数' as ITEMNAME,
        ITEMATTRIBUTE as VALUE,ISINUSE,CREATE_DATE,UPDATE_DATE
 from code_library
 where codeno in ('CardAuthTime')
/

