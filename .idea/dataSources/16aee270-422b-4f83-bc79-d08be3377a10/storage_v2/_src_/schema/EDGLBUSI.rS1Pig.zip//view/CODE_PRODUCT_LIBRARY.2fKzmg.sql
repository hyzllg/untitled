create view CODE_PRODUCT_LIBRARY as
select p.productid,
       'Periods' as itemno,
       '还款期数' as itemname,
       to_char(p.term) as value,
       update_date,
       create_date
  from product_config_info p
   union all
   select p.productid,
       'FirstWithDrawMoney' as itemno,
       '首次最低提现金额' as itemname,
       to_char(p.FIRSTDRAWAMT) as value,
       update_date,
       create_date
  from product_config_info p
    union all
   select p.productid,
       'Rate' as itemno,
       '利率' as itemname,
       to_char(p.businessrate) as value,
       update_date,
       create_date
  from product_config_info p
    union all
   select p.productid,
       'DefaultPeriod' as itemno,
       '默认期数' as itemname,
       to_char(p.DEFAULTTERM) as value,
       update_date,
       create_date
  from product_config_info p
    union all
   select p.productid,
       'ApplyTime' as itemno,
       '申请有效期天数' as itemname,
       to_char(p.APPLYTIME) as value,
       update_date,
       create_date
  from product_config_info p
    union all
   select p.productid,
       'RedelegationTime' as itemno,
       '重新授权天数' as itemname,
       to_char(p.RedelegationTime) as value,
       update_date,
       create_date
  from product_config_info p
  union all
   select p.productid,
       'MinWithDrawMoney' as itemno,
       '非首次最低提现金额' as itemname,
       to_char(p.MINDRAWAMT) as value,
       update_date,
       create_date
  from product_config_info p
  union all
   select p.productid,
       'GraceDays' as itemno,
       '宽限期天数' as itemname,
       to_char(p.GraceDays) as value,
       update_date,
       create_date
  from product_config_info p
  union all
  select p.productid,
       'FirstLimitDays' as itemno,
       '提额有效天数' as itemname,
       to_char(p.firstlimitdays) as value,
       update_date,
       create_date
  from product_config_info p
  union all
  select p.productid,
       'LimitChangeDays' as itemno,
       '提额间隔天数' as itemname,
       to_char(p.UPDATELIMITDAYS) as value,
       update_date,
       create_date
  from product_config_info p
  union all
  select p.productid,
       'MaxLimit' as itemno,
       '产品最高额度' as itemname,
       to_char(p.maximumcreditlimit) as value,
       update_date,
       create_date
  from product_config_info p
/

