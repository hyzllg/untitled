create view V_ACCT_RECOVERY_LOSS as
select baserialno,SERIALNO,crederefinishdate,UPDATED_DATE,OVERDUEFINEBEGINDATE,PAYCREDERE
from acct_recovery_loss
/

