create function          GETworkTIME2(serialnoArg in varchar2)
return varchar2
is signtime varchar2(20) ;
begin
select round( Months_Between(SYSDATE,to_date(nvl(ft.START_DATE,ft.SETUPDATE),'yyyy/MM/dd'))) into signtime
  from customer_work ft
 WHERE  ft.customerid = serialnoArg;
   if signtime is not null then
     if(signtime<=3) THEN SIGNtime:='1' ;
     ELSIF (3<signtime AND signtime<=6) THEN signtime:='2' ;
       ELSIF (6<signtime AND signtime<=12) THEN signtime:='3';
         ELSIF(12<signtime AND signtime<=24) THEN signtime:='4' ;
           ELSIF(24<signtime AND signtime<=36) THEN signtime:='5' ;
             ELSIF (signtime>36) THEN signtime:='6' ;

     else signtime:='1' ;
     end if;
   end if;
  return signtime;
END  GETworkTIME2;


/

