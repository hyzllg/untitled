create function getreasontype(opinionnoArg in varchar2)
--获取原因类型
return varchar2
is
  reasontype varchar2(50);
begin
    select distinct reasontype into reasontype
  from reason_param rp, flow_opinion fo
 where rp.phaseno = fo.phaseno
   and rp.Mainreasoncode = fo.Reasoncode1
   and nvl(rp.Subreasoncode,'Null') = nvl(fo.Reasoncode2,'Null')
   and fo.opinionno = opinionnoArg;

  return(reasontype);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getreasontype;

/

