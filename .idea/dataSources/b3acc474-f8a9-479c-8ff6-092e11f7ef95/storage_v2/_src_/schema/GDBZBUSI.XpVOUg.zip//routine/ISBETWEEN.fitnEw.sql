create function ISBETWEEN(pObject in number, pType IN VARCHAR2,pLeft in number, pRight in number)
return integer
is
-------------------------------------------------
--判断对象数值是否在由pNum1~pNum2指定的区间内
--RINK 2004-11-8
-------------------------------------------------
 v_Result integer;
begin
 v_Result := 0;
 if(pObject<pRight and pObject>pLeft) THEN v_Result := 1;
 END IF ;
 if((pType='01' or pType='03') and pObject = pLeft) then v_Result := 1;
 end if;
 if((pType='02' or pType='03') and pObject=pRight) then v_Result := 1;
 end if;

 return(v_Result);

end ISBETWEEN;
/

