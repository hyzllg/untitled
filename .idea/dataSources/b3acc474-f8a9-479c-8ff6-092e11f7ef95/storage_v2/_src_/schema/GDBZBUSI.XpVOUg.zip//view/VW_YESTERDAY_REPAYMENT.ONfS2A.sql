create view VW_YESTERDAY_REPAYMENT as
SELECT t.baserialno,
        SUM(NVL(t.actualpaycorpusamt, 0) + NVL(t.actualpayinteamt, 0) +
            NVL(t.actualfineamt, 0) + NVL(t.actualpayfeeamt1, 0)) AS yesterdayTotalPayAmt,
        SUM(NVL(t.actualpaycorpusamt, 0)) AS yesterdayPayCorpusAmt,
        SUM(NVL(t.actualpayinteamt, 0)) AS yesterdayPayInteAmt,
        SUM(NVL(t.actualfineamt, 0)) AS yesterdayFineAmt,
        SUM(NVL(t.actualpayfeeamt1, 0)) AS yesterdayPayFeeAmt1
   FROM acct_back_detail t
  WHERE t.actualpaydate >= to_char(TRUNC(SYSDATE - 1), 'yyyy/mm/dd')
    AND t.actualpaydate < to_char(TRUNC(SYSDATE), 'yyyy/mm/dd')
    AND t.paytype<>'6'
  GROUP BY t.baserialno
/

