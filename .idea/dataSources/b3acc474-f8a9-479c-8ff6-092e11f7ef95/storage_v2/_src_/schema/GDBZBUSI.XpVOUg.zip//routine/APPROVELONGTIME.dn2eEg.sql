create function          approvelongtime(serialnoArg in varchar2)
--审批总时效
 return varchar2

 is
  longtimes varchar2(30);
begin
  SELECT

   EXTRACT(DAY FROM (decode(getendsptime(serialnoArg),'',sysdate,to_date(getendsptime(serialnoArg),'YYYY/MM/DD HH24:MI:ss'))-to_date(getFHendtime(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'天'
   || EXTRACT(HOUR FROM (decode(getendsptime(serialnoArg),'',sysdate,to_date(getendsptime(serialnoArg),'YYYY/MM/DD HH24:MI:ss'))-to_date(getFHendtime(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'时'
   || EXTRACT(MINUTE FROM (decode(getendsptime(serialnoArg),'',sysdate,to_date(getendsptime(serialnoArg),'YYYY/MM/DD HH24:MI:ss'))-to_date(getFHendtime(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'分' into longtimes
FROM DUAL;
  return(longtimes);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end approvelongtime;

/

