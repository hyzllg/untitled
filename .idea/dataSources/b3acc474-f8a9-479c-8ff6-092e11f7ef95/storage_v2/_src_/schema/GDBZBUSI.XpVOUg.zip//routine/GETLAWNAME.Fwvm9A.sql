create function GetLawName(OutID in varchar2)
--获取法催厂商
return varchar2
is
  OutName varchar2(200);
begin
  select manuname
    into OutName
    from law_manufacturer om
   where om.manuid = OutID;
  return OutName ;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetLawName;
/

