create FUNCTION getriskrate(pSerialNo varchar)
return decimal
is pRiskRate  decimal;
begin
select RiskRate into pRiskRate
  from BUSINESS_CONTRACT
  where SerialNo=pSerialNo;
if pRiskRate is not null then
  return pRiskRate;
else
  return 0;
end if;
end;
/

