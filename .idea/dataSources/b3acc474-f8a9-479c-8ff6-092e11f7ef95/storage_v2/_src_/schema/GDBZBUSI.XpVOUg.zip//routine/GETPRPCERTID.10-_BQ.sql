create function getprpcertid(policynoArg in varchar2)
--通过保单号获取身份证号
return varchar2
is scertid varchar2(50);
begin
  select certid into scertid
         from customer_info where customerid=(
                                  select customerid from business_apply
                                  where policyno=policynoArg);

return scertid;
EXCEPTION
WHEN NO_DATA_FOUND THEN
return '';
WHEN OTHERS THEN
return '';
end getprpcertid;
/

