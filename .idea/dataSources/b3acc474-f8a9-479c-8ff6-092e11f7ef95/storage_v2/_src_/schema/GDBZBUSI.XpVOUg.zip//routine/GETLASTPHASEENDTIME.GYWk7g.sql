create function GetLastPhaseEndTime(ftserialnoArg in varchar2)
--找上一阶段结束时间
return varchar2
is lastphaseendtime  varchar2(200) ;
begin
   select endtime into lastphaseendtime from flow_task where serialno=ftserialnoArg ;
  return lastphaseendtime;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';

end GetLastPhaseEndTime;
/

