create function          GetEndResultApprove(serialnoArg in varchar2)
--获取最后审批结果
return varchar2
is approveendresult varchar2(200) ;
begin
  select case when endtime is not null and (phaseno='0040' or phaseno='0030' or phaseno='0047') then phasename||'通过'
              else phasename end into approveendresult
    from flow_task ft
   where serialno = (select serialno from (select serialno
                       from flow_task
                      where exists (select 1
                               from flow_task
                              where phaseno = '0030'
                                and objectno =serialnoArg  and flowno='CreditFlow')
                        and phaseno not in ('0050', '0070', '1000','2060','2050','2070','2010','2000','3030','2080','3080','2090','2095','3000','3060','3080','3070')
                        and objectno = serialnoArg and flowno='CreditFlow' order by begintime desc) where rownum=1) and objectno=serialnoArg and ft.flowno='CreditFlow';
  return approveendresult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetEndResultApprove;

/

