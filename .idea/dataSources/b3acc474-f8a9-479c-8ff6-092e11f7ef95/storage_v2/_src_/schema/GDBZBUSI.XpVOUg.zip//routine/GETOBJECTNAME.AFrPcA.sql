create function getobjectname(pObjectType varchar)
return varchar
is
pObjectName  varchar2(200);
begin
select ObjectName into pObjectName
from ObjectType_Catalog
where ObjectType=pObjectType;

if pObjectName is null then
  return pObjectType;
else
  return pObjectName;
end if;
end;
/

