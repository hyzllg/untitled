create FUNCTION getCWIndustryCode(sArgCustomerID varchar2)
return varchar2
is sIndustryCode  varchar(80);
begin
select industrycode into sIndustryCode from customer_work where customerid = sArgCustomerID;
return sIndustryCode;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

