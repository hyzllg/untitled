create function          GetRefuseMainReason(serialnoArg in varchar2)
--获取拒绝主原因(案件超时)
return varchar2
is refuseMainReason  varchar2(200) ;
begin
  select phaseno into refuseMainReason from flow_object where objectno=serialnoArg;
  if refuseMainReason = '2080' then select phasename into refuseMainReason from flow_object where objectno=serialnoArg ;
  else
  select phaseopinion1 into refuseMainReason
  from flow_opinion
 where serialno = (select max(serialno)
                     from flow_opinion
                    where (phasechoice like '%未通过%' or phasechoice like '%拒绝%' or phasechoice='不符合追加贷条件')
                      and nvl(reasoncode1,'0')<>'0'
                      and objectno=serialnoArg) AND objectno=serialnoArg;
  end if;
  return refuseMainReason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetRefuseMainReason;

/

