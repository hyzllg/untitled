create function  getpaydate2(serialnoArg in varchar2)
--获得应还款日
return varchar2
is
  paydate varchar2(20);
begin
  select substr(min(paydate),9,10)
    into paydate
    from acct_payment_schedule
   where baserialno = serialnoArg;
  return(paydate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getpaydate2;
/

