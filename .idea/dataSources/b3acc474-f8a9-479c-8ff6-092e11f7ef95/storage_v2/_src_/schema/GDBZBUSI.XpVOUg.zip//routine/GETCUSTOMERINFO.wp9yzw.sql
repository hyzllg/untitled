create FUNCTION getCustomerInfo(pCustomerID varchar,pType varchar)
return varchar
is pResult  varchar(80);
begin
  if pType='10' then
select p.certtype into pResult from customer_info p where p.CustomerId = pCustomerID;
elsif pType='20' then
  select p.countrytype into pResult from customer_info p where p.CustomerId = pCustomerID;
elsif pType='30' then
  select p.certidisinuse into pResult from customer_info p where p.CustomerId = pCustomerID;
elsif pType='40' then
  select p.certidstardate into pResult from customer_info p where p.CustomerId = pCustomerID;
elsif pType='50' then
  select p.certidenddate into pResult from customer_info p where p.CustomerId = pCustomerID;
end if;
return pResult;
end;

/

