create FUNCTION GETNEWAPPROVEBASERIALNO(PSERIALNO varchar)
return varchar
is  pnewapprovebaserialno  varchar(200);
begin
  pnewapprovebaserialno:='';
  select newapprovebaserialno into pnewapprovebaserialno
  from business_apply
  where serialno =PSERIALNO;
  return pnewapprovebaserialno;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return PSERIALNO;
  WHEN OTHERS THEN
  return PSERIALNO;
end;
/

