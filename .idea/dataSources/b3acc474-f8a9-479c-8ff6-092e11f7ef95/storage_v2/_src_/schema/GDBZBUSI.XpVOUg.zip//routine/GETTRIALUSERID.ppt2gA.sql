create function          GetTrialUserID(serialnoArg in varchar2)
--获取初审人员id
return varchar2
is TrialUserName  varchar2(200) ;
begin
   select userid into TrialUserName
     from flow_task
    where phaseno in ('0030','0035') and flowno='CreditFlow'
      and serialno =
          (select max(serialno)
             from flow_task where phaseno in ('0030','0035') and objectno = serialnoArg and flowno='CreditFlow');
  return TrialUserName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetTrialUserID;

/

