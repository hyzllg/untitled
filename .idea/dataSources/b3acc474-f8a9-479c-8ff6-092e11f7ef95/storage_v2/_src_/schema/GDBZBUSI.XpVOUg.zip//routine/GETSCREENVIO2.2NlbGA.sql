create FUNCTION          GETSCREENVIO2 (vid  VARCHAR2) RETURN VARCHAR2
IS

  leh    number;
  screen varchar2(80);
  r      varchar2(80);


BEGIN
leh := length(vid);
  screen := '********************';
  if (leh = 18 or leh = 19 or leh = 16) then
    r := substr(vid, 0, 4) || substr(screen, 0, leh - 6) || substr(vid, leh - 1, 1)||substr(screen, 0, 1);
  end if;
	RETURN r;
END;
/

