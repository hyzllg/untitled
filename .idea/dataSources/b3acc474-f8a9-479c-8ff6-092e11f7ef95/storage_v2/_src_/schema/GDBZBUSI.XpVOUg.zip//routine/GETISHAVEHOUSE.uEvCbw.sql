create function getIsHaveHouse(customeridArg in varchar2)
return varchar2
is IsHaveHouse varchar2(200) ;
begin
  select case
           when (select count(*)
                   from customer_realty
                  where customerid = customeridArg) > 0 then
            '有'
           else
            '无'
         end into IsHaveHouse from dual ;
  return IsHaveHouse;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getIsHaveHouse;
/

