create function          backreason1time(serialnoArg in varchar2)
--初审回退门店时间
return varchar2
is
 flag varchar2(10);
 times varchar2(30);
begin
  select getistrialback(serialnoArg) into  flag from dual;
  if flag ='是' then
    select f.begintime into times from flow_task f where f.serialno=
  (  select max(ft.serialno)
                   from flow_task ft
                  where ft.objectno =serialnoArg
                    and ft.phaseno = '0012'
                    and ft.flowno = 'CreditFlow');
  else
    select '' into times from dual;
  end if;
  return(times);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end backreason1time;

/

