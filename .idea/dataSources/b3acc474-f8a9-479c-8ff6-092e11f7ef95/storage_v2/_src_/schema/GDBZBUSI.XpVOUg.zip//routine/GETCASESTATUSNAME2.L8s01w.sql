create FUNCTION          getCaseStatusName2(sResult varchar)
--获取审批结果
return varchar
is sStatusName varchar(200);
begin
   select case
               when sResult in ('初审','终审','组长','组长回退终审','终审回退初审') then '中央审批中'
               when sResult in ('初审拒绝','终审拒绝','组长拒绝') then '审批拒绝'
               when sResult in ('初审通过','终审通过','初审通过') then '审批通过'
               else sResult
          end
          into sStatusName from dual;
   if sStatusName is not null then
      return sStatusName;
   else
       return '';
   end if;
end;

/

