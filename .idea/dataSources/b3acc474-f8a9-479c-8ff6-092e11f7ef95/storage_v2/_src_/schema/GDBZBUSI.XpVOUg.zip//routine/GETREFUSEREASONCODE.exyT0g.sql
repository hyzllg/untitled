create function GetRefuseReasonCode(serialnoArg in varchar2)
--获取拒绝原因码
return varchar2
is refuseReasonCode   varchar2(200) ;
begin
   /*有坑逼面签不更新flow_opinion原因码只更新ba的*/
   /*flow_opinion没有时改为从ba取*/
 select (case nvl(p2.reasoncode2,'1') when '1' then  p2.reasoncode1
 else  p2.reasoncode1||'.'||p2.reasoncode2 end) into refuseReasonCode
   from  (select p.reasoncode1,p.reasoncode2 from flow_opinion p
  where p.objectno=serialnoArg and (phasechoice like '%未通过%' or phasechoice like '%不符合%' or phasechoice like '%拒绝%') and reasoncode1 is not null order by p.updatetime desc) p2 where rownum=1;
return refuseReasonCode;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
   select replace(substr(reasoncode,3),'@','.') into refuseReasonCode from business_apply ba where ba.serialno=serialnoArg and length(reasoncode) >3;
   return refuseReasonCode;
 WHEN OTHERS THEN
  return '';
end GetRefuseReasonCode;
/

