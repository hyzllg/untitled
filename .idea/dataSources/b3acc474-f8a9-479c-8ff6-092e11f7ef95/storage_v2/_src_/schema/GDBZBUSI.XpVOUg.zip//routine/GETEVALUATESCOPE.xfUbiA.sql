create function getevaluatescope(pObjectNo varchar,pReportDate varchar)
return varchar
is
pReturnValue varchar(10);
pReportScope varchar(10);
iCount1 INT;
iCount2 INT;
iCount3 INT;
cursor my_cursor is select ReportScope From REPORT_RECORD
 where ObjectType='CustomerFS'
 and ObjectNo=pObjectNo
 and ReportDate=pReportDate
 and ModelNo like '%9';
begin
iCount1 := 0;
iCount2 := 0;
iCount3 := 0;
open my_cursor;
     loop
         fetch my_cursor into pReportScope;
         exit when my_cursor %notfound;
         if pReportScope='01' then
          iCount1 := iCount1 + 1;
         end if;

         if pReportScope='02' then
           iCount2 := iCount2 + 1;
         end if;

         if pReportScope='03' then
           iCount3 := iCount3 + 1;
         end if;
     end loop;
close my_cursor;
if iCount1 > 0 then
   pReturnValue := '01';
elsif iCount2 > 0 then
   pReturnValue := '02';
elsif iCount3 > 0 then
   pReturnValue := '03';
end if;
return pReturnValue;

END;
/

