create FUNCTION          getmentionFraud(baserialno VARCHAR2)
--反欺诈标识
RETURN VARCHAR2
IS mentioncheat VARCHAR2(2);
BEGIN
SELECT
  CASE WHEN COUNT(1)>0 THEN '1'
  ELSE '2'
  END
   INTO mentioncheat FROM MentionFraud_info mi WHERE mi.objectno=baserialno and nvl(mi.ismentionedfraud,'N') in ('Y','R') and mi.isinuse='1' AND inveresult IS NOT NULL;
   RETURN mentioncheat;
END;

/

