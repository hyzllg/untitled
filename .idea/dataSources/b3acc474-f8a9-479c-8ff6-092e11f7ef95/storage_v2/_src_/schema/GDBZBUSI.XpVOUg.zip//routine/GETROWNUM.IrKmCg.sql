create function getrownum   
return varchar2 
is cursor tablenmae is select table_name from user_tables order by table_name;
 srow varchar2(2000);
sss varchar2(2000);
ss number ;
ssss varchar2(2000);
 begin
 ssss:='';
  FOR counter in tablenmae LOOP  
    ss:=0;
    srow:=  'select count(1) from '||counter.table_name;
    execute immediate srow into ss;
    sss:=ss||'@';
    ssss:=ssss||sss;
END LOOP; 
 
  return ssss;
end getrownum;
/

