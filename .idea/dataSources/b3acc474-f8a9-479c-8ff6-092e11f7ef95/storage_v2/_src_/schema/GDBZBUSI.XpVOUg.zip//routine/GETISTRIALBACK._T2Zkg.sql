create function          getistrialback(serialnoArg in varchar2)
--初审是否回退门店
return varchar2
 is
  YesOrNo varchar2(2);
begin
  select case
           when (select count(*)
                   from flow_task
                  where objectno =serialnoArg
                    and phaseno = '0012'
                    and flowno = 'CreditFlow') > 0 then
            '是'
           else
            '否'
         end
    into YesOrNo
    from dual;
  return(YesOrNo);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getistrialback;

/

