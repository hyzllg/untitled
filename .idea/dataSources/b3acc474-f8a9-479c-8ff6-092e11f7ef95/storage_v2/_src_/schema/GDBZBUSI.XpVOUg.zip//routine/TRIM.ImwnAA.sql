create FUNCTION trim
(
   pValue VARCHAR2
)
RETURN VARCHAR2
IS
v_Result			VARCHAR2(600);
BEGIN
v_Result :=	 ltrim(rtrim(pValue));
return v_Result;
END
;
/

