create PROCEDURE  proc_stu (sObjectNo in varchar2) as
Begin
  delete from flow_object where objectno=sObjectNo;
  update ds_business_apply set approvesum=(select approvesum from business_apply where serialno=sObjectNo) where objectno=sObjectNo;
  commit;
end;
/

