create FUNCTION getcustomernamebyapply(pSerialNo varchar)
return varchar
is pCustomerName  varchar(60);
begin
select  nvl(customername,'')  into pCustomerName
from business_apply
where SerialNo=pSerialNo;
return pCustomerName;
end;
/

