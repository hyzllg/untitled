create view V_ACCI_REPORT as
select ia.serialno,
        ia.applyno,
        decode(ia.producttype,'1','个人版','2','家庭版','个人版') as producttype,
        nvl(ba.channelname, '直销') as channelname,
        decode(ia.INSURETYPE, '0', '线上', '线下') as type,
        (case
          when cred.insertType is not null then
           cred.insertType
          when nvl(ba.channelcode, 'NULL') = 'ZYApp' then
           'APP'
          when nvl(cred.PROJECTMODE, 'NULL') = 'O2O' then
           'O2O'
          else
           'PC'
        end) as channelType,
        ia.customername,
        ia.certid,
        substr(ia.certid, 0, 6) || '*********'||substr(ia.certid,length(ia.certid)-2,3) as certid2,
        getitemname('CusmStatus', ia.insurestatus) as insurestatus1,
        ia.insurestatus,
        ia.term / 12 as term,
        ia.insurance,
        ia.paymentmethod,
        to_char(ia.premiumrate, 'FM990.00000') as premiumrate,
        ia.premiumamount,
        nvl(ia.beforeVatPremium,round(ia.premiumamount/1.06,2)) as mount,
        ia.accidentpolicyno,
        ba.NEWAPPROVEBASERIALNO as applynoA,
        ia.ensurepolicyno,
        substr(replace(ia.insurebegindate, '-', '/'), 1, 10) as insurebegindate1,
        substr(replace(ia.insureenddate, '-', '/'), 1, 10) as insureenddate,
        substr(ENDORSENOBEGINTIME, 1, 10) as accidentcanceldate,
        (CASE
          WHEN ba.INPUTORGID is null THEN
           ''
          else
           (select oi.ZOOORGNAME from org_info oi WHERE ba.INPUTORGID = oi.orgid )
        end) as BELONGAREANAME,
        GETBELONGORGNAME(ia.ORGID) as belongorgName,
        ia.orgname,
        decode(instr(ba.channelname,'渠道'),0,ba.salesusername, (case when ba.agentuserid=ba.salesuserid then ba.salesusername else getusername(ba.agentuserid) end) ) as SALESUSERNAME,
        decode(instr(ba.channelname,'渠道'),0,ba.salesuserid,ba.agentuserid) as SALESUSERID,
        (case when ba.agentuserid=ba.salesuserid then ba.salesusername else getusername(ba.agentuserid) end) as agentusername,
        ba.agentuserid,
        ia.username as user_name,
        ia.userid as user_id,
        ia.useraward,
        '0' as isemployee,
        ia.orgid as orgid,
        ba.SALESORGID as SALESORGID,
        ia.riskcode,
        ia.property_org_id
   from insure_apply     ia,
        business_apply   ba,
        org_info         org,
        creditaudittable cred
  where ia.applyno = ba.serialno
    and ia.ORGID = org.orgid
    and ia.applyno = cred.serialno(+)
    and ia.register_no is null
    and ia.insurestatus in ('1', '2', '3', '4', '5')
    UNION ALL
     select ia.serialno,
         ia.applyno,
         decode(ia.producttype,'1','个人版','2','家庭版','个人版') as producttype,
         '线上获客' as channelname,
         '线上' as type,
        '' as channelType,
        ia.customername,
        ia.certid,
        substr(ia.certid, 0, 10) || '*****' || substr(ia.certid, 16, 18) as certid2,
        getitemname('CusmStatus', ia.insurestatus) as insurestatus1,
        ia.insurestatus,
        ia.term / 12 as term,
        ia.insurance,
        ia.paymentmethod,
        to_char(ia.premiumrate, 'FM990.00000') as premiumrate,
        ia.premiumamount,
        nvl(ia.beforeVatPremium,round(ia.premiumamount/1.06,2)) as mount,
        ia.accidentpolicyno,
        '' as applynoA,
        '' as ensurepolicyno,
        substr(replace(ia.insurebegindate, '-', '/'), 1, 10) as insurebegindate1,
        substr(replace(ia.insureenddate, '-', '/'), 1, 10) as insureenddate,
        substr(ENDORSENOBEGINTIME, 1, 10) as accidentcanceldate,
        nvl((select oi.ZOOORGNAME from user_info ui,org_info oi WHERE ui.BELONGORG = oi.orgid and ui.userid = apr.referrerid ),
        nvl( ( SELECT ZOOORGNAME FROM org_info oi WHERE oi.belongorgid =aom.orgid and ZOOORGNAME is not null and rownum=1) ,'') ) as BELONGAREANAME,
        nvl((select GETORGNAME(oi.belongorgid) from user_info ui,org_info oi WHERE ui.belongorg=oi.orgid and ui.userid = apr.referrerid),
        GETORGNAME(aom.orgid)) as belongorgName,
        '' as orgname,
        '' as SALESUSERNAME,
        '' as SALESUSERID,
        getusername(apr.referrerid) as agentusername,
        apr.referrerid as agentuserid,
        '' as user_name,
        '' as user_id,
        ia.useraward as useraward,
        nvl(apr.isemployee,'0') as isemployee,
        ia.orgid as orgid,
        '' as SALESORGID,
        ia.riskcode,
        ia.property_org_id
   from
        acci_person_register apr,
        insure_apply     ia left join accidentinsurance_org_map aom on  ia.property_org_id=aom.maporgid and aom.orglevel='13'
  where ia.register_no = apr.serialno
        and ia.insurestatus in ('1', '2', '3', '4', '5')
/

