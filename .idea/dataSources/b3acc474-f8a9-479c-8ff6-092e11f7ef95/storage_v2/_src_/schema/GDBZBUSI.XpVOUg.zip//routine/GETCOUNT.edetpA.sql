create FUNCTION getCount(pObjectno varchar)
--获取累计逾期期次
return varchar
is  pCountOverstage  varchar(20);
begin
  select count(*) into pCountOverstage from acct_payment_schedule where paydate < nvl(finishdate,to_char(sysdate,'yyyy/MM/dd')) and objectno = pObjectno  ;
  return pCountOverstage;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

