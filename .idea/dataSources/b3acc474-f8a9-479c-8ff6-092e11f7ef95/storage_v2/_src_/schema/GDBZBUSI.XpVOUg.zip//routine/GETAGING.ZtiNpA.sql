create function getaging(pi_serial_no  in varchar2,
                                    pi_table_name in varchar2,
                                    pi_pk_name    in varchar2,
                                    pi_field_name in varchar2)
  return varchar2 is
  Result varchar2(30);
  v_sql  varchar2(460);
begin
  begin
    v_sql := 'SELECT EXTRACT(DAY FROM (sysdate - to_date(' || pi_field_name ||
             ',''YYYY/MM/DD HH24:MI:ss'')) DAY TO SECOND) || ''天''';
  
    v_sql := v_sql || ' || EXTRACT(HOUR FROM(sysdate - to_date(' ||
             pi_field_name ||
             ', ''YYYY/MM/DD HH24:MI:ss'')) DAY TO SECOND) || ''时''';
    v_sql := v_sql || ' || EXTRACT(MINUTE FROM(sysdate - to_date(' ||
             pi_field_name ||
             ', ''YYYY/MM/DD HH24:MI:ss'')) DAY TO SECOND) || ''分''';
    v_sql := v_sql || ' from ' || pi_table_name || ' where ' || pi_pk_name ||
             ' = ''' || pi_serial_no || '''';
  
    execute immediate v_sql
      into Result;
  exception
    when no_data_found then
      Result := '';
    when others then
      Result := '';
  end;

  return(Result);
end getaging;
/

