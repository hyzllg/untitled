create FUNCTION          getBelongGroup(pOrgid varchar2)
--获取组别
return varchar2
is  pBelongGroup  varchar2(200);
begin
	select TEAMNAME into pBelongGroup from urge_team_info where teamid=pOrgid;
  return pBelongGroup;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

