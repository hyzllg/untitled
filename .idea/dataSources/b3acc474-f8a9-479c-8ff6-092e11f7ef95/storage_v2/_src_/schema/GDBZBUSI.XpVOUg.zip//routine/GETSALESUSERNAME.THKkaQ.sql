create FUNCTION          getsalesusername(pSerialnoID varchar)
return varchar
is pSalesuserName  varchar(80);
begin
select SalesuserName into pSalesuserName
  from business_apply
where serialno = pSerialnoID;
  return pSalesuserName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

