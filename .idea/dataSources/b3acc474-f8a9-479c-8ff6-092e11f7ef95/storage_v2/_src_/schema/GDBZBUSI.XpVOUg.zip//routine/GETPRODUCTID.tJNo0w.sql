create FUNCTION          getProductID(pType varchar)
return varchar
is pResult  varchar(80);
begin
 select (case when  nvl(pType,'799999')='799999' then '799999'
    when pType='7001' then '799999'
    else pType  end) as productId into pResult from dual;
return pResult;
end;

/

