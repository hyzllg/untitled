create FUNCTION getattribute6(pCodeNo varchar,pItemNo varchar)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  select case when attribute6 is not null then attribute6 else itemno end into pItemName
  from Code_Library
  where CodeNo=pCodeNo and ItemNo=pItemNo;
  if pItemName is null then
            return pItemName;
  else
            return pItemName;
  end if;
end;
/

