create FUNCTION          getapprate(pSerialNO varchar2)
return varchar2
is pAppRate varchar2(80);
begin
select PREAPPROVERATE into pAppRate
from Creditaudittable
 where serialno = pSerialNO;
 return pAppRate;
end;

/

