create FUNCTION GETBELONGORGNAME(pOrgID varchar)
return varchar
is pOrgName varchar(80);
begin
select OrgName into pOrgName
from ORG_STATEMENT_INFO
 where Orgid = (select oi.belongorgid from ORG_STATEMENT_INFO oi where oi.orgid=pOrgID);
 return pOrgName;
end;
/

