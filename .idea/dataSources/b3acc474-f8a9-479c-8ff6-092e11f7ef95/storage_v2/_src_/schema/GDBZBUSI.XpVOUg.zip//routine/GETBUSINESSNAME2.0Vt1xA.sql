create FUNCTION          getbusinessname2(pPolicyno varchar)
return varchar
is pBusinessTypeName  varchar(80);
begin
	select TypeName into pBusinessTypeName
	from BUSINESS_TYPE
	where TypeNo=(SELECT BUSINESSTYPE from business_apply ba
                 where policyno = pPolicyno) ;
	return pBusinessTypeName;
end;

/

