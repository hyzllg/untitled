create FUNCTION "GETCHECKNAME2"(pSerialno varchar2)
--区分资金渠道切换新旧申请
return varchar2
is userName varchar2(200);
   newTaskNum number(1);
begin
	 select count(1) into newTaskNum from switchchannel_info where serialno=pSerialno;
	 if newTaskNum=0 then
	 		userName :='Old';
	 else
	 		userName :='New';
	 end if;
   return userName;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

