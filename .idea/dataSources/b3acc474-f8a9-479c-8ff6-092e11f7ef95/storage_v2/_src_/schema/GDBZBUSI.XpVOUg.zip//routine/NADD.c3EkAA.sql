create procedure nadd is
begin
for i in 1..10 loop
	insert into business_apply(serialno) values(i)
    /

