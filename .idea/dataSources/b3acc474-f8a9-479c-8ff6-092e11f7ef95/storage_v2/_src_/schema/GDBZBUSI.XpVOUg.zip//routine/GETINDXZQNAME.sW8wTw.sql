create FUNCTION getindxzqname(pCustomerID varchar2,pParams varchar2)
return varchar2
is  pAdd  varchar2(200);
begin
  if pParams='NATIVE' then
  select getitemname('AreaCodeP',NATIVEPROVINCE)||''||getitemname('AreaCodeC',NATIVECITY)||''||getitemname('AreaCodeD',NATIVEDISTRICT)||''||nativeplace into pAdd
  from ind_info where customerid=pCustomerID;
  elsif pParams='FAMILY' then
  select getitemname('AreaCodeP',FAMILYPROVINCE)||''||getitemname('AreaCodeC',FAMILYCITY)||''||getitemname('AreaCodeD',FAMILYDISTRICT)||''||familyadd into pAdd
  from ind_info where customerid=pCustomerID;
  else
  select '' into pAdd from dual;
  end if;
return pAdd;
end;
/

