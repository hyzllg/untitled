create FUNCTION GETCARDTYPE(pCustomerid varchar2)
    return varchar2
    is pCardType  varchar2(10);
    begin
      select CardType into pCardType from Card_Reader where customerid =pCustomerid;      
  return pCardType;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '0';
  WHEN OTHERS THEN
  return '0';
end;
/

