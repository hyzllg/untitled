create FUNCTION getcsorgname(pUserID varchar2)
return varchar2
is pOrgName varchar2(80);
begin
  select attribute4 into pOrgName
    from user_info
   where userID = pUserID;
 return pOrgName;
end;

/

