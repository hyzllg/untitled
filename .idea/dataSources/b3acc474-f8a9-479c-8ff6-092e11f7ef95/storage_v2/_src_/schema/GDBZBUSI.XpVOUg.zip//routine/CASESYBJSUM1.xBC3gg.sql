create function          casesybjsum1(idArg in varchar2,isinuseArg in integer,isguarantyArg in varchar2)
--获取某个厂商下所有案件剩余金额
return number is
  sybjsum number;
begin
  select sum(residualamount) into sybjsum
    from collection_info
   where collectionuserid = idArg
     and isinuse = isinuseArg and isguaranty= isguarantyArg;
  return(sybjsum);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end casesybjsum1;

/

