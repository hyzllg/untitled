create function getPURCHASESUM(CustomeridArg in varchar2) return varchar2 
--购车价格(元)
is
  cursor cur_m is select PURCHASESUM from CUSTOMER_VEHICLE where customerid = customeridArg order by serialno;
  purchasesums varchar2(400);
begin
  for cur_r in cur_m
    loop
       purchasesums:=cur_r.PURCHASESUM||' ;'||purchasesums;
       end loop;
  return(purchasesums);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN 
  return '';
end getPURCHASESUM;
/

