create function getPhaseNoByRelative(sRelativeSerialNo VARCHAR)
return varchar
is sPhaseNo VARCHAR(50);
begin
select phaseno into sPhaseNo from flow_task where serialno = sRelativeSerialNo;
return sPhaseNo;
end;
/

