create FUNCTION GETLASTPHASENO(pObjectType VARCHAR, pObjectNo VARCHAR, pSerialNo VARCHAR)
return varchar
is
sPhaseNo  varchar(32);
sRelativeSerialNo VARCHAR(48);
BEGIN

 SELECT aa.RelativeSerialNo INTO sRelativeSerialNo
 FROM (SELECT tt.* FROM (SELECT RelativeSerialNo,PhaseNo FROM Flow_Task WHERE ObjectType = pObjectType AND ObjectNo = pObjectNo AND SerialNo = pSerialNo ORDER BY SerialNo DESC)tt
where rownum=1) aa;

 SELECT PhaseNo INTO sPhaseNo FROM Flow_Task WHERE ObjectType = pObjectType AND ObjectNo = pObjectNo AND SerialNo = sRelativeSerialNo;

IF sPhaseNo = NULL THEN
 RETURN sPhaseNo;
ELSE
 RETURN sPhaseNo;
END IF;

END;
/

