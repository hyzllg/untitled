create function getLoanHouseSum(baSerialnoArg in varchar2)
--获取个人房贷总金额
return varchar2 
is LoanHouseSum varchar2(200) ;
begin
  select sum(nvl(F11,0)) into LoanHouseSum 
    from ICR_RPT_T40 irt, icr_cda icd 
   where F1 like '%房%' 
     and irt.rptno = icd.reportno 
     and icd.objectno = baSerialnoArg;
  return LoanHouseSum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getLoanHouseSum;
/

