create view V_Q2USER_PERFORMANCE_ADJUST as
select a.etl_mon,
        a.q2_employee_no,
        a.q2_employee_name,
        a.branch_name,
        a.com_name,
        a.basic_perf_amt,
        a.tb_perf_amt,
        a.overdue_perf_amt,
        0 as adjust_amt,
        a.due_amt as due_amt,
        a.employ_type
   from dm_cxq_q2user_performance a
   left join q2user_performance_adjust b
   on a.etl_mon = b.etl_mon and a.q2_employee_no = b.q2_employee_no
   where  b.q2_employee_no is null
    union all
  select a.etl_mon,
        a.q2_employee_no,
        a.q2_employee_name,
        a.branch_name,
        a.com_name,
        a.basic_perf_amt,
        a.tb_perf_amt,
        a.overdue_perf_amt,
        a.adjust_amt as adjust_amt,
        a.due_amt as due_amt,
        a.employ_type
   from
   q2user_performance_adjust a
/

