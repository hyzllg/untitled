create FUNCTION getMaxPayTerm(sobjectno varchar)
return NUMBER
is  mMaxPayTerm  NUMBER(20);
begin
  mMaxPayTerm:=0;
  select nvl(MAX(SEQID),0) into mMaxPayTerm
  from acct_payment_schedule pas
  where pas.baserialno=sobjectno and pas.ACTUALPAYFEEAMT1=pas.PAYFEEAMT1 and pas.PAYCORPUSAMT=pas.ACTUALPAYCORPUSAMT;
  return mMaxPayTerm;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end;

/

