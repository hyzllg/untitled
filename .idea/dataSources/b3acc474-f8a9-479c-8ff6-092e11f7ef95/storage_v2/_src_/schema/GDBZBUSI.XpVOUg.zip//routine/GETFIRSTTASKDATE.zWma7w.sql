create function          getfirsttaskdate(objectnoArg in varchar2)
--获单时间（初审）
return varchar2
is
  firsttaskdate varchar2(20);
begin
  select decode(nvl(STANDARDTIME1, 0),'0',flow_task.begintime,STANDARDTIME1) into firsttaskdate
    from flow_task
   where serialno = (select serialno from (select serialno
                       from flow_task
                      where objectno = objectnoArg
                        and phaseno = '0030' and flowno='CreditFlow'
                        and userid<>'OPS' order by begintime asc) where rownum=1);
  return(firsttaskdate);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfirsttaskdate;

/

