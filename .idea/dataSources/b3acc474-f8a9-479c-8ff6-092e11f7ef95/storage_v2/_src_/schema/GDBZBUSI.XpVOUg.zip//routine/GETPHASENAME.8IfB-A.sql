create FUNCTION getPhaseName( pFlowNo VARCHAR2, pPhaseNo VARCHAR2)
RETURN varchar2
is
pPhaseName varchar2(80);
BEGIN
select PhaseName into pPhaseName
from FLOW_MODEL where FlowNo = pFlowNo and PhaseNo = pPhaseNo ;
return pPhaseName;
END;
/

