create function GetBackReason(serialnoArg in varchar2)
--获取回退原因
return varchar2
is backReason  varchar2(200) ;
begin
  select mainreason||'-'||subreason into backReason from
(select distinct ra.mainreason ,fo.opinionno
  from reason_param ra, flow_opinion fo
 where reasontype = '20'
   and fo.phaseno = ra.phaseno
   and fo.reasoncode1 = ra.mainreasoncode
   --and fo.reasoncode2 = ra.subreasoncode
   and fo.opinionno = (select max(fo1.opinionno) from flow_opinion fo1 where objectno=serialnoArg)) a left join
   (select distinct ra.subreason ,fo.opinionno
  from reason_param ra, flow_opinion fo
 where reasontype = '20'
   and fo.phaseno = ra.phaseno
   --and fo.reasoncode1 = ra.mainreasoncode
   and fo.reasoncode2 = ra.subreasoncode
   and fo.opinionno = (select max(fo1.opinionno) from flow_opinion fo1 where objectno=serialnoArg)) b on a.opinionno=b.opinionno ;
  return backReason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetBackReason;
/

