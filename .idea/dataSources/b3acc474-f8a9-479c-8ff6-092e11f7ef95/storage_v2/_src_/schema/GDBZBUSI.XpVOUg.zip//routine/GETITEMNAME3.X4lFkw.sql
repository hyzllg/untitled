create FUNCTION getitemname3(pCodeNo varchar,pItemNo varchar)
return varchar
is  pItemName  varchar(200);
begin
	pItemName:='';
	select attribute5 into pItemName
	from Code_Library
	where CodeNo=pCodeNo and ItemNo=pItemNo;
	if pItemName is null then
            return pItemNo;
	else
            return pItemName;
	end if;
end;

/

