create function           GetTrialEndTime(serialnoArg in varchar2)
--获取初审结束时间
return varchar2
is TrialBeginTime  varchar2(200) ;
begin
   select endtime into TrialBeginTime
     from flow_task
    where flowno='CreditFlow'
      and serialno =
          (select max(serialno)
             from flow_task where phaseno in ('0030','0035') and objectno = serialnoArg and flowno='CreditFlow');
  return TrialBeginTime;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetTrialEndTime;


/

