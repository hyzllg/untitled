create view V_MAINDTO as
select ba.serialno,
       'EGZ' "planCode",
       'EGZ' "riskCode",
       'C' "language",
       '1' "policyType",
       '2' "policySort",
       '0201' "businessNature",
       (select formulaCode from QuotePrice) "formulaCode",
       to_char(sysdate + 1, 'yyyy-MM-dd') "startDate",
       to_number(to_char(sysdate, 'hh24')) "startHour",
       to_char(add_months(sysdate, ba.signterm) + 1, 'yyyy-MM-dd') "endDate",
       to_number(to_char(sysdate, 'hh24')) "endHour",
       '1' "sumQuantity",
       '1' "insuredCount",
       round(least(ba.signsum * (1 + 0.063 * ba.signterm / 12), 600000), 2) "sumAmount",
       round(least(round(nvl(ba.signsum, 0) *
                         (1 + 0.063 * ba.signterm / 12)),
                   600000) *
             (SELECT premiumrate / 100 from AccidentInsurance_Config) *
             ba.termmonth / 12,
             2) "sumPremium",
       'PLGI000001' "operateCode",
       'PLGI000001' "handlerCode",
       nvl(aom.maporgid, '000') "makeCom",
       nvl(aom.maporgid, '000') "comCode",
       '1' "jFeeFlag"
  from business_apply ba, accidentinsurance_org_map aom
 where aom.isinuse = '1'
   and ba.inputorgid = aom.orgid(+)
   order by  ba.serialno desc
/

