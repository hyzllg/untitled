create FUNCTION getstageBalance(pSerialno varchar2)
return varchar2
is pBalance  number(14,2);
begin
select (nvl(al.normalbalance, 0) + nvl(al.overduebalance, 0)) into pBalance
  from acct_loan al
where serialno = pSerialno;
  return pBalance;
end;

/

