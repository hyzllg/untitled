create FUNCTION getdaytime(timed Date)
return varchar
is  pItemName  varchar(20);
begin
  pItemName:=to_char(timed,'yyyy/mm/dd hh24:mi:ss') ;
  return pItemName;
end;

/

