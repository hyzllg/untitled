create FUNCTION getattachmentsum(sDocNo varchar)
return integer
is sAmount integer;
begin
    select count(*) into sAmount from DOC_ATTACHMENT
    where docno = sDocNo;
    return sAmount;
end;
/

