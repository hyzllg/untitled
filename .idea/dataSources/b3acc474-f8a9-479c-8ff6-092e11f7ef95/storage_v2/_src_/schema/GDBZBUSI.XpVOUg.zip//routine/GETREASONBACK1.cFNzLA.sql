create function          getreasonback1(serialnoArg in varchar2)
 return varchar2 is
  reasonback1 varchar2(100);
begin
  select nvl(ba.isapprovebackorg, '否')
    into reasonback1
    from business_apply ba
   where ba.serialno = serialnoArg;
  if reasonback1 = '是' then
    select phaseopinion1 || '-' || phaseopinion2
      into reasonback1
      from (select opinionno, phaseopinion1, phaseopinion2
              from flow_opinion
             where reasoncode1 is not null
               and phasechoice = '初审回退录入'
               and objectno = serialnoArg
             order by opinionno desc)
     where rownum = 1;
  else
    reasonback1 := '';
  end if;

  return reasonback1;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end getreasonback1;
/

