create function GetLast3MOverdueNum(serialnoArg in varchar2)
--人行信用卡近3个月的逾期次数
return varchar2
is creditCard3MOverNum1  varchar2(200) ;
creditCard3MOverNum2  varchar2(200) ;
creditCard3MOverNum3  varchar2(200) ;
begin 
  select sum(decode(irt41.f23, 'N', 0, 1)) + sum(decode(irt41.f24, 'N', 0, 1)) +
         sum(decode(irt41.f25, 'N', 0, 1)) into creditCard3MOverNum1  
    from icr_rpt_t41 irt41,icr_cda ic 
   where irt41.rptno=ic.reportno 
         and ic.objectno=serialnoArg ;
  select sum(decode(irt34.f23, 'N', 0, 1)) + sum(decode(irt34.f24, 'N', 0, 1)) +
         sum(decode(irt34.f25, 'N', 0, 1)) into creditCard3MOverNum2  
    from ICR_RPT_T34 irt34,icr_cda ic 
    where irt34.rptno=ic.reportno 
        and ic.objectno=serialnoArg ;
  select sum(decode(irt31.f23, 'N', 0, 1)) + sum(decode(irt31.f24, 'N', 0, 1)) +
         sum(decode(irt31.f25, 'N', 0, 1)) into creditCard3MOverNum3  
    from ICR_RPT_T31 irt31,icr_cda ic 
    where irt31.rptno=ic.reportno 
         and ic.objectno=serialnoArg ;
  return creditCard3MOverNum1+creditCard3MOverNum2+creditCard3MOverNum3 ;
  
 EXCEPTION 
   WHEN NO_DATA_FOUND THEN 
    return '';
  WHEN OTHERS THEN 
    return '';
end GetLast3MOverdueNum;
/

