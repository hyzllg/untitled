create FUNCTION getSADREFlowItems
(
   pStr in varchar2
)
RETURN  VARCHAR2
IS
v_Result varchar2(600);
v_idx   number;
v_curIdx number;
v_TempId varchar2(80);
v_Name   varchar2(80);
BEGIN
v_idx    := -1;
v_curIdx := 1;
v_Result := '';
if pStr is null or pStr='' then return pStr;
end if;
v_idx := INSTR(pStr,',');
while (v_idx > 0) loop v_TempId := subStr(pStr,v_curIdx,(v_idx-v_curIdx));
select FLOWNAME into v_Name from FLOW_CATALOG where FLOWNO = v_TempId;
if (v_Name is not null) then v_Result := v_Result||','||v_Name;
end if;
v_curIdx := v_idx+1;
v_idx  := INSTR(pStr,',',v_curIdx);
end loop;
v_TempId := subStr(pStr,v_curIdx);
select FLOWNAME into v_Name from FLOW_CATALOG where FLOWNO = v_TempId;
if (v_Name is not null) then v_Result := v_Result||','||v_Name;
end if;
if length(v_Result)>0 then return substr(v_Result,2);
end if;
return v_Result;
END;
/

