create function          GetFinalResult(serialnoArg in varchar2)
--获取终审结论
return varchar2
is trialresult varchar2(200) ;
begin
  select phaseaction into trialresult
    from flow_task
   where  objectno = serialnoArg and flowno='CreditFlow'
     and serialno = (select max(serialno)
                       from flow_task
                      where objectno = serialnoArg
                        and phaseno in ('0040','0045') and flowno='CreditFlow' );
  return trialresult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFinalResult;


/

