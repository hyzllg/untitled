create view STU as
(select customername,businesssum,serialno,defaultpayacctname from acct_loan where customername in ('王博','交通银行客户'))
/

