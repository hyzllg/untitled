create view V_ICR_RPT_T45 as
SELECT
RPTNO,
NVL2(F0,SUBSTR(F0,1,3)||'********','') F0,
F1,
F2,
F3
FROM gdbzbusi.ICR_RPT_T45

/

