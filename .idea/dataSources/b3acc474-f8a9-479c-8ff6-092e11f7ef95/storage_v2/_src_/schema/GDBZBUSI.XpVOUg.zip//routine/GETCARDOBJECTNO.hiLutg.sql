create FUNCTION GETCARDOBJECTNO(pCustomerid varchar2)
    return varchar2 is
    pObJectNo  varchar2(60);
    begin
          select substr(ObJectNo,length(ObJectNo)-7) into pObJectNo from Card_Reader where customerid =pCustomerid;     
  return pObJectNo;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '0';
  WHEN OTHERS THEN
  return '0';
end;
/

