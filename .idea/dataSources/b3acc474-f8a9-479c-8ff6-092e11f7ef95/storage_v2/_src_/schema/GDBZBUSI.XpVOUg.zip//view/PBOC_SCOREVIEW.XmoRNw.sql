create view PBOC_SCOREVIEW as
select al.baserialno       AS BASERIALNO,
       pd.CUSTOMERID      as CUSTOMERID,
       pd.QUERYMONTH      as QUERYMONTH,
       pd.DIGITALSCORE    as SCORE,
       pd.SCOREUPDATETIME as SCOREDATE
  from PBOC_DIGITALINFOSCORE pd
 inner join ACCT_LOAN al
    on pd.CUSTOMERID = al.CUSTOMERID
 where TO_DATE(TO_CHAR(TO_DATE(pd.querymonth, 'yyyy-mm-dd'), 'yyyy-mm'),
               'yyyy-mm') >=
       TO_DATE(TO_CHAR(TO_DATE(al.putoutdate, 'yyyy/mm/dd'), 'yyyy/mm'),
               'yyyy/mm')
   and TO_DATE(TO_CHAR(TO_DATE(pd.querymonth, 'yyyy-mm-dd'), 'yyyy-mm'),
               'yyyy-mm') <
       TO_DATE(to_char(TO_DATE(nvl(al.finishdate, '9999/12/31'),
                               'yyyy/mm/dd'),
                       'yyyy/mm'),
               'yyyy/mm')
/

