create function          getlpuser(baserialno in varchar2,phasenoArg in varchar2) return varchar2 is
--理赔人员
 lpuserid varchar2(32);
begin
 select userid  into lpuserid
   from flow_task
  where flowno = 'BankCliamFlow'
    and serialno = (select max(serialno)
                      from flow_task
                     where objectno = (select serialno
                                         from bankclaimtaskinfo
                                        where lnsacct =
                                              (select loanserialno
                                                 from business_apply
                                                where serialno = baserialno)
                                          and status = '0')
                       and phaseno = phasenoArg) ;

  return(lpuserid);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getlpuser;


/

