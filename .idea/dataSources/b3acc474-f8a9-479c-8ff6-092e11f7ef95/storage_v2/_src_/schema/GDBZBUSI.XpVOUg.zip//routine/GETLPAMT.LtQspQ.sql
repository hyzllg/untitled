create function          getLPAmt(sAccountNo varchar2)
  return number
  is
  actualpaycorpusamt number(17, 2);
  lpamt  number(17, 2);
begin
  actualpaycorpusamt := 0.00;
  lpamt              := 0.00;
  select nvl(sum(nvl(aps.actualpaycorpusamt, 0)),0)
    into actualpaycorpusamt
    from acct_payment_schedule aps
   where aps.objectno = sAccountNo
     and aps.paytype = '1';
  select (ba.putoutsum - actualpaycorpusamt + al.interestbalance +
         al.fineintebalance)
    into lpamt
    from business_apply ba, acct_loan al
   where al.baserialno = ba.serialNo
     and al.accountno = sAccountNo;
  return lpamt;
end getLPAmt;

/

