create FUNCTION GETPOLICYNAME(sPolicyID VARCHAR)
return VARCHAR
is sPolicyName varchar(80) /

