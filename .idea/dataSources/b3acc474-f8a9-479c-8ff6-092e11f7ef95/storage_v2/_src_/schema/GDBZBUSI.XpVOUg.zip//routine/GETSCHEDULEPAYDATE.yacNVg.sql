create function          GetSchedulePayDate(seqidArg in number,loanserialnoArg in varchar2)
--获得还款日期
return varchar2
is
  paydate varchar2(20);
begin
  select apsb.paydate
    into paydate
    from acct_payment_schedule_back apsb
   where apsb.seqid = seqidArg
     and apsb.objectno = loanserialnoArg
     and apsb.backinputdate=(to_char(trunc(sysdate-1),'yyyy/mm/dd'));
  return paydate;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetSchedulePayDate;

/

