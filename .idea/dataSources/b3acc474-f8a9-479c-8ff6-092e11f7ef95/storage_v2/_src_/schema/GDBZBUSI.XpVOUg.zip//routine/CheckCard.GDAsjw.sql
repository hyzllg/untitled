create function          "CheckCard" (CertID in varchar2(20))
return varchar2 is
num number(10);
phasetype varchar2(20);
msg varchar2(200);
begin
  select ft.phasetype,count(1) into phasetype,num
  from flow_object ft, business_apply bt, customer_info ci
 where ft.objectno = bt.serialno
  and  bt.customerid=ci.customerid
  and ft.flowno='CreditFlow'
  and ft.phasetype in ('1000','2000','3000')
  and ci.certid='360803198608030998' group by ft.phasetype;
  if num>0 then
    if phasetype='1000' then
      msg:='该用户有在途申请';
      return msg;
    elsif then


  return msg;
end CheckCard;

    /

