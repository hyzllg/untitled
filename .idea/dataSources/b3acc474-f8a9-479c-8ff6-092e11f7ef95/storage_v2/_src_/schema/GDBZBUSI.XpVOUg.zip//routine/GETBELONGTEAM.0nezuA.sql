create FUNCTION          getbelongteam(pOrgid varchar2)
--获取催收员的所属团队
return varchar2
is  pBelongTeam  varchar2(200);
begin
	select getItemname('belongteam',uti.belongteam) into pBelongTeam from urge_team_info uti where uti.teamid=pOrgid ;
  return pBelongTeam;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

