create FUNCTION          getUserTypeName(pUserType varchar)
return varchar
is pUserTypeName  varchar(80);
begin
SELECT itemname into pUserTypeName  FROM code_library cl WHERE cl.codeno='UserType' and itemno=pUserType;
return pUserTypeName;
end;

/

