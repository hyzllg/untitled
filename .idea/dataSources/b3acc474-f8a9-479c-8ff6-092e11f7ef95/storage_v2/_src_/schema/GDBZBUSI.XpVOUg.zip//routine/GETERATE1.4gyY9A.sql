create function GETERATE1( sCurrencyFrom varchar2 , sCurrencyTo varchar2)
   return number
  is
	nValueFrom number;
	nValueTo number;
  begin
         if sCurrencyFrom = sCurrencyTo then
         	return 1;
         end if;

         select ExchangeValue into nValueFrom from ERATE_INFO where Currency = sCurrencyFrom;
         if sCurrencyTo='01' then return nValueFrom; end if;
         select ExchangeValue into nValueTo from ERATE_INFO where Currency = sCurrencyTo;
				 if sCurrencyFrom='01' then return 1/nValueTo; end if;
         return nValueFrom/nValueTo;
   end;
/

