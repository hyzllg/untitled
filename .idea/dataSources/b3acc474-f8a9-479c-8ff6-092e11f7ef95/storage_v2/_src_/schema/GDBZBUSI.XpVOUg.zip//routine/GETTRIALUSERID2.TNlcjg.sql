create function GetTrialUserID2(serialnoArg in varchar2)
--获取初审姓名ID
return varchar2
is TrialUserID  varchar2(200) ;
begin
   select userID into TrialUserID
     from flow_task
    where phaseno in ('0030','0035') and flowno='CreditFlow'
      and serialno =
          (select max(serialno)
             from flow_task where phaseno in ('0030','0035') and objectno = serialnoArg and flowno='CreditFlow' and userid<>'OPS');
  return TrialUserID;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetTrialUserID2;
/

