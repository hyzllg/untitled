create package body relative_auto_reject is
 procedure spxt_relative_existsOverdue(pi_cert_id       in varchar2,-- 客户身份证信息
                            po_reject_reason out varchar2) is
   v_spouse_sql  varchar2(4000) := '';
    v_contact_sql varchar2(4000) := '';
    v_self_sql varchar2(4000):='';--找出自己的姓名和手机号
    --找出系统已有客户的联系人与当前申请客户的电话和姓名相同
    v_contact_self_sql varchar2(4000):='';
    v_sql         varchar2(4000) := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
    v_num         int := 0;
    v_fullname      varchar2(200);
    v_mobiletelephone varchar2(20);
  begin
    v_self_sql:='select ii.mobiletelephone,ii.fullname from ind_info ii where certid='''||pi_cert_id||'''';
    execute immediate v_self_sql into v_mobiletelephone,v_fullname;
    v_contact_self_sql:=' SELECT customerid FROM customer_relative UNPIVOT'||
                        ' ((mob,fulname) FOR (mob1,fullname) IN ((mobile,fullname),'||
                        ' (mobile1,fullname1),(mobile2,fullname2),(mobile3,fullname3),'||
                        ' (mobile4,fullname4),(mobile5,fullname5),(mobile6,fullname6),'||
                        '(mobile7,fullname7),(mobile8,fullname8),(mobile9,fullname9)) )'||
                        ' WHERE  MOB ='''||v_mobiletelephone||''' and fulname='''||v_fullname||'''';
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户联系人和电话
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, ind_info ii' ||
                       ' where cr.customerid = ii.customerid ' ||
                       ' and ii.certid = ''' || pi_cert_id || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的当前客户联系人和电话对应的客户id
    v_contact_sql := v_contact_sql ||
                     ' select ii2.customerid ' ||
                     ' from ind_info ii2 , (' ||v_spouse_sql || ') t1 '||
                     ' where ii2.mobiletelephone=t1.mobile and ii2.fullname=t1.fullname '
                   || ' union all '||v_contact_self_sql;
    v_sql := 'select count(0) from (' || v_contact_sql || ')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql := 'select nvl(sum(al.overduedays),0) from acct_loan al where customerid in ('||v_contact_sql||')';
      execute immediate v_sql
      into v_num;
      if v_num>0 then
        po_reject_reason := 'XT1501';
      else po_reject_reason := '';
      end if;
    else
      po_reject_reason := '';
    end if;
  end spxt_relative_existsOverdue;

   /*
 经系统匹配，申请客户的配偶和亲属中1年之内有30+逾期的，申请人直接拒绝。
 */
  procedure spxt_relative_exists31Overdue(pi_cert_id       in varchar2,-- 客户身份证信息
                            po_reject_reason out varchar2) is
   v_spouse_sql  varchar2(4000) := '';
    v_contact_sql varchar2(4000) := '';
    v_self_sql varchar2(4000):='';--找出自己的姓名和手机号
    --找出系统已有客户的联系人与当前申请客户的电话和姓名相同
    v_contact_self_sql varchar2(4000):='';
    v_sql         varchar2(4000) := '';
    v_sql2         varchar2(4000) := '';
    v_sql3         varchar2(4000) := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
    v_num         int := 0;
    v_fullname      varchar2(200);
    v_mobiletelephone varchar2(20);
  begin
    v_self_sql:='select ii.mobiletelephone,ii.fullname from ind_info ii where certid='''||pi_cert_id||'''';
    execute immediate v_self_sql into v_mobiletelephone,v_fullname;
    v_contact_self_sql:=' SELECT customerid FROM customer_relative UNPIVOT '||
                        ' ((mob,fulname,reltion) FOR (mob1,fullname,relation) IN ((mobile,fullname,relation),'||
                        ' (mobile1,fullname1,relation1),(mobile2,fullname2,relation2),(mobile3,fullname3,relation3),'||
                        ' (mobile4,fullname4,relation4),(mobile5,fullname5,relation5),(mobile6,fullname6,relation6),'||
                        '(mobile7,fullname7,relation7),(mobile8,fullname8,relation8),(mobile9,fullname9,relation9)) )'||
                        ' WHERE  MOB ='''||v_mobiletelephone||''' and fulname='''||v_fullname||''' and  '||
                        ' reltion in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')';
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户联系人和电话
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, ind_info ii' ||
                       ' where cr.customerid = ii.customerid  and cr.RELATION'||v_suffix ||
                       ' in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')'||
                       ' and ii.certid = ''' || pi_cert_id || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的当前客户联系人和电话对应的客户id
    v_contact_sql := v_contact_sql ||
                     ' select ii2.customerid ' ||
                     ' from ind_info ii2 , (' ||v_spouse_sql || ') t1 '||
                     ' where ii2.mobiletelephone=t1.mobile and ii2.fullname=t1.fullname '||
                     ' union all '||v_contact_self_sql;
    v_sql := 'select count(0) from (' || v_contact_sql || ')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql2 := 'select 1 from acct_payment_schedule aps where aps.paydate<to_char(sysdate,''yyyy/MM/dd'')'||
      ' and aps.paydate >to_char(sysdate,''yyyy'')-1||substr(to_char(sysdate,''yyyy/mm/dd''),5) and '||
      ' aps.objectno in (select al.serialno from acct_loan al where al.customerid in ('||v_contact_sql||'))'||
      ' and to_date(nvl(aps.finishdate,to_char(sysdate,''yyyy/MM/dd'')),''yyyy/MM/dd'')-to_date(aps.paydate,''yyyy/MM/dd'')>30';
      v_sql3 := 'select count(0) from (' || v_sql2 || ')';
      execute immediate v_sql3
      into v_num;
      if v_num>0 then
        po_reject_reason := 'XT1502';
      else po_reject_reason := '';
      end if;
    else
      po_reject_reason := '';
    end if;
  end spxt_relative_exists31Overdue;
  /*
 经系统匹配，申请客户的配偶和亲属中在最近的三个月内有放款的，申请人直接拒绝（判断时间精确到日）。
 */
  procedure sp_relative_exists3MPutOut(pi_cert_id       in varchar2,-- 客户身份证信息
                            po_reject_reason out varchar2) is
   v_spouse_sql  varchar2(3000) := '';
    v_contact_sql varchar2(4000) := '';
    v_self_sql varchar2(4000):='';--找出自己的姓名和手机号
    --找出系统已有客户的联系人与当前申请客户的电话和姓名相同
    v_contact_self_sql varchar2(4000):='';
    v_sql         varchar2(4000) := '';
    v_sql2         varchar2(4000) := '';
    v_sql3         varchar2(4000) := '';
    v_suffix      varchar2(1) := '';
    v_count       int := 0;
    v_num         int := 0;
    v_fullname      varchar2(200);
    v_mobiletelephone varchar2(200);
  begin
    v_self_sql:='select ii.mobiletelephone,ii.fullname from ind_info ii where certid='''||pi_cert_id||'''';
    execute immediate v_self_sql into v_mobiletelephone,v_fullname;
    v_contact_self_sql:=' SELECT customerid FROM customer_relative UNPIVOT '||
                        ' ((mob,fulname,reltion) FOR (mob1,fullname,relation) IN ((mobile,fullname,relation),'||
                        ' (mobile1,fullname1,relation1),(mobile2,fullname2,relation2),(mobile3,fullname3,relation3),'||
                        ' (mobile4,fullname4,relation4),(mobile5,fullname5,relation5),(mobile6,fullname6,relation6),'||
                        '(mobile7,fullname7,relation7),(mobile8,fullname8,relation8),(mobile9,fullname9,relation9)) )'||
                        ' WHERE  MOB ='''||v_mobiletelephone||''' and fulname='''||v_fullname||''' and  '||
                        ' reltion in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')';
    for i in 0 .. 9 loop
      if i > 0 then
        v_suffix := i;
      end if;
      --找见当前客户联系人和电话
      v_spouse_sql  := v_spouse_sql || ' union all select cr.mobile' ||
                       v_suffix || ', cr.fullname' || v_suffix ||
                       ' from customer_relative cr, ind_info ii' ||
                       ' where cr.customerid = ii.customerid  and cr.RELATION'||v_suffix ||
                       ' in (''0301'',''0302'',''0304'',''0401'',''0402'',''0403'',''0404'',''0405'',''0406'')'||
                       ' and ii.certid = ''' || pi_cert_id || '''';
    end loop;
    v_spouse_sql := substr(v_spouse_sql, 12);
--匹配出来的当前客户联系人和电话对应的客户id
    v_contact_sql := v_contact_sql ||
                     ' select ii2.customerid ' ||
                     ' from ind_info ii2 , (' ||v_spouse_sql || ') t1 '||
                     ' where ii2.mobiletelephone=t1.mobile and ii2.fullname=t1.fullname '||
                     ' union all '||v_contact_self_sql;
    v_sql := 'select count(0) from (' || v_contact_sql||')';
    execute immediate v_sql
      into v_count;
    if v_count > 0 then
      v_sql2 := 'select 1 from acct_loan where customerid in ('||v_contact_sql||') and months_between(sysdate,to_date(putoutdate,''yyyy/MM/dd''))<=3';
      v_sql3 := 'select count(0) from (' || v_sql2 || ')';
      execute immediate v_sql3
      into v_num;
      if v_num>0 then
        po_reject_reason := 'XT1503';
      else po_reject_reason := '';
      end if;
    else
      po_reject_reason := '';
    end if;
  end sp_relative_exists3MPutOut;
   /*
  * 申请阶段自动审批处理
  */
  procedure relative_apply_auto_reject(pi_cert_id       in varchar2, -- 客户身份证信息
                                    po_reject_reason out varchar2) is -- 拒绝原因
  po_reject_reason_zhongjian varchar2(2000):='';
  begin
    if po_reject_reason is null then
      spxt_relative_existsOverdue(pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      spxt_relative_exists31Overdue(pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    if po_reject_reason is null then
      sp_relative_exists3MPutOut(pi_cert_id, po_reject_reason);
      po_reject_reason_zhongjian :=po_reject_reason||'@'||po_reject_reason_zhongjian;
    end if;
    po_reject_reason :=po_reject_reason_zhongjian;
  end relative_apply_auto_reject;
end relative_auto_reject;
/

