create FUNCTION getbusinessname(pJBusinessType varchar)
return varchar
is pBusinessTypeName  varchar(80);
begin
	select TypeName into pBusinessTypeName
	from BUSINESS_TYPE
	where TypeNo=pJBusinessType;
	return pBusinessTypeName;
end;
/

