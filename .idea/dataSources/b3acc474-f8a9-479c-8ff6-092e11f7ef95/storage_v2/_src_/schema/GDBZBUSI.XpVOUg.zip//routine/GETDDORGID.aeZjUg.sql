create FUNCTION getDDOrgid(sOrgid varchar)
return varchar
is
sMforgid varchar(20);
begin
    select nvl(mfogrid,'') into sMforgid  from  ORG_INFO where orgid=sOrgid;
  return sMforgid;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getDDOrgid;
/

