create function          getfinalamt(serialnoArg in varchar2)
--获取最终审批金额
return varchar2
is approvesum varchar2(20);
begin
 select fo.businesssum into approvesum
   from flow_opinion fo
  where fo.serialno = (select max(serialno)
                         from flow_opinion
                        where phaseno in('0040','0035','0030','0045','0047')
                          and objectno = serialnoArg );
  return approvesum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfinalamt;


/

