create FUNCTION getkforgname(pSerialno varchar2)
return varchar2
is pOrgName varchar2(80);
begin
select orgname
  into pOrgName
  from org_info
 where orgid =
       (select inputorgid from business_apply where serialno = pSerialno);
 return pOrgName;
end;

/

