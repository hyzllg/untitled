create view V_LOANPLUS_LIMIT as
SELECT
a.CUSTOMERNAME,
NVL2(a.CERTID,SUBSTR(a.CERTID,1,4)||'************'||SUBSTR(a.CERTID,17),'') CERTID,
a.VALIDDATE,
a.LIMITDATE,
a.LIMITENDDATE,
a.REASON,
a.SUBREASON,
a.SOURCE,
a.UPDATEUSER,
a.UPDATETIME,
a.BATCHNO,
ci.customerid
FROM gdbzbusi.LOANPLUS_LIMIT a,gdbzbusi.customer_info ci where a.certid=ci.certid and ci.CERTTYPE='Ind01'
/

