create function getSADREItems(pType in varchar2,
                                         pStr  in varchar2)
return varchar2
----------------------------------------------------------------
-- description: 将授权场景中维度要素编号序列,转换为中文名称序列
--        pType: role 角色
--               biz  业务品种
--               user 用户
--               org  机构
--        pStr: 要素编号序列
-- author: zllin@amarsoft.com
-- date: 2011-04-27
-- logs: 1. 2011-06-01 剥离代码转换部分功能为独立func
----------------------------------------------------------------
is
  v_Result varchar2(1000) := '';
  v_idx    int := -1;
  v_curIdx int := 1;
  v_TempId varchar2(80) := '';
  v_Name   varchar2(80) := '';
begin
  --return itself where pStrm is null
  if pStr is null then
     return pStr;
  end if;

  --fetch name one by one
  v_idx := instr(pStr,',');
  while v_idx > 0 loop
      v_TempId := subStr(pStr,v_curIdx,(v_idx-v_curIdx));

      --代码转换为中文
      v_Name := SADREItemName(pType,v_TempId);
      if (v_Name is not null) then
         v_Result := v_Result||','||v_Name;
      end if;

      v_curIdx := v_idx+1;           --指针移动
      v_idx  := instr(pStr,',',v_curIdx);

  end loop;

  --handle when v_idx==0 字符串不包含
  v_TempId := subStr(pStr,v_curIdx);
  v_Name := SADREItemName(pType,v_TempId);
  if (v_Name is not null) then
     v_Result := v_Result||','||v_Name;
  end if;

  --剔除第一位的逗号(,)
  if length(v_Result)>0 then
     return substr(v_Result,2);
  end if;

  return(v_Result);
end getSADREItems;
/

