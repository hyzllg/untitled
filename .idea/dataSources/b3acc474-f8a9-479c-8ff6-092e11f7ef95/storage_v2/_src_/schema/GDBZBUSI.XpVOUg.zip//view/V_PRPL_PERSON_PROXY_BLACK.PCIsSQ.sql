create view V_PRPL_PERSON_PROXY_BLACK as
select
    NVL2(agentidentifyno,SUBSTR(agentidentifyno,1,4)||'************'||SUBSTR(agentidentifyno,17),'') agentidentifyno
  ,agentname
  ,agentphone
  ,agentcompanyname
  ,risklevel
  ,comcode
  ,repairrisktype
  ,othertypetext
  ,audittext
  ,repairmark
  ,flag
  ,inserttimeforhis
  ,operatetimeforhis
  from gdbzbusi.prpl_person_proxy_black
/

