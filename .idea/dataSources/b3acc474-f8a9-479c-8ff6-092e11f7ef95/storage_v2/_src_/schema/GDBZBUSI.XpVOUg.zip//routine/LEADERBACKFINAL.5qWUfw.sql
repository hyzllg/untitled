create function          leaderBackFinal(serialnoArg in varchar2)
--组长是否回退终审
return varchar2
is
  num number(2);
begin
    select count(1) into num
 from flow_task
    where phaseno = '0045' and flowno='CreditFlow'
      and objectno = serialnoArg;

  return num;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
  return(num);
end leaderBackFinal;


/

