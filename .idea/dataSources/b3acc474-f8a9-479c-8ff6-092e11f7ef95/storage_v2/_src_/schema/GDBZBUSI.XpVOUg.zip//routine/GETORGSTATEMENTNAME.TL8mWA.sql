create FUNCTION          getorgstatementname(pOrgID varchar2)
return varchar2
is pOrgName varchar2(80);
begin
select OrgName into pOrgName
from org_statement_info
 where Orgid = pOrgID;
 return pOrgName;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

