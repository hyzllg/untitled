create function          casesybjsum(idArg in varchar2,isinuseArg integer)
--获取某个厂商下所有案件剩余金额
return number is
  sybjsum number;
begin
  select sum(residualamount) into sybjsum
    from collection_info
   where collectionuserid = idArg
     and isinuse = isinuseArg;
  return(sybjsum);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end casesybjsum;

/

