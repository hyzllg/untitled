create function          leadertaskendtime(SerialNoArg in varchar2)
--组长审批结束时间
return varchar2
is
  times varchar2(30);
begin
  select endtime into times
    from flow_task
   where serialno = (select max(serialno)
                       from flow_task
                      where phaseno = '0047'
                      and objectno=serialnoArg
                        and flowno = 'CreditFlow');


  return(times);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end leadertaskendtime;


/

