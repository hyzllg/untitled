create view V_CUSTOMER_INSURE_INF as
select al.PUTOUTNO as policyno,al.PUTOUTNO as proposalno,al.STARTDATE as startdate,al.FINALDATE as enddate,al.CUSTOMERNAME as custname,al.CUSTOMERID as custno,al.CURRENCY as prmcurrency,al.TALFEE1 as sumpremium,al.TALPREAMOUNT as sumamount,al.CHANGNO as Endorseno,al.ORGID as comcode,al.REPORTNO,al.FILIINGNO,al.CASENO,
ba.LENDACCOUNTNAME as ACCOUNT_NAME,ba.LENDACCOUNTNO as ACCOUNT_NO,ba.LENDBANKNO as BANK_CODE,ba.RECOGNIZEENAME,
ba.businessnature,'B' as classcode,'BLG' as riskcode,'CHN' as NATIONALITY_CODE,getItemName('PutOutOrg',ba.copobank) as copobank,
ci.CERTTYPE as idtype,ci.CERTID as idno,ci.CERTIDISINUSE as IS_ID_VALID_LONG_TERM,ci.CERTIDSTARDATE as ID_VALID_START,ci.CERTIDSTARDATE as ID_VALID_THRU,
ii.CUSTOMERID as CUSTOMER_NO,ii.FULLNAME as CUSTOMER_NAME,ii.AGE as INDI_AGE,ii.SEX as INDI_GENDER_CODE,ii.BIRTHDAY as INDI_DATE_OF_BIRTH,ii.NATIVEPLACE as INDI_ID_ADDRESS,ii.CERTTYPE as ID_TYPE,ii.MOBILETELEPHONE as INDI_MOBILE,ii.FAMILYADD as ADDRESS,ii.EMAILADD as EMAIL,ii.CERTID as ID_NO,ii.FAMILYZIP as POST_CODE,ii.FAMILYTEL as TEL,ii.MARRIAGE as MARITAL_STATUS,
cw.SERIALNO,cw.CUSTOMERID,cw.INDUSTRYCODE,cw.RANKLEVEL,cw.OCCUPATION,
rp.recognizeeID as b_recognizeeID,rp.POSTCODE as b_POST_CODE,rp.CONTACTPHONE as b_TEL,rp.MAILINGADDRESS as b_PERMANENT_ADDRESS 
from acct_loan al 
join business_apply ba on al.baserialno=ba.serialno
join customer_info ci on  ba.customerid=ci.customerid
join customer_work cw on  ci.customerid=cw.customerid
join ind_info ii on  ci.customerid=ii.customerid
join RECOGNIZEE_PERSON rp on ba.recognizeeID=rp.recognizeeID
/

