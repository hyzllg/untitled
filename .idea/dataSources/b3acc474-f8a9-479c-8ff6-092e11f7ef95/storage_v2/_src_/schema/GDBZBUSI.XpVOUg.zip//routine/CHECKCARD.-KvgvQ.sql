create function          CheckCard (CertID varchar2)
return varchar2 is
num number(10);
num2 number(10);
phasetype varchar2(20);
msg varchar2(200);
baserialno varchar2(20);
num3 number(10);
num1 number(10);
cursor cus_card is select ft.phasetype,bt.serialno, count(1)
  from flow_object ft, business_apply bt, customer_info ci
 where ft.objectno = bt.serialno
  and  bt.customerid=ci.customerid
  and ft.flowno='CreditFlow'
  and ft.phasetype in ('1000','2000','3000')
  and ci.certid=CertID group by ft.phasetype,bt.serialno;
begin
  select count(1) into num1 from black_info bi where bi.certid=CertID;
  if num1>0 then
    msg:='该用户是黑名单客户';
  end if;
  OPEN cus_card; --打开游标
  --循环游标
  LOOP
    FETCH cus_card
      into phasetype,baserialno,num; --取值
    EXIT WHEN cus_card%NOTFOUND; --当没有记录时退出循环
    if num>0 then
      if phasetype='1000' then
        msg:='该用户有在途申请';
        return msg;
      else
        select count(1) into num2 from acct_loan al where al.baserialno=baserialno and al.loanstatus in ('0','1');
        if num2>0 then
           msg:='该用户存在未结清的贷款';
        end if;
        select sysdate-max(to_date(ba.inputdate,'yyyy-MM-dd')) into num3 from business_apply ba where ba.serialno=baserialno;
        if num3>30 then
          msg:='在可申请时限内';
        end if;
      end if;
       EXIT when msg !='';
    end if;
   END LOOP;
  CLOSE cus_card;
  return msg;
end CheckCard;

/

