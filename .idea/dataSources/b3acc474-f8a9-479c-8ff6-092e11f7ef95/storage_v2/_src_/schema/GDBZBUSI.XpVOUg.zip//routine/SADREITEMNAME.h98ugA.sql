create function SADREItemName(pType in varchar2, pNo in varchar2)
return varchar2
is

  v_Name   varchar2(80) := '';
  v_sql    varchar2(100) := '';
begin
  if pType='role' then
     v_sql := 'select RoleName from ROLE_INFO where RoleId =:1';
  elsif pType='biz' then
     v_sql := 'select TypeName from BUSINESS_TYPE where TypeNo =:1';
  elsif pType='user' then
     v_sql := 'select UserName from USER_INFO where UserId =:1';
  elsif pType='org' then
     v_sql := 'select OrgName from ORG_INFO where OrgId =:1';
  elsif pType='dimension' then
     v_sql := 'select DIMENSIONNAME from SADRE_DIMENSION where DIMENSIONID =:1';
  elsif pType='scene' then
     v_sql := 'select SCENENAME from SADRE_RULESCENE where SCENEID =:1';
  elsif pType='flow' then
     v_sql := 'select FLOWNAME from flow_catalog where FLOWNO =:1';
  else
     return '';
  end if;

      begin
        execute immediate v_sql
          into v_Name
          using pNo;

      exception
        when no_data_found then
          v_Name := '';
      end;

  return(v_Name);
end SADREItemName;
/

