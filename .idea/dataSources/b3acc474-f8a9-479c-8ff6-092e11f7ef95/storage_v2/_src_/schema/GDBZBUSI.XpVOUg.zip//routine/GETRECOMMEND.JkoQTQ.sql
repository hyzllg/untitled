create FUNCTION          getrecommend(baserialno varchar)
return varchar
is pSegmentrecommend varchar(80);
begin
select Segmentrecommend into pSegmentrecommend
from business_apply
 where serialno = baserialno;
 return pSegmentrecommend;
 EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;
/

