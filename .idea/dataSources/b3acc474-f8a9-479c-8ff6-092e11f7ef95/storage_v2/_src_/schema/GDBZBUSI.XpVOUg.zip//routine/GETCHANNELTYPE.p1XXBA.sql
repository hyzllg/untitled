create FUNCTION getchanneltype(pagentno varchar)
return varchar
is  pchanneltype  varchar(200);
begin
  /**这个方法仅用于获取历史单子,指creditaudittable取不到的情况下使用*/
  pchanneltype:='';
  SELECT channeltype into pchanneltype FROM channel_manage_company WHERE serialno =
(SELECT CHANNELCOMNO FROM channelcompany_contacts where agentno = pagentno and rownum=1 );
  return pchanneltype;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return pchanneltype;
  WHEN OTHERS THEN
  return pchanneltype;
end;
/

