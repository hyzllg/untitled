create function GetBankOrgName(bankOrgArg in varchar2)
return varchar2
is BankNameValue varchar2(200) ;
begin
 select distinct inputorgname
   into BankNameValue
   from recognizee_bank
  where inputorgid = bankOrgArg;
  return BankNameValue;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetBankOrgName;
/

