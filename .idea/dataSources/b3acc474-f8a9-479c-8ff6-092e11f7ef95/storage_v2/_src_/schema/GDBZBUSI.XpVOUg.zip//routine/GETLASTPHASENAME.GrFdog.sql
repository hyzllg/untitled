create FUNCTION getLastPhaseName(pObjectType varchar,pObjectNo VARCHAR,pFlowNo VARCHAR)
return varchar
is pPhaseOpinion1  varchar(80);
begin
  SELECT PhaseName INTO pPhaseOpinion1 FROM FLOW_TASK WHERE serialno =(
  SELECT nvl(relativeserialno,serialno)
  FROM FLOW_TASK
 WHERE SERIALNO = (SELECT MAX(SERIALNO)
                     FROM FLOW_TASK
                    WHERE OBJECTTYPE = pObjectType
                      AND OBJECTNO = pObjectNo
                      AND FLOWNO = pFlowNo));
	return pPhaseOpinion1;
end;
/

