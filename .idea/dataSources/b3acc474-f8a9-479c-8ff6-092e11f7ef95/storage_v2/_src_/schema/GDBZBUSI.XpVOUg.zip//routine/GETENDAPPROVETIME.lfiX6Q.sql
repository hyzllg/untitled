create function GETENDAPPROVETIME(serialnoArg in varchar2)
return  varchar2
is  approveEndTime varchar2(20);
begin
  select to_char(max(to_date(substr(endtime, 1, 10), 'yyyy/mm/dd')),
                 'yyyy/MM/dd') into approveEndTime
    from flow_task ft, business_apply ba
   where ft.objectno = ba.serialno
     and ba.serialno = serialnoArg;
  return approveEndTime;
end GETENDAPPROVETIME;
/

