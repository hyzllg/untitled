create FUNCTION GETPAYMENTMETHOD(pJBusinessType varchar)
return varchar
is pBusinessTypeName  varchar(80);
begin
	select termname into pBusinessTypeName
	from acct_term_library
	where termid=pJBusinessType AND STATUS='1' AND termid LIKE 'RPT%';
	return pBusinessTypeName;
end;
/

