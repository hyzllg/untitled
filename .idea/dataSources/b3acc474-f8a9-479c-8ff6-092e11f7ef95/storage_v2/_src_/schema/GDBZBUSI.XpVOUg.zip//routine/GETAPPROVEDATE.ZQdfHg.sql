create function GETAPPROVEDATE(serialnoArg in varchar2)
--进入审批日期
return varchar2
is ApproveDate varchar2(20);
begin
  select ft.begindate into ApproveDate
    from ( select nvl(substr(begintime,1,10),'') begindate
     from  flow_task
      where phaseno='0030' and objectno=serialnoArg
       order by begintime asc)ft
       where rownum='1';
  return ApproveDate;
end GETAPPROVEDATE;
/

