create FUNCTION          getMaxFtUserName(sobjectno varchar,sphaseno varchar)
return varchar
is  mUserName  varchar(200);
begin
  mUserName:='';
  if sphaseno='1010' then
    select nvl(ft.userid,'8000616484')||' '||nvl(ft.username,'汤伟蓉') into mUserName
    from flow_task ft
    where ft.serialno=(select max(ftt.serialno) from flow_task ftt where
    ftt.objectno=(select max(bci.serialno) from bankclaimtaskinfo bci where bci.lnsacct=sobjectno
    and exists(select 1 from gdbzbusi.flow_task fttt WHERE fttt.flowno='BankCliamFlow' and fttt.phaseno='1020' and
    fttt.objectno=bci.serialno )) and ftt.phaseno=sphaseno);
  elsif sphaseno='1020' then
    select nvl(ft.userid,'8000581401')||' '||nvl(ft.username,'李倩倩') into mUserName
    from flow_task ft
    where ft.serialno=(select max(ftt.serialno) from flow_task ftt where
    ftt.objectno=(select max(bci.serialno) from bankclaimtaskinfo bci where bci.lnsacct=sobjectno
    and exists(select 1 from gdbzbusi.flow_task fttt WHERE fttt.flowno='BankCliamFlow' and fttt.phaseno='1020' and
    fttt.objectno=bci.serialno )) and ftt.phaseno=sphaseno);
  else
  select '' into mUserName from dual;
  end if;
  return mUserName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
    if sphaseno='1010' then
       return '8000616484 汤伟蓉';
    elsif sphaseno='1020' then
       return '8000581401 李倩倩';
     end if;
  WHEN OTHERS THEN
  return '';
end;
/

