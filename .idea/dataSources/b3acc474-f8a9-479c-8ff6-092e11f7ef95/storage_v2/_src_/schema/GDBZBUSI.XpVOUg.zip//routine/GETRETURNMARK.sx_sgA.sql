create function getReturnMark(serialnoArg in varchar2)
--初审回退备注
return varchar2
is backremark varchar2(300);
begin
  select nvl(ba.isapprovebackorg,'否') into  backremark from business_apply ba where ba.serialno=serialnoArg;
  if backremark ='是' then
select phaseopinion3 into backremark
 from flow_opinion where serialno=(
 select serialno from (
     select serialno
     from flow_opinion
     where reasoncode1 is not null
     and phasechoice = '初审回退录入'
     and objectno = serialnoArg order by updatetime desc)
   where rownum=1 );

  else
    backremark:='';
  end if;

  return backremark;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getReturnMark;

/

