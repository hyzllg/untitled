create FUNCTION GETCOUNTBUSINESSSUM(serialnoArg in varchar2)
--获取理论审批金额
return varchar2
is CountBusinessSum varchar2(20);
begin
  select nvl(fo.CHANGECOUNTBUSINESSSUM,fo.countbusinesssum) into CountBusinessSum
  from flow_opinion fo
  where fo.serialno =
      ( select max(serialno)
                 from flow_opinion where phaseno not in ('0070','0050','0012'）  and objectno=serialnoArg and updatetime is not null);
  return CountBusinessSum;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getCountBusinessSum;
/

