create function GetFinalApproveSum(baSerialnoArg in varchar2)
--获取终审通过的审批金额
return varchar2
is approveSumResult varchar2(200) ;
begin
  select ba.approvesum into approveSumResult
    from business_apply ba, flow_task ft
   where ba.serialno = ft.objectno  and ft.phaseno in ( '0040','0045')
     and (ft.phaseaction = '终审通过' or ft.phaseaction = '终审通过提交预约' ) and ft.flowno='CreditFlow'
     and ba.serialno = ft.objectno and ba.serialno=baSerialnoArg;

  return  approveSumResult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFinalApproveSum;
/

