create FUNCTION getitemname(pCodeNo varchar,pItemNo varchar)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  select ItemName into pItemName  
  from Code_Library
  where CodeNo=pCodeNo and ItemNo=pItemNo;
  return pItemName;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return pItemNo;
  WHEN OTHERS THEN
  return pItemNo;
end;
/

