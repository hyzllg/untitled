create FUNCTION split (
    p_str       IN VARCHAR2
)
    RETURN varchar2
IS
    j INT := 0;--逗号所在的位置
    i INT := 1;--起始位置
    len INT := 0;--字符串长度
   --str VARCHAR2 (4000);
    strname varchar2(4000);

BEGIN
    len := LENGTH (p_str);
    IF len=4
            then strname:=getItemName('PersonFlag',p_str);
    else
      WHILE j < len
      LOOP
          j := INSTR (p_str, ',', i);
          IF j = 0 --没有找见逗号
             THEN
               --str := p_str;
              strname := getItemName('PersonFlag',substr(p_str,i-3,4))||'/'||strname;
              IF i >= len
              THEN
                  EXIT;
              END IF;
          ELSE
              --str := substr(p_str,i,4);
              strname :=getItemName('PersonFlag',SUBSTR (p_str, j-4, 4))||'/'||strname;
              i := j + 4;
          END IF;
      END LOOP;
    end if;
    RETURN strname;
    EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
END split;

/

