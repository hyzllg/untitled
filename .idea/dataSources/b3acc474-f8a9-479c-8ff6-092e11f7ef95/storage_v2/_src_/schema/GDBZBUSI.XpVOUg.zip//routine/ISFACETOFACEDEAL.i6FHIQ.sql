create function isfacetofacedeal(serialnoArg in varchar2)
return varchar2

is finalTrialvalue varchar2(40);

begin
    select phasename into finalTrialvalue
      from flow_object
     where flowno = 'CreditFlow'
       and phaseno in
           ('0010', '0012','0020', '0070', '1000', '2000', '2050', '2060','2090','3030','3060','3070','3080')
       and objectno = serialnoArg;

  return(finalTrialvalue);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end isfacetofacedeal;
/

