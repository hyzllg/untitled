create function getleadername(serialNoArg in varchar2)
--获取组长姓名
return varchar2 is
  names varchar2(200);
begin
  select getusername(belonguserid) into names
    from approve_users
   where username = GetFinalUserName(serialnoArg) and approvelevel='2';
  return(names);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getleadername;
/

