create view V_LOANPLUS_RECORD as
SELECT
NVL2(a.CERTID,SUBSTR(a.CERTID,1,4)||'************'||SUBSTR(a.CERTID,17),'') CERTID,
a.CUSTOMERNAME,
a.FLAG,
a.INSERTTIME,
a.UPDATETIME,
a.SERIALNO,
ci.customerid
FROM gdbzbusi.LOANPLUS_RECORD a,gdbzbusi.customer_info ci where a.certid=ci.certid and ci.CERTTYPE='Ind01'
/

