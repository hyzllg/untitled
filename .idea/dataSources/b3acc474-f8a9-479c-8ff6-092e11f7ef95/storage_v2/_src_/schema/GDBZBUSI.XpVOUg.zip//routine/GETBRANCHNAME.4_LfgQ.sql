create function getbranchname(inputorgid in varchar2)
  --获得门店所在分部
 return varchar2
is
  branchname varchar2(20);
begin

    select belongorgid into branchname
    from org_info where orgid = inputorgid and orglevel='14';
  return(branchname);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getbranchname;
/

