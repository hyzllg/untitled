create FUNCTION          GetOrgId(pUserID varchar2)
--获取所属机构
return varchar2
is
 pRelativeOrgID  varchar2(80) ;
begin
 select BELONGORG into pRelativeOrgID from USER_INFO where userid = pUserID and status='1' ;
 return pRelativeOrgID;
end ;
/

