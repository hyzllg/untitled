create function getcheckendtime1(serialnoArg in varchar2)
--录单结束时间 提交复核时间
return varchar2
is tiemback varchar2(100);
begin
select substr(endtime,1,10) into tiemback-- 2018/03/26 09:40:53
 from flow_task where serialno=(
 select serialno from (
     select serialno
     from flow_task
     where  phaseno = '0020'
     and objectno = serialnoArg order by endtime desc)
   where rownum=1);
  return tiemback;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getcheckendtime1;

/

