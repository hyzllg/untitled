create function          getamtsumnew1(IDArg in varchar2,isGuaranty in varchar2)
--得到某催收员下的所有阶段的分案剩余本金总额
return number is
  amt1 number;
begin
  select sum(caseresidualamount) into amt1
    from collection_info
   where collectionuserid = IDArg
     and isguaranty = isGuaranty
     and isinuse = '1';
  return(amt1);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getamtsumnew1;
/

