create function getRepaymentInfo(pi_ba_serial_no in varchar2,
                                            pi_get_type     in varchar2)
  return varchar2 is
  Result varchar2(30);
--上次扣款日期和上次扣款金额
  --v_bb_serial_no acct_back_detail.bbserialno%type;
  v_bb_serial_date acct_back_detail.actualpaydate%type;
begin
  begin
    if pi_get_type = 'lastDate' then
      select max(t.actualpaydate)
        into Result
        from acct_back_detail t
       where t.baserialno = pi_ba_serial_no and t.paytype<>'6';
    elsif pi_get_type = 'lastAmount' then
      select max(t.actualpaydate)
        into v_bb_serial_date
        from acct_back_detail t
       where t.baserialno = pi_ba_serial_no and t.paytype<>'6';

      select trim(to_char(sum(nvl(t.actualpaycorpusamt, 0)) +
                     sum(nvl(t.actualpayinteamt, 0)) +
                     sum(nvl(t.actualfineamt, 0)) +
                     sum(nvl(t.actualpayfeeamt1, 0)),'9999990.99'))
        into Result
        from acct_back_detail t
       where t.actualpaydate = v_bb_serial_date
         and t.baserialno = pi_ba_serial_no;
    end if;
  exception
    when no_data_found then
      Result := '';
    when others then
      Result := '';
  end;

  return(Result);
end getRepaymentInfo;
/

