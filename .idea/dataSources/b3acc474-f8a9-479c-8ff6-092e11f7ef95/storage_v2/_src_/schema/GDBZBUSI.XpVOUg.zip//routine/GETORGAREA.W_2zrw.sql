create function GetOrgArea(orgArg in varchar2)
--获取门店所在区域
return varchar2
is orgnamevalue  varchar2(200) ;
 orgindex number(10);
 orgArg1 varchar2(200);
begin
  orgArg1:=orgArg;
   <<fst_loop>>
FOR orgindex IN  1..6
LOOP
   select orgid into orgArg1 from org_info where orgid = (select belongorgid from org_info where orgid=orgArg1);
   select orgid into orgnamevalue from org_info where orgid=orgArg1;
   exit fst_loop when orgnamevalue in ('Z1001','Z1002','Z1003','Z1004') ;
END LOOP;
  return orgnamevalue;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetOrgArea;
/

