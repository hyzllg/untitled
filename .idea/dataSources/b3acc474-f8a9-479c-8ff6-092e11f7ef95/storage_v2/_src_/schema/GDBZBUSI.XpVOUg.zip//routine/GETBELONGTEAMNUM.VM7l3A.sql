create function GETBELONGTEAMNUM(orgidArg in varchar2)
--获取机构下营业组数
return number
is countteam number(10) ;
begin
 select count(orgid) into countteam from org_info o where o.belongorgid=orgidArg;
  return  countteam;
end GETBELONGTEAMNUM;
/

