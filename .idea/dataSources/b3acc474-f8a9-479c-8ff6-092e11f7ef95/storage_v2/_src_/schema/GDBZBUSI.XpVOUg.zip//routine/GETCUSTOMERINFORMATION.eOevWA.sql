create FUNCTION "GETCUSTOMERINFORMATION"(pCustomerid in varchar2,pParams in varchar2)
return number
is sSum number(10,2);
begin
if pParams='businesssum' then
select nvl((select sum(ba.signsum) from business_apply ba where ba.serialno in(select al.baserialno from acct_loan al where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP')),0)
into sSum from dual;

elsif pParams='oversum' then
select nvl((select sum(nvl(al.overduebalance,0)+nvl(al.interestbalance,0)+nvl(al.fineintebalance,0)+nvl(al.feeamtbalance,0)+nvl(al.overduefinebalance,0)+nvl(al.compintebalance,0))
from acct_loan al where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP'),0) into sSum from dual;

elsif pParams='feeamtbalance' then
select nvl((select sum(al.feeamtbalance) from acct_loan al
where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP'),0) into sSum from dual;

elsif pParams='residuesum' then
select nvl((select sum(nvl(al.normalbalance,0)+nvl(al.overduebalance,0)) from acct_loan al
where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP'),0) into sSum from dual;

elsif pParams='overduedays' then
select nvl((select max(al.overduedays) from acct_loan al
where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP'),0) into sSum from dual;

elsif pParams='overdueterm' then
select nvl((select max(nvl(substr(ci.overstage,2,length(ci.overstage)),0)) from collection_info ci
where ci.customerid=pCustomerid and ci.isinuse='1' and ci.overstage<>'FP'),0) into sSum from dual;

elsif pParams='overstage' then
select nvl((select max(nvl(substr(ci.overstage,2,length(ci.overstage)),0)) from collection_info ci
where ci.customerid=pCustomerid and ci.isinuse='1' and ci.overstage<>'FP'),0) into sSum from dual;

elsif pParams='paycredere' then
select nvl((select sum(nvl(arl.paycredere,0)-nvl(arl.actualcredere,0)) from acct_recovery_loss arl
where arl.serialno in(select al.serialno from acct_loan al where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP')),0)
into sSum from dual;

elsif pParams='payoverduefine' then
select nvl((select sum(nvl(arl.payoverduefine,0)) from acct_recovery_loss arl
where arl.serialno in(select al.serialno from acct_loan al where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP')),0)
into sSum from dual;

elsif pParams='askamtsum' then
select nvl((select sum(nvl(arl.paycredere,0)+nvl(arl.payoverduefine,0)+nvl(arl.payfeeamt1,0)-nvl(arl.actualcredere,0)-nvl(arl.actualoverduefine,0)-nvl(arl.actualpayfeeamt1,0)) from acct_recovery_loss arl
where arl.serialno in(select al.serialno from acct_loan al where al.customerid=pCustomerid and al.finishdate is null and al.aloverstagetrue<>'FP')),0)
into sSum from dual;

elsif pParams='monthresiduesum' then
select nvl((select sum(ci.caseresidualamount) from collection_info ci
where ci.isinuse='1'and ci.customerid=pCustomerid and ci.accounttype<>'07'),0) into sSum from dual;


else
select '0' into sSum from dual;
end if;
return sSum;
end getcustomerinformation;
/

