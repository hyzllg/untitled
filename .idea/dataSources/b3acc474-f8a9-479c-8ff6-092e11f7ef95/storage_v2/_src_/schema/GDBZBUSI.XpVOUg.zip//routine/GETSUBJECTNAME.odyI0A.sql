create FUNCTION GETSUBJECTNAME (pJSubjectNo varchar)
return varchar
is pSubjectName  varchar(80);
begin
	select SubjectName into pSubjectName
	from SUBJECT_INFO
	where SubjectNo=pJSubjectNo;
	return pSubjectName;
end;
/

