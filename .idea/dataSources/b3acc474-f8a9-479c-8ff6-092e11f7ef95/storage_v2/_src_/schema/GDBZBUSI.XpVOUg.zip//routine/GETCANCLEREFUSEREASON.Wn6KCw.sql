create FUNCTION          getCancleRefuseReason(sReasoncode1 varchar,sPhaseno varchar,sReasonCode2 varchar)
return varchar
is
reason varchar(100);
begin
    SELECT subreason INTO reason FROM reason_param WHERE mainreasonCode = sReasoncode1 AND subreasonCode = sReasonCode2 AND isinuse = '1' AND phaseno = sPhaseno;
	return reason;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getCancleRefuseReason;

/

