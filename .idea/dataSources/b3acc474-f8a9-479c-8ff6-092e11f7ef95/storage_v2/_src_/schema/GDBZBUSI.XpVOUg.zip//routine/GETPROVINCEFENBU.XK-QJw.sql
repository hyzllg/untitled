create function          GetProvinceFenBu(orgArg in varchar2)
--获取门店所在省分部
 return varchar2 is
  vProvinceFenBu varchar2(32);
begin
  select orgid into vProvinceFenBu from org_info where orgid=(select belongorgid from org_info where orgid=
  (select belongorgid from org_info where orgid=orgArg));
  return vProvinceFenBu;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '';
  WHEN OTHERS THEN
    return '';
end GetProvinceFenBu;

/

