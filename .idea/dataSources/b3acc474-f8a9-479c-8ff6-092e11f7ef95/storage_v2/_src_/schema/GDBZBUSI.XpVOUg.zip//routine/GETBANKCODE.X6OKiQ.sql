create FUNCTION getBankCode(pBANKNO varchar,pCodeNo varchar,pLandCode varchar)
return varchar
is pBankCode  varchar(200);
begin
  pBankCode:='';
  select bankCode into pBankCode
  from bank_config
  where BANKNO=pBANKNO and CodeNo=pCodeNo and LandCode=pLandCode;
  return pBankCode;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return pBankCode;
  WHEN OTHERS THEN
  return pBankCode;
end;

/

