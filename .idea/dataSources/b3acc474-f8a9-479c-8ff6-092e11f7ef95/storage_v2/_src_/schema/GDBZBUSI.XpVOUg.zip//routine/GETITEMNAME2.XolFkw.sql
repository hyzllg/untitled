create FUNCTION getItemName2
(
   pCustomerID varchar2,pItemNo varchar2
)
RETURN varchar2
is
pItemName varchar2(200);
BEGIN
select
ItemName into pItemName
from CODE_LIBRARY
where CodeNo =
(
   select
   case when substr
   (
      CustomerType,1,2
   )
   ='03' then 'IndividualTaxType' else 'TaxType' end
   from CUSTOMER_INFO
   where customerid=pCustomerID
)
and ItemNo = pItemNo;
return pItemName;
END;
/

