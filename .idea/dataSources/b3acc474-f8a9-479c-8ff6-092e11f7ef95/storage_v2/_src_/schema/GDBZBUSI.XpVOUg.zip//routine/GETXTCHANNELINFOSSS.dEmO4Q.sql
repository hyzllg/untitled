create FUNCTION getxtchannelinfosss(pChannelCompany varchar2,pContactsName varchar2,pAgentuserid varchar2,pSalesuserid varchar2,pChannel varchar2,pFlag varchar2)
return varchar2 is
  pIsAgent  varchar2(2);
  pResult  varchar2(40);
begin
  pResult:='';
  if pChannel='CH2016032400000002' then
  select cc.isagent into pIsAgent from channelcompany_contacts cc where cc.channelcompany=pChannelCompany and cc.contactsname=pContactsName;

if pFlag='attachetype' and pIsAgent='1' then
select ui.attachetype into pResult from user_info ui where ui.userid=pAgentuserid;

elsif pFlag='attachetype' and pIsAgent='2' then
select ui.attachetype into pResult from user_info ui where ui.userid=pSalesuserid;
elsif pFlag='channelmanagerid' and pIsAgent='1' then

select ui.channelmanagerid into pResult from user_info ui where ui.userid=pAgentuserid;

elsif pFlag='channelmanagerid' and pIsAgent='2' then
select ui.channelmanagerid into pResult from user_info ui where ui.userid=pSalesuserid;

elsif pFlag='channelmanagername' and pIsAgent='1' then
select ui.channelmanagername into pResult from user_info ui where ui.userid=pAgentuserid;

elsif pFlag='channelmanagername' and pIsAgent='2' then
select ui.channelmanagername into pResult from user_info ui where ui.userid=pSalesuserid;

else
select '' into pResult from dual;
end if;

else
select '' into pResult from dual;
end if;
return pResult;
end ;
/

