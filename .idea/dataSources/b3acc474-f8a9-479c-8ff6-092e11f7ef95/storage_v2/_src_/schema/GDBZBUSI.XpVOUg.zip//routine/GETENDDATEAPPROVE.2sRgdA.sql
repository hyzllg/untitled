create function GetEndDateApprove(serialnoArg in varchar2)
--获取审批结束日期
return varchar2
is approveendtime varchar2(200) ;
begin
  select substr(endtime,1,10) into approveendtime
    from flow_task ft
   where serialno = (select max(serialno)
                       from flow_task
                      where exists (select 1
                               from flow_task
                              where phaseno = '0030'
                                and objectno = ft.objectno)
                        and phaseno not in ('0050', '0070', '1000','2060','2050','2070','2010','2000','2090','3030','3040','3050','3060','3070','3080')
                        and objectno = ft.objectno) and objectno=serialnoArg;
  return approveendtime;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetEndDateApprove;
/

