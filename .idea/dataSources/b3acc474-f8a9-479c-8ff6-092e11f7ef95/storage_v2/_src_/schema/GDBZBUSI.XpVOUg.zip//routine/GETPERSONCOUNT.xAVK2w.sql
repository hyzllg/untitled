create function          getpersoncount(teamidArg in varchar2)
--获取催收某组的人数
return varchar2
is
  ManuNum  integer;
  flag integer;
begin
  select belongteam into flag from urge_team_info where teamid=teamidArg;
  if flag =3 then
    select count(1) into ManuNum from out_manufacturer  where  teamid = teamidArg;
  else
  select count(1) into ManuNum
    from user_info ui, user_role ur
   where ui.teamid = (select teamid
                        from urge_team_info uti
                       where uti.teamid = teamidArg)
     and ui.userid = ur.userid
     and ur.roleid in ('611', '612', '613','614','615','616','617','618');
  end if;
  return(ManuNum);

  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getpersoncount;

/

