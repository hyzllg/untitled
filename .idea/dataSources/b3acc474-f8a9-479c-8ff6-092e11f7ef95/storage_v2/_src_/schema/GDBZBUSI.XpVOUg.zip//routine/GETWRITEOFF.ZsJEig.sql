create FUNCTION          getwriteoff(serialnoArs varchar2)
return number
is amount  number(24,2);
begin
	select -sum(nvl(realpayamt,0)) into amount
	from claimamtinfo
	where lnsacct=serialnoArs and paytype='3' and status in ('5','10');
	return amount;
end;


/

