create function getConvertCode(pModelItemID varchar2,pInitCode varchar2,pValue varchar2)
return varchar2
---------------------------------
--获取代码转换结果
--RINK at 2004/8/31
---------------------------------
is
  pConvertCode varchar2(100);
begin
  begin
    SELECT ConvertValue into pConvertCode
    FROM CONFIG_CONVERT
    WHERE DataItemID = pModelItemID
          AND InitValue = pInitCode;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
         pConvertCode := pValue;
  end;
  if pConvertCode is null then
    pConvertCode := pValue;
  end if;
  return(pConvertCode);
end getConvertCode;
/

