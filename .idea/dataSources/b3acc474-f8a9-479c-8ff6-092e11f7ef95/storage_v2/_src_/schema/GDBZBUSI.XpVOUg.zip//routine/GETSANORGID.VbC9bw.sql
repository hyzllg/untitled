create FUNCTION getSanOrgid(sOrgID varchar2)
return varchar
is  pItemName  varchar(200);
begin
  pItemName:='';
  Select o1.ORGID into pItemName  From ORG_INFO o1 WHERE o1.orgtype in ('1') and o1.BELONGORGID=
(select o2.BELONGORGID From ORG_INFO o2 WHERE o2.orgid=sOrgID and o2.orgtype in ('2','4'));
  if pItemName is null then
            return pItemName;
  else
            return pItemName;
  end if;
end;
/

