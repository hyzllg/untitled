create function          leadergettasktime(serialnoArg in varchar2)
--案件跳转至组长待处理的时间
return varchar2
is
  times varchar2(30);
begin
   select begintime into times
     from flow_task
    where serialno = (select min(serialno)
                        from flow_task
                       where phaseno = '0047'
                       and objectno=serialnoArg
                         and flowno = 'CreditFlow');

  return(times);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end leadergettasktime;


/

