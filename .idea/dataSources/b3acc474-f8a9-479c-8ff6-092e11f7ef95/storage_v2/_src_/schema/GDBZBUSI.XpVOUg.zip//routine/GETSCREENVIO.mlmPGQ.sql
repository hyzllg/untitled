create function          getScreenVio(vid varchar) return varchar is
/**
* 屏蔽姓名,手机号,证件号,卡号中间的信息 2018/07/02
*/
  leh    number;
  screen varchar2(80);
  r      varchar2(80);
begin

  leh := length(vid);

  screen := '********************';
  if (leh = 18 or leh = 19 or leh = 16) then
    r := substr(vid, 0, 6) || substr(screen, 0, leh - 10) || substr(vid, leh - 3, leh);
  elsif (leh = 11) then
    r := substr(vid, 0, 3) || substr(screen, 0, 4) || substr(vid, leh - 3, leh);
  elsif (leh = 12) then
    r := substr(vid, 0, 3) || substr(screen, 0, 4) || substr(vid, leh - 3, leh);
  elsif (leh = 10) then
    r := substr(vid, 0, 3) || substr(screen, 0, 4) || substr(vid, leh - 3, leh);
  elsif (leh = 2  or leh = 3 or leh = 4) then
    r := substr(vid, 0, 1) || substr(vid, 1, leh-1);
  else
    r := substr(vid, 0, 1) || substr(screen, 1, leh-1);
  end if;

  return r;

end;

/

