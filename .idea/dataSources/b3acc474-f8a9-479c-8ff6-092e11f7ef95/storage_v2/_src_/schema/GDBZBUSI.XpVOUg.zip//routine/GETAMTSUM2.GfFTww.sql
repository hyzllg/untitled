create function          getamtsum2(IDArg in varchar2,stage in varchar2,isGuaranty in varchar2)
--获得某催收员某阶段的剩余本金总额
return number is
  amt2 number;
begin
   select sum(residualamount) into amt2
    from collection_info
   where collectionuserid = IDArg
     and overstage = stage
     and isguaranty = isGuaranty
     and isinuse = '1';
  return(amt2);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getamtsum2;
/

