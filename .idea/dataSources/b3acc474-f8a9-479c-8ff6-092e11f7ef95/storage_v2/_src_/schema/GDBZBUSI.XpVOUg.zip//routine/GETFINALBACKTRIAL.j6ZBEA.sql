create function GetFinalBackTrial(serialnoArg in varchar2)
--获取终审是否回退初审
return varchar2
is finalBackTrialvalue  varchar2(200) ;
begin
  select count(1) into finalBackTrialvalue
 from flow_task
    where phaseno = '0035' and flowno='CreditFlow'
      and objectno = serialnoArg;

  return finalBackTrialvalue;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetFinalBackTrial;
/

