create FUNCTION getGuarantyTypeName(pGuarantyType varchar2)
RETURN varchar2
is
pGuarantyTypeName varchar2(80);
BEGIN
select
GuarantyTypeName into pGuarantyTypeName
from CMS_COLLATERALTYPE_INFO
Where GuarantyType = pGuarantyType;
return pGuarantyTypeName;
END;
/

