create function          getfinalremark(serialnoArg in varchar2)
--终审备注
return varchar2
is remark varchar2(400);
begin
  select distinct fo.phaseopinion3 into remark
   from flow_opinion fo
   where fo.phaseno = '0040'
   and fo.opinionno in (select max(fo1.opinionno) from flow_opinion fo1 where fo1.objectno=serialnoArg and fo1.objectno=fo.objectno and fo1.phaseno='0040');
  return remark;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfinalremark;


/

