create FUNCTION          getappsum(pSerialNO varchar2)
return varchar2
is pAppSum varchar2(80);
begin
select PREAPPROVESUM into pAppSum
from Creditaudittable
 where serialno = pSerialNO;
 return pAppSum;
end;

/

