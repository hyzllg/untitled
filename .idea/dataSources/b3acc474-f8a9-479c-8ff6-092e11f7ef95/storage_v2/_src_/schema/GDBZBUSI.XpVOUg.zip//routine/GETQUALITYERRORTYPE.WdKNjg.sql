create function          getQualityErrorType(pi_serial_no in varchar2)
  return varchar2 is
  Result varchar2(30) := '';

  v_tel_confirm_remark quality_opionon.telconfirmremark%type;
  v_operation_remark   quality_opionon.operationremark%type;
  v_approval_remark    quality_opionon.approvalremark%type;
begin
  begin
    select t.telconfirmremark, t.operationremark, t.approvalremark
      into v_tel_confirm_remark, v_operation_remark, v_approval_remark
      from quality_opionon t
     where t.qualityserialno = pi_serial_no;

    if v_tel_confirm_remark is not null then
      Result := '/电核类';
    end if;
    if v_operation_remark is not null then
      Result := Result || '/操作类';
    end if;
    if v_approval_remark is not null then
      Result := Result || '/审批类';
    end if;

    if Result is not null and length(Result) > 0 then
      Result := substr(Result, 2);
    end if;
  exception
    when no_data_found then
      Result := '';
  end;
  return(Result);
end getQualityErrorType;
/

