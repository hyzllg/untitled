create view V_PRPL_REPORT_PHONE_BLACK as
select
  nvl2(reportphone,substr(reportphone,1,3)||'********','') reportphone
  ,risklevel
  ,comcode
  ,repairrisktype
  ,othertypetext
  ,audittext
  ,repairmark
  ,flag
  ,inserttimeforhis
  ,operatetimeforhis
  from gdbzbusi.prpl_report_phone_black
/

