create function          getendsptime(serialnoArg in varchar2)
--审批结束时间
return  varchar2
is endtime  varchar2(40);
begin
 select begintime into endtime from flow_task where phaseno in ('2040','0050','3020','3021') and flowno='CreditFlow' and objectno=serialnoArg;
  return(endtime);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getendsptime;

/

