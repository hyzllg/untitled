create FUNCTION          getabc(pSerialnoID varchar)
return varchar
is pChannel  varchar(80);
begin
select channel into pChannel
  from business_apply
where serialno = pSerialnoID;
  return pChannel;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end;

/

