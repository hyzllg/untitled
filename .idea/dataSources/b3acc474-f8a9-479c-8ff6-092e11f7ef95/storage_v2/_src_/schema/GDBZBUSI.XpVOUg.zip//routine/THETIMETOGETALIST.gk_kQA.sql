create function thetimetogetalist(serialnoArg in varchar2)
--获单多长时间了
 return varchar2 

is
  timer varchar2(30);
begin
  SELECT 
   EXTRACT(DAY FROM (sysdate-to_date(getfirsttaskdate(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'天'
   || EXTRACT(HOUR FROM (sysdate-to_date(getfirsttaskdate(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'时'
   || EXTRACT(MINUTE FROM (sysdate-to_date(getfirsttaskdate(serialnoArg),'YYYY/MM/DD HH24:MI:ss')) DAY TO SECOND )
   ||'分' into timer
FROM DUAL;
  return(timer);
 
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN 
  return '';
end thetimetogetalist;
/

