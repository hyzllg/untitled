create view V_COLLECTIONCASELIST1 as
select ci.serialno,
       al.customerName as customerName,
       ci.accounttype as accounttype,
       getItemName('CollectionAccountType', ci.accounttype)  as caseType,
       getrecommend(al.baserialno) as segmentrecommend,
       ci.certid as certid,
       ci.contractNo,
       al.putoutno,
       ci.caseresidualamount as monthBeginBalance,
       nvl(al.normalbalance, 0) + nvl(al.overduebalance, 0) as stageBalance,
       case
         when nvl(al.overduedays, 0) = 0 then
          0
         else
          nvl(al.overduebalance, 0) + nvl(al.interestbalance, 0) +
          nvl(al.fineintebalance, 0) + nvl(al.feeamtbalance, 0) +
          nvl(al.overduefinebalance, 0)
       end as overdueSum,
       al.overduedays as overdays,
       ci.overstageyc as overduestage,
       ci.overstage,
       getItemName('AccountBank', ci.coopbank) as coopbank,
       al.putoutdate as signdate,
       substr(al.nextpaydate, 9, 10) as actualpaydate,
       al.pmtamount + al.PMTGUEFEE as pmtamount,
       ci.isclaim,
       case
         when ci.isclaim = '0' then
          '未理赔'
         else
          '理赔'
       end as isclaimname,
       ci.firstorgid as manageorgid,
       getItemName('CuiShouCode', ci.lastoperate) as lastoperate,
       ci.calltime as calltime,
       ci.promisesum,
       ci.promisedate,
       ci.lastfollowtime as lastfollow,
       ci.collectionuserid as collectuserid,
       case
         when ci.accounttype = '03' then
          getOutName(ci.collectionuserid)
         when ci.accounttype = '04' then
          getlawname(ci.collectionuserid)
         else
          getUserName(ci.collectionuserid)
       end as collectuseridName,
       ci.lnsacct,
       ci.phonenum,
       getworkcorp(al.customerid) as workcorp,
       ci.customerid,
       case
         when ci.TRAURESULT = '1' then
          '同意'
         when ci.TRAURESULT = '2' then
          '拒绝'
         else
          ''
       end as TRAURESULT,
       case
         when ci.WAFARESULT = '1' then
          '同意'
         when ci.WAFARESULT = '2' then
          '拒绝'
         else
          ''
       end as WAFARESULT,
       case
         when ci.SKIPRESULT = '1' then
          '同意'
         when ci.SKIPRESULT = '2' then
          '拒绝'
         else
          ''
       end as SKIPRESULT,
       case
         when ci.accounttype = '03' then
          (case
            when ci.overdays > 0 and ci.overdays <= 180 then
             '15%'
            when ci.overdays > 180 and ci.overdays <= 270 then
             '25%'
            when ci.overdays > 270 and ci.overdays <= 360 then
             '30%'
            when ci.overdays > 360 and ci.overdays <= 720 then
             '35%'
            when ci.overdays > 720 then
             '40%'
            else
             ''
          end)
         else
          ''
       end as moneyrate,
       split(ci.personFlag) as personFlag,
       al.defaultpayacctno,
       al.businesssum,
       getsalesusername(al.baserialno) as salesusername,
       case
         when (getabc(al.baserialno) = 'CH2015080600000001') then
          ''
         else
          getsalesdirectorname(al.baserialno)
       end as salesdirectorname,
        ci.firstorgid,
       ci.lastorgid
  from collection_info ci, acct_loan al
 where ci.isinuse = '1'
  and al.contractserialno=ci.contractno and al.customerid=ci.customerid
   and al.serialno = ci.lnsacct
/

