create view V_ICR_RPT_T10 as
SELECT
RPTNO,
F0,
F1,
F2,
NVL2(F3,SUBSTR(F3,1,4)||'************'||SUBSTR(F3,17),'') F3,
F4,
F5,
F6,
F7,
F8,
F9,
F10,
F11,
NVL2(F12,SUBSTR(F12,1,3)||'********','') F12,
F13,
F14,
F15,
F16,
NVL2(F17,SUBSTR(F17,1,4)||'************'||SUBSTR(F17,17),'') F17,
F18,
F19,
F20,
F21,
F22,
F23,
NVL2(F24,SUBSTR(F24,1,3)||'********','') F24,
F25,
F26,
F27,
F28,
F29,
F30,
F31
FROM gdbzbusi.ICR_RPT_T10

/

