create FUNCTION          getwriteoffSearch(serialnoArs varchar2)
return number
is amount  number(24,2);
begin
  select -sum(nvl(realpayamt,0)) into amount
  from claimamtinfo
  where serialno=serialnoArs and paytype='3' and status='10';
  return amount;
end;


/

