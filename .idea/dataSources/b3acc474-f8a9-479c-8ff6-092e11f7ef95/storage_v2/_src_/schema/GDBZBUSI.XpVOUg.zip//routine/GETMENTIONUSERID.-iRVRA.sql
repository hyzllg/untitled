create FUNCTION          getmentionuserid(pSerialno varchar)
--获取案件最新提报人
return varchar
is pMentionUserId  varchar(80);
begin
select mi1.mentionuserid into pMentionUserId from mentionfraud_info mi1 where mi1.objectno = pSerialno and mi1.isinuse='1'
  and serialno = (select max(serialno) from mentionfraud_info mi where mi.objectno=mi1.objectno and isinuse='1'  );
return pMentionUserId;
end;

/

