create function GETENTRYAPPROVETIME(serialnoArg in varchar2)
return varchar2
is ApproveBegintime varchar2(20)  ;
begin
  select to_char(min(to_date(substr(begintime, 1, 10), 'yyyy/mm/dd')),
                 'yyyy/MM/dd') into ApproveBegintime
    from flow_task ft, business_apply ba
   where ft.objectno = ba.serialno
     and ba.serialno = serialnoArg;

  return ApproveBegintime;
end GETENTRYAPPROVETIME;
/

