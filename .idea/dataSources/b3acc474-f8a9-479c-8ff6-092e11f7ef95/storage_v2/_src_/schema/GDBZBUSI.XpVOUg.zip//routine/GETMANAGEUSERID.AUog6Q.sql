create function GetManageUserID(useridArg in varchar2)
return varchar2
is userResult varchar2(200) ;
begin
select userid into userResult
  from user_info u1
 where u1.attribute3 like '%销售主任'
 and u1.belongteam = (select u2.belongteam
                                     from user_info u2
                                    where u2.userid = useridArg and u2.status='1') and u1.status='1';
  return userResult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetManageUserID;
/

