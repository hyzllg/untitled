create FUNCTION getSADREShortItems1
(
   pType VARCHAR2,pStr varchar2
)
RETURN varchar2
IS
v_Result varchar2(2000)
;
v_idx    integer
;
v_curIdx integer
;
v_TempId varchar2(80)
;
v_Name   varchar2(80)
;
v_counter integer
;
BEGIN
v_idx    :=
-1
;
v_counter := 1
;
v_Result := ''
;
if(pStr is null or pStr='') then
return pStr
;
end if
;
v_idx := INSTR(pStr,',')
;
while (v_idx > 0) loop
v_TempId := subStr(pStr,1,v_idx-1)
;
v_Name := SADREItemName(pType,v_TempId)
;
if (v_Name is not null) then if (v_counter=1) then v_Result := v_Name
;
else  v_Result := v_Result||','||v_Name
;
end if
;
end if
;
 v_curIdx
:= v_idx+1
;
--鎸囬拡绉诲姩
  v_idx  := INSTR(pStr,',',v_curIdx)
;
 v_counter := v_counter+1
;
if (v_counter>3) then  v_curIdx := length(pStr)+1
;
 v_idx := 0
;
 v_Result := v_Result||' ...'
;
end if
;
end loop
;
 v_Name := SADREItemName(pType,pStr)
;
if (v_Name is not null) then  v_Result := v_Name
;
end if
;
return v_Result
;
END
;
/

