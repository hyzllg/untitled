create FUNCTION          getworkcorp(pCustomerId varchar2)
return varchar2
is pWorkCorp  varchar2(800);
begin
select nvl(workcorp,'') into pWorkCorp from customer_work where CUSTOMERID = pCustomerId;

return pWorkCorp;
end;

/

