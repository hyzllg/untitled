create FUNCTION getLoanStatusName(sSerialNo varchar)
return varchar
is sStatusName varchar(20);
begin
   select getitemname('LoanStatus',Loanstatus) into sStatusName from ACCT_LOAN
   where baSerialNo=sSerialNo;
   if sStatusName is not null then
      return sStatusName;
   else
       return '';
   end if;
end;
/

