create function          getcsuserleader(idArg in varchar2)
--得到催收人员的组长
return varchar2

is
  leader varchar2(20);
begin
  select getusername(leader) into leader
    from urge_team_info
   where teamid = (select teamid from user_info  where userid = idArg );
  return(leader);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getcsuserleader;

/

