create view V_MAINLOANDTO as
select ba.serialno,
       (select attribute3
          from code_library
         where codeno = 'AccountBank'
           and itemno = ba.copobank) "loanBankCode",
       nvl(ba.signsum, 0) "loanAmount",
       to_char(to_date(ba.signtime, 'yyyy/MM/dd hh24:mi:ss') + 1,
               'yyyy-MM-dd') "loanDate",
       to_char(add_months(to_date(ba.signtime, 'yyyy/MM/dd hh24:mi;ss') + 1,
                          ba.signterm),
               'yyyy-MM-dd') "repaidDate",
       ba.contractserialno "loanContractNo"
  from business_apply ba
 where ba.serialno like '201807%'
   and ba.signsum > 0
   and ba.signtime is not null
--and  ba.contractserialno is not null
--and ba.serialno = '2018040900000065'
 order by serialno desc
/

