create FUNCTION getxzqname(pItemNo1 varchar2,pItemNo2 varchar2,pItemNo3 varchar2)
return varchar2
is  pItemName  varchar2(200);
begin
  pItemName:='';
  select getitemname('AreaCodeP',pItemNo1)||''||getitemname('AreaCodeC',pItemNo2)||''||getitemname('AreaCodeD',pItemNo3) into pItemName
  from dual
  where 1=1;
  return pItemName;
end;
/

