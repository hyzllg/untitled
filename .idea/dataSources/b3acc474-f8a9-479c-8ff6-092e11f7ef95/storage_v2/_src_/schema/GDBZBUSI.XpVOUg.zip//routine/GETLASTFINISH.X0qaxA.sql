create function getLastFinish(over_date in varchar2(50),oldApplyNo in varchar2(100),newApplyNo in varchar2(100))
return varchar2(500)
is over_date varchar2(50);
    oldApplyNo varchar2(100);
    newApplyNo varchar2(100);
BEGIN
    FOR cur IN (
        select allBa.NEWAPPROVEBASERIALNO, allBa.customerid, allBa.SERIALNO, allBa.INPUTDATE
        from BUSINESS_APPLY allBa
        where allBa.NEWAPPROVEBASERIALNO in ('2018121800011282',
                                             '2018101300002276',
                                             '2017101700001343',
                                             '2018091000006441',
                                             '2018050900000090',
                                             '2018090300007163',
                                             '2018032700002869',
                                             '2018031000000165',
                                             '2018031500002845',
                                             '2018061900000727',
                                             '2018031500001587',
                                             '2017090800001118',
                                             '2018030400000579',
                                             '2018121200008399',
                                             '2017110800002520',
                                             '2018060700002055',
                                             '2018093000003204',
                                             '2017041800001044',
                                             '2017053100001317',
                                             '2018090500007388',
                                             '2018031500000473',
                                             '2018090500005414',
                                             '2018073000004064',
                                             '2018062600007380',
                                             '2019011600001068',
                                             '2017122000001970',
                                             '2017103000001500',
                                             '2019011900001932',
                                             '2018103100004266',
                                             '2018091100003414',
                                             '2018082000007125',
                                             '2017081800000097',
                                             '2018081600006443',
                                             '2018030200001551',
                                             '2018062800003676',
                                             '2018101800005790',
                                             '2018102600002721',
                                             '2018091900002303',
                                             '2018022800000542',
                                             '2018082900003785',
                                             '2019031200002408',
                                             '2018061300007542',
                                             '2018031600000854',
                                             '2018103100003941',
                                             '2018061100005828',
                                             '2018111300007480',
                                             '2018061000000576',
                                             '2018030700000473',
                                             '2017101200002275',
                                             '2017112700003749',
                                             '2017040500000894',
                                             '2019010600003531',
                                             '2018032200002158',
                                             '2017121400003084',
                                             '2017112700000336',
                                             '2017122500000366',
                                             '2018022800001441',
                                             '2018022800001210',
                                             '2017092000000246',
                                             '2018022800000717',
                                             '2018122400008536',
                                             '2018071900001167',
                                             '2018081500006706',
                                             '2018082100006369',
                                             '2018071200003705',
                                             '2018060500002913',
                                             '2018102400002227')
        )
        loop
            select *
            from (select al.finishdate into over_date, ba.NEWAPPROVEBASERIALNO into oldApplyNo,cur.NEWAPPROVEBASERIALNO into newApplyNo
                  from acct_loan al,
                       business_apply ba
                  where ba.customerid = al.customerid
                    and cur.CUSTOMERID = ba.CUSTOMERID
                    and ba.SERIALNO != cur.SERIALNO
                    and cur.inputdate > ba.INPUTDATE
                  order by ba.INPUTDATE desc)
            where rownum = 1;
        END loop;
END getLastFinish;
/

