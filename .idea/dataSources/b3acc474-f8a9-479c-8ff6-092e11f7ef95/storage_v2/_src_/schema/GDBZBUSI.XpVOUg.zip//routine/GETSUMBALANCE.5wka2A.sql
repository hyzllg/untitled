create function          GetSumBalance(ACTUALPAYDATEArg in varchar2)
--剩余本金
return  number
is
  sumbalance number(24,7);
begin
  select nvl(al.normalbalance, 0) + nvl(al.overduebalance, 0)
    into sumbalance
    from acct_loan_back al
   where al.putoutdate = ACTUALPAYDATEArg and al.backinputdate=(to_char(trunc(sysdate-1),'yyyy/mm/dd'));
  return sumbalance;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetSumBalance;

/

