create function getgroupleader(serialnoArg in varchar2) 
--获得审批组长姓名
return varchar2 
is
  leadername varchar2(20);
begin
  select getusername(belonguserid) into leadername
    from approve_users
   where username = GetFinalUserName(serialnoArg)
     and approvelevel = 2;

  return(leadername);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN 
  return '';
end getgroupleader;
/

