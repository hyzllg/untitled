create function getSettleAgainData(pCustomerid in VARCHAR2,pType in varchar2)
--获得结清再贷费率、理论审批金额、总无抵押金额
return Number
IS lastdata number;
ishaveOverdue number;
sobjlast varchar2(100);
nolast varchar2(100);
begin
   SELECT max(BASERIALNO) into nolast FROM acct_loan WHERE LOANSTATUS in ('10','20','30','92') and CUSTOMERID =pCustomerid;
   if nolast is not null then
     SELECT count(1) into ishaveOverdue FROM acct_payment_schedule WHERE to_date(nvl(finishdate,to_char(sysdate,'yyyy/mm/dd')),'yyyy/mm/dd')-to_date(paydate,'yyyy/mm/dd')>29 and BASERIALNO =nolast;
     if ishaveOverdue =0 then
       select serialno into sobjlast from (SELECT SERIALNO FROM flow_opinion WHERE OBJECTNO =nolast and phaseno in ('0020','0030','0035','0040','0045','0047') order by SERIALNO desc) where rownum=1;
        if pType='PREMIUM' then
          select premium into lastdata FROM flow_opinion WHERE OBJECTNO =nolast and SERIALNO =sobjlast;
        elsif pType='COUNTBUSINESSSUM' then
         SELECT nvl(CHANGECOUNTBUSINESSSUM,nvl(COUNTBUSINESSSUM,0)) into lastdata FROM flow_opinion WHERE OBJECTNO =nolast and SERIALNO =sobjlast;
        elsif pType='TATALDEBT' then
         SELECT nvl(TATALDEBT,0) into lastdata FROM flow_opinion WHERE OBJECTNO =nolast and SERIALNO =sobjlast;
        end if;
     end if;
   else lastdata:=0 ;
   end if;
  return lastdata;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return 0;
  WHEN OTHERS THEN
  return 0;
end getSettleAgainData;
/

