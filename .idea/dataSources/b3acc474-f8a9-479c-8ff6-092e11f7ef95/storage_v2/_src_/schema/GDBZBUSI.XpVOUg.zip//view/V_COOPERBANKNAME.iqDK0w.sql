create view V_COOPERBANKNAME as
select getitemname('PutOutOrg', ba.copobank) COOPERBANKNAME, p.attribute6 attribute6
from Acct_Loan al,business_intfgl BI,business_apply ba,PREMIUM_INCOME p
  Where BI.business_type1 IN ('V00', 'XB12','R00','XB05')
 and ba.serialno=al.baserialno
AND BI.ATTRIBUTE6 = AL.PUTOUTNO
and p.attribute6 = BI.ATTRIBUTE6
/

