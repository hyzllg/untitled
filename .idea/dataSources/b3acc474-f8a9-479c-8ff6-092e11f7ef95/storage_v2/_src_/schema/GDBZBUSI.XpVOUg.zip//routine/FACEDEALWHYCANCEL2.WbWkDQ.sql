create function facedealwhycancel2(serialnoArg in varchar2)
return varchar2
is cancelreanson varchar2(400);

begin

 select distinct case when fo.Phaseno='1100' then rp.Mainreason else  rp.subreason end as opinino into cancelreanson from reason_param rp,flow_opinion fo
where rp.mainreasoncode=fo.reasoncode1
and rp.subreasoncode = fo.reasoncode2
and rp.flowno='CreditFlow'
and fo.reasoncode1 is not null and fo.phasechoice like '%拒绝%' AND fo.phasechoice not like '%自动拒绝%'
AND fo.phasechoice NOT LIKE '%实时拒绝%' and fo.phasechoice !='拒绝'
and rp.reasontype='10'
and fo.objectno=serialnoArg
and fo.objecttype='CreditApply';

  return(cancelreanson);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end facedealwhycancel2;
/

