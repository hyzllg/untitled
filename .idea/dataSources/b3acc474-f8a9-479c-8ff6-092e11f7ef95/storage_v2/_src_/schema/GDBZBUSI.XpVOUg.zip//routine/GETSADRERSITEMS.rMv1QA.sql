create FUNCTION getSADRERSItems
(
   pStr varchar2
)
RETURN varchar2
IS
v_Result varchar2(800);
v_idx   integer;
v_curIdx integer;
v_TempId varchar2(80);
v_Name   varchar2(80);
v_counter integer;
BEGIN
v_idx    := -1;
v_curIdx := 1;
v_Result := '';
v_counter := 0;
if pStr is null or pStr='' then return pStr;
end if;
v_idx := INSTR(pStr,',');
while(v_idx > 0) loop v_TempId := subStr(pStr,v_curIdx,(v_idx-v_curIdx));
select RoleName into v_Name from ROLE_INFO where RoleId = v_TempId;
if (v_Name is not null) then v_Result := v_Result||','||v_Name;
end if;
v_curIdx := v_idx+1;
--鎸囬拡绉诲姩
v_idx  :=  INSTR(pStr,',',v_curIdx);
v_counter := v_counter+1;
if (v_counter>=5) then v_curIdx := length(pStr)+1;
v_idx := 0;
v_Result := v_Result||' ...';
end if;
end loop;
v_TempId := subStr(pStr,v_curIdx);
select RoleName into v_Name from ROLE_INFO where RoleId = v_TempId;
if (v_Name is not null) then v_Result := v_Result||','||v_Name;
end if;
if length(v_Result)>0 then return substr(v_Result,2);
end if;
return v_Result;
END;
/

