create function geterrornumber(strnum in varchar2)
 return number is
  num number;
begin
  select to_number(strnum) into num
    from dual;
  return(num);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end geterrornumber;
/

