create function getalarmmodelname(pAlarmModelNo varchar)
return varchar
is
pAlarmModelName  varchar2(80);
begin
select AlarmModelName into pAlarmModelName
from ALARM_MODEL
where AlarmModelNo=pAlarmModelNo;
return pAlarmModelName;
end;
/

