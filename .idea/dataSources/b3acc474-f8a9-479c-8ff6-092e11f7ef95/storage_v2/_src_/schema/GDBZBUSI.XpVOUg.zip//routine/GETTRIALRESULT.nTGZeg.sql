create function GetTrialResult(serialnoArg in varchar2)
--获取初审结论
return varchar2
is trialresult varchar2(200) ;
begin
  select getLastPhaseName('CreditApply',serialnoArg,'CreditFlow') into trialresult from dual;
  if trialresult = '复核' then
  select phaseaction into trialresult from flow_task where phaseno='0030' and objectno = serialnoArg and flowno='CreditFlow';
else
  select phaseaction into trialresult
    from flow_task
   where flowno='CreditFlow'
     and objectno = serialnoArg
     and serialno = (select max(serialno)
                       from flow_task
                      where objectno = serialnoArg
                        and phaseno in ('0030','0035') and phaseaction is not null and flowno='CreditFlow');
 end if;
  return trialresult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetTrialResult;
/

