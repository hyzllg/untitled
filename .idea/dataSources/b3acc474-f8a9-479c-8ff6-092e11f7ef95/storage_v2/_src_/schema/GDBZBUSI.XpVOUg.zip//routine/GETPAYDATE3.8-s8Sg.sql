create function          getpaydate3(serialnoArg in varchar2)
--获得最近一次逾期日期
return varchar2
is
  paydate varchar2(20);
begin
  select case when loanstatus in('90','91','92') then 'true' else 'false' end  into paydate from acct_loan where baserialno=serialnoArg ;
  if paydate='true' then
  select max(paydate)
    into paydate
    from acct_payment_schedule
   where baserialno = serialnoArg
     and to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate)
     and nvl(finishdate,'2999/12/31')>paydate;
 else
   select max(paydate)
    into paydate
    from acct_payment_schedule
   where baserialno = serialnoArg
     and to_date(paydate, 'yyyy/mm/dd') < trunc(sysdate)
     and finishdate is null;
 end if;
  return(paydate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getpaydate3;

/

