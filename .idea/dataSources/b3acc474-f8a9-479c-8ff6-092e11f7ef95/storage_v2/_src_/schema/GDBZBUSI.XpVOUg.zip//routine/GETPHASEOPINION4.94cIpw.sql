create FUNCTION          getphaseopinion4(pSerialno varchar2)
return varchar2 is
pPhaseno varchar2(80);
pPhaseopinion4  varchar2(80);
begin
select distinct max(phaseno) into pPhaseno from flow_task where objectno = pSerialno;
select distinct Phaseopinion4  into pPhaseopinion4 from flow_task where objectno = pSerialno and phaseno=pPhaseno;
return pPhaseopinion4;
end;

/

