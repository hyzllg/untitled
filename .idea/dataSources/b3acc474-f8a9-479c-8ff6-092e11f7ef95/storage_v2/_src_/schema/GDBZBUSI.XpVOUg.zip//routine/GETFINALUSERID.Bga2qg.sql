create function getfinaluserid(baserialno in varchar2)
--获取终审姓名ID
return varchar2
 is
  finaluserid varchar2(32);
begin
select userid into finaluserid
  from flow_task
 where serialno = (select max(serialno)
                     from flow_task
                    where phaseno in( '0040','0045')
                      and objectno = baserialno and flowno='CreditFlow');
  return(finaluserid);
   EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getfinaluserid;
/

