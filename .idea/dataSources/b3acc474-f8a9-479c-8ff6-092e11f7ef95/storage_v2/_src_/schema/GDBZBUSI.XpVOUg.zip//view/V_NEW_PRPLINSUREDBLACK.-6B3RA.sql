create view V_NEW_PRPLINSUREDBLACK as
select case when length(INSUREDCODE)>2 then lpad(substr(INSUREDCODE,length(INSUREDCODE)-1,2),length(INSUREDCODE),'*') else INSUREDCODE end as INSUREDCODE ,
       INSUREDNAME,
       INSUREDTYPE,
       INSERTTIMEFORHIS,
       CREATETIME,
       REPAIRMARK,
       REPAIRRISKTYPE,
       TYPE,
       NATIONALITY,
       PERSON_ID
  FROM gdbzbusi.new_prplinsuredblack
/

