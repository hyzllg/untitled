create function GETOPINIONSUM(serialnoArg in varchar2)
return varchar2
is signtime varchar2(20) ;
begin
Select to_char(round(decode(fo.VERIFYEARNTYPE,'10',nvl(fo.AUTOCOUNT,0),nvl(fo.MANULEVALUATE,0)),2)) INTO signtime From Flow_Opinion fo where fo.OpinionNo
in (Select Max(fo1.OpinionNo) From Flow_Opinion fo1 where fo1.objectno=serialnoArg);
   if signtime is not null then
     if(signtime<=3000) THEN SIGNtime:='4001' ;
     ELSIF (3000<signtime AND signtime<=6000) THEN signtime:='4002' ;
       ELSIF (6000<signtime AND signtime<=10000) THEN signtime:='4003';
         ELSIF(10000<signtime AND signtime<=15000) THEN signtime:='4004' ;
           ELSIF(15000<signtime AND signtime<=20000) THEN signtime:='4005' ;
             ELSIF (signtime>20000) THEN signtime:='4006' ;

     else signtime:='4001' ;
     end if;
   end if;
  return signtime;
END  GETOPINIONSUM;
/

