create function          getcaserate(idArg in  varchar2,stageArg in varchar2,isGuaranty in varchar2)
--得到催收人员某阶段有效分案比例
return number is
  caserate number;
begin
  select caserate into caserate
    from caserate
   where casenewuserid = idArg
     and casestage = stageArg
     and relbusinesstype = isGuaranty
     and isinuse = '1';
  return(caserate);
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end getcaserate;
/

