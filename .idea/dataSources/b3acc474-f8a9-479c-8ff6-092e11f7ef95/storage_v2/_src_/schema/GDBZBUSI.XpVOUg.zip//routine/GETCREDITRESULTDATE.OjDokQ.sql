create function getCreditResultDate(serialnoArg in varchar2)
--取征信结论时间
return varchar2
is CreditResultDate  varchar2(200) ;
begin 
  select irh00.f1 
    into CreditResultDate 
    from ICR_RPT_H00 irh00, icr_cda ic  
   where ic.reportno = irh00.rptno 
     and ic.objectno = serialnoArg;
  return CreditResultDate; 
 EXCEPTION 
   WHEN NO_DATA_FOUND THEN 
    return '';
  WHEN OTHERS THEN 
    return '';
end getCreditResultDate;
/

