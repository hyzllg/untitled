create FUNCTION getreportname(pReportNo varchar)
return varchar
is pReportName  varchar(80);
begin
  select ReportName into pReportName from FINANCE_CATALOG where  ReportNo = pReportNo;
  return pReportName;
end;
/

