create function GetMainProductName(MainProductTypeArg in varchar2)
return varchar2
is mainproductname varchar2(40);
begin
  select typename into mainproductname from business_type where typeno=MainProductTypeArg;
  return mainproductname;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN
  return '';
end GetMainProductName;
/

