create FUNCTION getECRInfo(pInputstr  VARCHAR,pFlag VARCHAR)
RETURN VARCHAR
/*
  Author:       fhuang
  Time:        2007-02-08
  Content:    ???????????
  Input Param:  pInputstr ??????
  				pFlag?????
                  pFlag=01,?????????,??????????
                  pFlag=02,?????????,????????
                  pFlag=03,?????????,??????
                  pFlag=04,?????????,????????
                  pFlag=05,??????????,??????(1??2??)
  Return param: pReturn ???
  History Log:
  */
IS
pReturn  VARCHAR2(32);
iCount    INTEGER;
BEGIN

IF pFlag='01' THEN
	SELECT LicenseNo INTO pReturn
	FROM ENT_INFO
	WHERE CustomerID = pInputstr
	AND TempSaveFlag = '2';
ELSIF pFlag='02' THEN
    SELECT Attribute24 into pReturn
    FROM BUSINESS_TYPE
    WHERE TypeNo = pInputstr
    AND IsInUse = '1';
ELSIF pFlag='03' THEN
    SELECT Attribute25 into pReturn
    FROM BUSINESS_TYPE
    WHERE TypeNo = pInputstr
    AND IsInUse = '1';
ELSIF pFlag='04' THEN
    SELECT Attribute23 into pReturn
    FROM BUSINESS_TYPE
    WHERE TypeNo = pInputstr
    AND IsInUse = '1';
ELSIF pFlag='05' THEN
    SELECT Count(GC.SerialNo) into iCount
    FROM GUARANTY_CONTRACT GC,CONTRACT_RELATIVE CR
    WHERE GC.SerialNo = CR.ObjectNo
    and CR.SerialNo = pInputstr
    and CR.ObjectType = 'GuarantyContract'
    AND GC.ContractStatus = '020';
    IF iCount>0 THEN
         pReturn := '1';
     ELSE
          pReturn := '2';
      END IF;
END IF;
RETURN pReturn;
END;
/

