create function getCreditResult(serialnoArg in varchar2)
--查看征信结论
return varchar2
is creditResult  varchar2(200) ;
begin 
  select irh.f7 into creditResult 
    from ICR_RPT_H01 irh, icr_cda ic
   where ic.reportno = irh.rptno
     and ic.objectno = serialnoArg;
  return creditResult;
  EXCEPTION
  WHEN NO_DATA_FOUND THEN
  return '';
  WHEN OTHERS THEN 
  return '';
end getCreditResult;
/

