create function GetloanCardMaxUseRate(serialnoArg in varchar2)
--人行贷记卡最高使用率
return varchar2
is CardMaxUseRate  varchar2(200) ;
begin 
  select max(case 
           when nvl(irt30.f9,0)=0 then 
            0 
           else 
            trunc(irt30.f10/irt30.f9,4) 
         end) 
    into CardMaxUseRate 
    from ICR_RPT_T30 irt30, icr_cda ic
   where ic.reportno = irt30.rptno 
     and ic.objectno = serialnoArg;
  return CardMaxUseRate; 
 EXCEPTION 
   WHEN NO_DATA_FOUND THEN 
    return '';
  WHEN OTHERS THEN 
    return '';
end GetloanCardMaxUseRate;
/

