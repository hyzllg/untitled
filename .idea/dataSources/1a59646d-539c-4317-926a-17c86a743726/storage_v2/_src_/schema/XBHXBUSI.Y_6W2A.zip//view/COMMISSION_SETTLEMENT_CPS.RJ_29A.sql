create view COMMISSION_SETTLEMENT_CPS as
select loanserialno,
       contractserialno,
       bp.policyno,
       putoutdate,
       ddproductid as ddproductid1,
       ddproductid as ddproductid2,
       bp.businesssum,
       businesstermmonth,
       nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)/1200 as assurefeerate1,
       nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)*nvl(bp.businesstermmonth,0)/1200 as businesstermmonth1,
       COMMISSIONRATE,
       nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)*nvl(bp.businesstermmonth,0)*nvl(COMMISSIONRATE,0)/120000 as COMMISSIONRATE1,
       assurefeerate,
       DDPRODUCTID as ddproductid3,
       DDPRODUCTID as ddproductid4,
       bp.create_date as CREATE_DATE,
       transendtime
from  BUSINESS_INSURANCEPOLICYINFO O,BUSINESS_PUTOUT bp
where O.POLICYNO=BP.POLICYNO and bp.PRODUCTID in(select cl.itemattribute from CODE_LIBRARY cl where CODENO='AgentOrgParamList')
/

