create view COMMISSION_SETTLE_CPSREPORT as
select loanserialno,
    bp.contractartificialno as contractserialno,
    bp.policyno,
    putoutdate,
    ddproductid as ddproductid1,
    ddproductid as ddproductid2,
    bp.businesssum,
    businesstermmonth,
    nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)/1200 as assurefeerate1,
    round(nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)/1200,2)*nvl(bp.businesstermmonth,0) as businesstermmonth1,
    COMMISSIONRATE,
    nvl(bp.businesssum,0)*nvl(bp.assurefeerate,0)*nvl(bp.businesstermmonth,0)*nvl(COMMISSIONRATE,0)/120000 as COMMISSIONRATE1,
    assurefeerate,
    DDPRODUCTID as ddproductid3,
    DDPRODUCTID as ddproductid4,
    bp.create_date as CREATE_DATE,
    transendtime
from  BUSINESS_INSURANCEPOLICYINFO O,BUSINESS_PUTOUT bp
where O.POLICYNO=BP.POLICYNO and bp.PRODUCTID in(select cl.itemattribute from CODE_LIBRARY cl where CODENO='AgentOrgParamList') and O.create_time < to_date('2021/05/24 17:00:00','yyyy/mm/dd hh24:mi:ss')
/

