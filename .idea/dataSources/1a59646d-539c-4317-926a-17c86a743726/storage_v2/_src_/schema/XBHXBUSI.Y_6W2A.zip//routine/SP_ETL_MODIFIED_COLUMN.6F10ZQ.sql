create procedure sp_etl_modified_column(v_data_time in varchar2 default to_char(sysdate,'yyyymmdd')) authid current_user is
  /**************************************************************************
  #  Name      :  sp_etl_modified_column
  #  Author    :
  #  Desc      :  collect modified column
  #  Create    :  2020-03-25
  #  Source    :
  #  Temp      :
  #  Output    :
  #  Version   :  1.0
  #  Command   :
  #  Modify    :
  #  Note      :
  ***************************************************************************/

--定义变量

  --公用变量
  PRONAME          varchar2(200)  default 'sp_etl_modified_column';
  PROCDESC         varchar2(1000) default 'collect modified column';
  STEP             varchar2(1000) default '0';
  V_ROW_COUNT      integer        default  0;
  V_HOUR           varchar2(20);
  V_DATE           varchar2(20);
  V_DATE_12PM      date;
  V_DATE_1D_BF     varchar2(20);
  V_DATE_3D_BF     varchar2(20);

  V_CNT            integer        default  0;
  V_RUN_START_TIME date;
  V_RUN_END_TIME   date;
  --V_ERROR_CODE     varchar2(20);
  --V_ERROR_MESSAGE  varchar2(1000);


begin

    STEP        := '程序开始执行';
    V_RUN_START_TIME := SYSDATE;


    select to_char(sysdate,'HH24')
    into v_hour
    from dual;

    select to_char(sysdate,'yyyymmdd')
    into v_date
    from dual;

    select to_char(sysdate-1,'yyyymmdd')
    into v_date_1d_bf
    from dual;

    select to_char(sysdate-3,'yyyymmdd')
    into v_date_3d_bf
    from dual;

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;

    insert into t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP        := '预处理1';
    V_RUN_START_TIME := SYSDATE;
    execute immediate 'truncate table t_etl_tab_column';

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;

    insert into t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

     STEP        := '预处理2';
     V_RUN_START_TIME := SYSDATE;
     V_DATE_12PM := to_date(v_date ||' 12:00:00','yyyymmdd hh24:mi:ss');

    if v_hour <= 12 then

     select count(1)
       into   v_cnt
       from   all_tables
       where  owner = upper('xbhxbusi')
       and    table_name = upper('t_etl_tab_column_')||V_DATE_1D_BF||'_2';

     if v_cnt = 0 then
         insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,'无前一批次备份表','0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
         commit;
       end if;

     select count(1)
     into   v_cnt
     from   all_tables
     where  owner = upper('xbhxbusi')
     and    table_name = upper('t_etl_tab_column_')||v_date||'_1';

     if v_cnt = 0 then
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'||v_date||'_1 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
      elsif v_cnt > 0 then
          execute immediate 'drop table xbhxbusi.t_etl_tab_column_'||v_date||'_1';
          execute immediate 'create table xbhxbusi.t_etl_tab_column_'||v_date||'_1 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
      end if;

      execute immediate 'insert into t_etl_tab_column select * from t_etl_tab_column_'||V_DATE_1D_BF||'_2';
      delete from t_etl_modified_column where etl_time >= trunc(sysdate) and etl_time <  V_DATE_12PM;


    elsif v_hour > 12 then

     select count(1)
       into   v_cnt
       from   all_tables
       where  owner = upper('xbhxbusi')
       and    table_name = upper('t_etl_tab_column_')||v_date||'_1';

     if v_cnt = 0 then
         insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,'无前一批次备份表','0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
         commit;
       end if;

      select count(1)
      into   v_cnt
      from   all_tables
      where  owner = upper('xbhxbusi')
      and    table_name = upper('t_etl_tab_column_')||v_date||'_2';

      if v_cnt = 0 then
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'|| v_date||'_2 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
      elsif v_cnt > 0 then
         execute immediate 'drop table xbhxbusi.t_etl_tab_column_'||v_date||'_2';
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'||v_date||'_2 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
      end if;

      execute immediate 'insert into t_etl_tab_column select * from t_etl_tab_column_'||v_date||'_1';
      delete from t_etl_modified_column where etl_time >= V_DATE_12PM and etl_time <  trunc(sysdate+1);

    end if;

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;

    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP := '字段增加';
    V_RUN_START_TIME := SYSDATE;

     insert into t_etl_modified_column
               (source_db,
               source_owner,
               table_name,
               column_name,
               --comments,
               modified_type,
               source_data_type,
               source_data_length,
               source_nullable,
               etl_time
               )
     select    'XSHX'           source_db,
               t1.owner            source_owner,
               t1.table_name       table_name,
               t1.column_name      column_name,
               'A'                 modified_type,
               --t1.comments         comments,
               t1.data_type        source_data_type,
               t1.data_length      source_data_length,
               t1.nullable         source_nullable,
               sysdate             etl_time
     from     (select    k1.*
               from      all_tab_columns      k1,
                         t_etl_hadoop_table   k2
               where     trim(k1.table_name) = trim(k2.table_name)
               and       trim(k1.owner) = trim(k2.owner)
               and       trim(k2.owner) = upper('xbhxbusi')
               )                                 t1
     left join
               (select   k1.*
               from      t_etl_tab_column   k1,
                         t_etl_hadoop_table  k2
               where     trim(k1.table_name) = trim(k2.table_name)
               and       trim(k1.owner) = trim(k2.owner)
               and       trim(k2.owner) = upper('xbhxbusi')
                 )                                t2
     on       t1.table_name = t2.table_name
     and      t1.column_name = t2.column_name
     where    t2.column_name is null;

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;
    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP := '字段减少';
    V_RUN_START_TIME := SYSDATE;

     insert into t_etl_modified_column
               (source_db,
               source_owner,
               table_name,
               column_name,
               --comments,
               modified_type,
               data_type,
               data_length,
               nullable,
               etl_time
               )
     select    'XSHX'           source_db,
               t1.owner            source_owner,
               t1.table_name       table_name,
               t1.column_name      column_name,
               'D'                 modified_type,
               --t1.comments         comments,
               t1.data_type        data_type,
               t1.data_length      data_length,
               t1.nullable         nullable,
               sysdate             etl_time
     from     (select    k1.*
               from      t_etl_tab_column     k1,
                         t_etl_hadoop_table   k2
               where     trim(k1.table_name) = trim(k2.table_name)
               and       trim(k1.owner) = trim(k2.owner)
               and       trim(k2.owner) = upper('xbhxbusi')
               )                                 t1
     left join
               (select   k1.*
               from      all_tab_columns     k1,
                         t_etl_hadoop_table  k2
               where     trim(k1.table_name) = trim(k2.table_name)
               and       k1.owner = trim(k2.owner)
               and       trim(k2.owner) = upper('xbhxbusi')
               )                                t2
     on       t1.table_name = t2.table_name
     and      t1.column_name = t2.column_name
     where    t2.column_name is null;

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;
    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP := '类型变更';
    V_RUN_START_TIME := SYSDATE;

     insert into t_etl_modified_column
               (source_db,
               source_owner,
               table_name,
               column_name,
               --comments,
               modified_type,
         source_data_type,
               data_type,
         source_data_length,
               data_length,
         source_nullable,
               nullable,
               etl_time
               )
     select    'XSHX'           source_db,
               t1.owner            source_owner,
               t1.table_name       table_name,
               t1.column_name      column_name,
               'M'                 modified_type,
               --t1.comments         comments,
         t2.data_type        source_data_type,
               t1.data_type        data_type,
         t2.data_length      source_data_length,
               t1.data_length      data_length,
         t2.nullable         source_nullable,
               t1.nullable         nullable,
               sysdate             etl_time
     from     (select    k1.*
               from      t_etl_tab_column     k1,
                         t_etl_hadoop_table   k2
               where     trim(k1.table_name) = trim(k2.table_name)
               and       trim(k1.owner) = trim(k2.owner)
               and       trim(k2.owner) = upper('xbhxbusi')
               )                                 t1
     inner join
               (select   k1.*
               from      all_tab_columns     k1,
                         t_etl_hadoop_table  k2
               where     trim(k1.table_name) = trim(k2.table_name)
               and       k1.owner = trim(k2.owner)
               and       trim(k2.owner) = upper('xbhxbusi')
               )                                t2
     on       t1.table_name = t2.table_name
     and      t1.column_name = t2.column_name
     and     (t1.data_type <> t2.data_type
     or       t1.data_length <> t2.data_length
     or       t1.nullable <> t2.nullable
   );

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;
    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP := '创建快照';
    V_RUN_START_TIME := SYSDATE;

    if v_hour <= 12 then
       select count(1)
       into   v_cnt
       from   all_tables
       where  owner = upper('xbhxbusi')
       and    table_name = upper('t_etl_tab_column_')||v_date||'_1';

       if v_cnt = 0 then
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'||v_date||'_1 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
       elsif v_cnt > 0 then
         execute immediate 'drop table xbhxbusi.t_etl_tab_column_'||v_date||'_1';
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'||v_date||'_1 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
       end if;

    elsif v_hour > 12 then
       select count(1)
       into   v_cnt
       from   all_tables
       where  owner = upper('xbhxbusi')
       and    table_name = upper('t_etl_tab_column_')||v_date||'_2';

       if v_cnt = 0 then
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'|| v_date||'_2 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
       elsif v_cnt > 0 then
         execute immediate 'drop table xbhxbusi.t_etl_tab_column_'||v_date||'_2';
         execute immediate 'create table xbhxbusi.t_etl_tab_column_'||v_date||'_2 as select owner, table_name, column_name, data_type, data_type_mod, data_type_owner, data_length, data_precision, data_scale, nullable, column_id, default_length, num_distinct, low_value, high_value, density, num_nulls, num_buckets, last_analyzed, sample_size, character_set_name, char_col_decl_length, global_stats, user_stats, avg_col_len, char_length, char_used, v80_fmt_image, data_upgraded, histogram, default_on_null, identity_column, evaluation_edition, unusable_before, unusable_beginning from sys.all_tab_columns';
       end if;
      end if;

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;
    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP := '清除历史快照';
    V_RUN_START_TIME := SYSDATE;

       select count(1)
       into   v_cnt
       from   all_tables
       where  owner = upper('xbhxbusi')
       and    table_name = upper('t_etl_tab_column_')||v_date_3d_bf||'_1';

       if v_cnt > 0 then
         execute immediate 'drop table xbhxbusi.t_etl_tab_column_'||v_date_3d_bf||'_1';
       end if;

       select count(1)
       into   v_cnt
       from   all_tables
       where  owner = upper('xbhxbusi')
       and    table_name = upper('t_etl_tab_column_')||v_date_3d_bf||'_2';

       if v_cnt > 0 then
         execute immediate 'drop table xbhxbusi.t_etl_tab_column_'||v_date_3d_bf||'_2';
       end if;

    V_ROW_COUNT := SQL%ROWCOUNT;
    V_RUN_END_TIME := SYSDATE;
    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',V_ROW_COUNT,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    STEP := '程序结束';
    V_RUN_START_TIME := SYSDATE;

    V_RUN_END_TIME := SYSDATE;
    insert into xbhxbusi.t_etl_log values (PRONAME,PROCDESC,STEP,'0','SUCCESS',0,V_RUN_START_TIME,V_RUN_END_TIME,v_data_time);
    commit;

    EXCEPTION
    WHEN OTHERS THEN

     --V_ERROR_CODE    := SQLCODE;
     --V_ERROR_MESSAGE := SQLERRM;

   RAISE;

end sp_etl_modified_column;
/

