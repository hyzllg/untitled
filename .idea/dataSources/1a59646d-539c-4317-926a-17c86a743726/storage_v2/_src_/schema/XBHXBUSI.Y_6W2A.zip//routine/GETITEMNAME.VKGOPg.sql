create FUNCTION getItemName(sCodeNo IN varchar2 ,sItemNo in varchar2 )
RETURN VARCHAR2
IS
sItemName VARCHAR2(80) ;
BEGIN
 select ItemName into sItemName from code_library where codeno = sCodeNo and ItemNo = sItemNo;
 return sItemName;
END getItemName;
/

