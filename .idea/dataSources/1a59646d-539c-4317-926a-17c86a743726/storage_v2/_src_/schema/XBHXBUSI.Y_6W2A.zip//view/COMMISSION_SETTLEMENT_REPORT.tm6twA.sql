create view COMMISSION_SETTLEMENT_REPORT as
select
    O.OBJECTNO,
    al.CONTRACTARTIFICIALNO,
    O.OBJECTTYPE,
    al.POLICYNO,
    O.CHANNELREPAYSNO,
    O.SERIALNO,
    O.TRANSENDTIME,
    al.DDPRODUCTID as PRODUCTID,
    O.PAYASSUREFEE,
    O.COMMISSIONTATE,
    nvl(COMMISSIONTATE,0)/100*nvl(PAYASSUREFEE,0) as COMMISSION,
    O.APPLYSERIALNO,
    O.BATCHNO,
    O.BATCHTYPE,
    DECODE(O.BATCHNO,'05','已理赔','99','已理赔','未理赔') as BATCHNOS,
    al.accountingorgid as ORGID,
    al.putoutdate,
    bi.agreementno
from LOAN_BATCH_INFO O, acct_loan al, business_insurancepolicyinfo bi
where o.objectNo = al.serialno
   and al.ddproductid in (select cl.itemattribute from CODE_LIBRARY cl where CODENO='AgentSubCommission')
   and bi.policyno = al.policyno
   and al.create_time > decode(al.ddproductid, '7014',to_date('2021/05/28 17:00:00','yyyy/mm/dd hh24:mi:ss'),to_date('2018/02/22','yyyy/mm/dd'))
/

