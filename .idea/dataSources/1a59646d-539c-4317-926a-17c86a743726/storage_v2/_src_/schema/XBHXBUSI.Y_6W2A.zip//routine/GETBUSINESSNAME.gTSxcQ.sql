create FUNCTION GETBUSINESSNAME
(
  PTYPENO IN VARCHAR2
) RETURN VARCHAR2
AS
sTypeName varchar2(80);
BEGIN
  select TypeName into sTypeName from business_type where TypeNo= pTypeNo;
  return sTypeName;
END GETBUSINESSNAME;
/

