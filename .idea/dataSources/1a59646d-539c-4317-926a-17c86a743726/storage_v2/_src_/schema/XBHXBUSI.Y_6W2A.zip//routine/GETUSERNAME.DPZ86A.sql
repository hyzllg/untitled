create FUNCTION getUserName(pUserID in VARCHAR2)
RETURN varchar2 AS sReturn varchar2(100);
begin
select UserName into sReturn from user_info where UserId = pUserID;
return sReturn;
end getUserName;
/

