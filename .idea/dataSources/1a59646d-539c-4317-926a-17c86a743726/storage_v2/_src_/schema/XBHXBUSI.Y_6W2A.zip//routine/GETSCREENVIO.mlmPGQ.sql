create function getScreenVio(vid varchar) return varchar is
/**
* 屏蔽姓名,手机号,证件号,卡号中间的信息 2017/12/20
* --调整身份证首尾显示个数
*/
  leh    number;
  screen varchar2(80);
  r      varchar2(80);
begin

  leh := length(vid);

  screen := '********************';
  if (leh = 18 or leh = 19 or leh = 16) then
    r := substr(vid, 0, 3) || substr(screen, 0, leh - 7) || substr(vid, leh - 3, leh);
  elsif (leh = 11) then
    r := substr(vid, 0, 3) || substr(screen, 0, 4) || substr(vid, leh - 3, leh);
  elsif(leh = 2) then
    r := substr(vid, 0, 1) || substr(screen, 1, leh - 1);
  elsif(leh = 1) then
    r := vid;
  else
    r := substr(vid, 0, 1) || substr(screen, 1, leh - 2) || substr(vid, leh, leh);
  end if;

  return r;

end;

/

